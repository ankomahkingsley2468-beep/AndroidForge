/**
 * Meridian IMS — Firestore Security Rules Adversarial Verification Suite ("Dirty Dozen")
 * Run with Firebase Emulator Suite (`@firebase/rules-unit-testing`) when testing locally.
 */

export interface DirtyDozenCase {
  id: number;
  name: string;
  path: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  expectedOutcome: 'PERMISSION_DENIED';
  description: string;
}

export const DIRTY_DOZEN_CASES: DirtyDozenCase[] = [
  {
    id: 1,
    name: 'Unauthenticated Branch Write',
    path: '/institutions/inst_1/branches/br_1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Rejects writes when request.auth is null.',
  },
  {
    id: 2,
    name: 'Unverified Email Admin Spoof',
    path: '/institutions/inst_1',
    operation: 'get',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Rejects super admin email when email_verified is false.',
  },
  {
    id: 3,
    name: 'Self-Assigned Super Admin',
    path: '/users/attacker_uid',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Prevents non-super-admin users from creating profiles with role=super_admin.',
  },
  {
    id: 4,
    name: 'Shadow Ghost Field Injection',
    path: '/institutions/inst_1/roster/ros_1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Rejects documents containing unlisted fields via data.keys().hasOnly().',
  },
  {
    id: 5,
    name: 'Cross-Tenant Call Access',
    path: '/institutions/inst_other/calls/call_1',
    operation: 'get',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Blocks members of inst_1 from reading calls inside inst_other.',
  },
  {
    id: 6,
    name: 'ID Poisoning Attack',
    path: '/institutions/inst_1/branches/' + 'a'.repeat(200),
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Enforces isValidId() regex and <= 128 char boundary.',
  },
  {
    id: 7,
    name: 'Timestamp Forgery',
    path: '/institutions/inst_1/attendance/att_1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Rejects client-forged createdAt timestamps not equal to request.time.',
  },
  {
    id: 8,
    name: 'Audit Log Mutation',
    path: '/institutions/inst_1/auditLogs/log_1',
    operation: 'delete',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Audit logs are strictly append-only; update and delete always fail.',
  },
  {
    id: 9,
    name: 'Privilege Escalation via Member Update',
    path: '/institutions/inst_1/members/emp_uid',
    operation: 'update',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Prevents employee role from elevating their own role to institution_admin.',
  },
  {
    id: 10,
    name: 'PII Blanket User List',
    path: '/users',
    operation: 'list',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Blocks non-super-admin users from enumerating all user PII documents.',
  },
  {
    id: 11,
    name: 'Oversized Payload Exhaustion',
    path: '/institutions/inst_1/calls/call_2',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Blocks strings exceeding schema length constraints.',
  },
  {
    id: 12,
    name: 'Backup Record Tampering',
    path: '/institutions/inst_1/backups/bak_1',
    operation: 'update',
    expectedOutcome: 'PERMISSION_DENIED',
    description: 'Prevents modification or deletion of recorded backup checksums.',
  },
];
