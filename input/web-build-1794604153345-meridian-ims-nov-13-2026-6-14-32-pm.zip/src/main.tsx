import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

registerSW({
  immediate: true,
  onRegisteredSW(_swUrl, registration) {
    if (registration) {
      window.dispatchEvent(new CustomEvent('meridian-sw-registered', { detail: registration }));
    }
  },
  onRegisterError(err) {
    console.warn('Service Worker registration warning:', err);
  },
});

createRoot(document.getElementById('root')!).render(<App />);
