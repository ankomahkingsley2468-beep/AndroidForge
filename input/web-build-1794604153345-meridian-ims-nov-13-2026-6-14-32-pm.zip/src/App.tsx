/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { IMSProvider, useIMS } from './context/IMSContext';
import { AuthOnboarding } from './components/AuthOnboarding';
import { AppShell } from './components/AppShell';
import { DashboardView } from './components/DashboardView';
import { AttendanceView } from './components/AttendanceView';
import { CallsView } from './components/CallsView';
import { AIAssistantView } from './components/AIAssistantView';
import { OrganizationStaffView } from './components/OrganizationStaffView';
import { ReportsView } from './components/ReportsView';
import { SystemViews } from './components/SystemViews';

const WorkspaceRouter: React.FC = () => {
  const { firebaseUser, authLoading, activeInstitution, activeTab } = useIMS();

  if (authLoading || !firebaseUser || !activeInstitution) {
    return <AuthOnboarding />;
  }

  return (
    <AppShell>
      {activeTab === 'dashboard' && <DashboardView />}
      {activeTab === 'super_admin' && <DashboardView superAdminMode />}
      {activeTab === 'attendance' && <AttendanceView />}
      {activeTab === 'calls' && <CallsView />}
      {activeTab === 'ai_assistant' && <AIAssistantView />}
      {activeTab === 'organization' && <OrganizationStaffView mode="organization" />}
      {activeTab === 'staff' && <OrganizationStaffView mode="staff" />}
      {activeTab === 'users_rbac' && <OrganizationStaffView mode="users_rbac" />}
      {activeTab === 'reports' && <ReportsView />}
      {activeTab === 'backups' && <SystemViews mode="backups" />}
      {activeTab === 'notifications' && <SystemViews mode="notifications" />}
      {activeTab === 'audit' && <SystemViews mode="audit" />}
      {activeTab === 'settings' && <SystemViews mode="settings" />}
    </AppShell>
  );
};

export default function App() {
  return (
    <IMSProvider>
      <WorkspaceRouter />
    </IMSProvider>
  );
}
