import React, { useEffect, useMemo, useRef, useState } from 'react';
import jsQR from 'jsqr';
import {
  Camera,
  CameraOff,
  CheckCircle2,
  Download,
  Lock,
  Printer,
  QrCode,
  RefreshCw,
  Search,
  Share2,
  ShieldCheck,
  UserCheck,
  AlertTriangle,
} from 'lucide-react';
import { todayDateKey, useIMS } from '../context/IMSContext';
import { buildMemberQrPayload, generateQrDataUrl, verifyQrPayload } from '../lib/qrUtils';
import type { RosterMember } from '../types/ims';

export const AttendanceView: React.FC = () => {
  const {
    activeInstitution,
    branches,
    departments,
    roster,
    attendance,
    effectivePermissions,
    selectedBadgeRosterId,
    setSelectedBadgeRosterId,
    recordAttendance,
    createNotification,
    offlineQueue,
    offlineActivityQueue,
    isOnline,
    isSyncingOffline,
    triggerServiceWorkerSync,
    pushToast,
  } = useIMS();

  const [subView, setSubView] = useState<'scanner' | 'credentials' | 'history'>('scanner');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualToken, setManualToken] = useState('');
  const [lastScanResult, setLastScanResult] = useState<{
    ok: boolean;
    message: string;
    detail?: string;
  } | null>(null);

  const [selectedRosterId, setSelectedRosterId] = useState<string>('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [qrPayloadText, setQrPayloadText] = useState<string>('');
  const [qrCountdown, setQrCountdown] = useState<number>(30);
  const [forceRotatingPreview, setForceRotatingPreview] = useState<boolean>(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [periodFilter, setPeriodFilter] = useState<'daily' | 'weekly' | 'monthly' | 'all'>('daily');
  const [dateFilter, setDateFilter] = useState(todayDateKey());
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [flaggingMissed, setFlaggingMissed] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const scanCooldownRef = useRef<number>(0);

  const today = todayDateKey();
  const activeRoster = roster.filter((r) => r.status === 'active');
  const todayRecords = attendance.filter((a) => a.dateKey === today);
  const offlineTodayCheckIns = offlineQueue.filter(
    (q) =>
      q.dateKey === today &&
      q.action === 'check_in' &&
      !todayRecords.some((a) => a.rosterId === q.rosterId)
  );
  const presentCount = todayRecords.length + offlineTodayCheckIns.length;
  const lateCount =
    todayRecords.filter((a) => a.status === 'late').length +
    offlineTodayCheckIns.filter((q) => q.status === 'late').length;
  const presentIdsToday = useMemo(() => {
    const ids = new Set(todayRecords.map((a) => a.rosterId));
    offlineTodayCheckIns.forEach((q) => ids.add(q.rosterId));
    return ids;
  }, [todayRecords, offlineTodayCheckIns]);
  const absentMembers = useMemo(
    () => activeRoster.filter((m) => !presentIdsToday.has(m.id)),
    [activeRoster, presentIdsToday]
  );
  const absentCount = absentMembers.length;
  const ratePct = activeRoster.length > 0 ? Math.round((presentCount / activeRoster.length) * 100) : 0;

  const selectedMember: RosterMember | undefined = useMemo(
    () => roster.find((r) => r.id === selectedRosterId) || activeRoster[0],
    [roster, activeRoster, selectedRosterId]
  );

  useEffect(() => {
    if (selectedBadgeRosterId) {
      setSelectedRosterId(selectedBadgeRosterId);
      setSubView('credentials');
      setSelectedBadgeRosterId(null);
    }
  }, [selectedBadgeRosterId, setSelectedBadgeRosterId]);

  useEffect(() => {
    if (!effectivePermissions.canViewAttendance && effectivePermissions.canCreateQrCodes && subView !== 'credentials') {
      setSubView('credentials');
    }
  }, [effectivePermissions.canViewAttendance, effectivePermissions.canCreateQrCodes, subView]);

  // Generate QR badge & auto-refresh when rotating mode is active
  useEffect(() => {
    if (!selectedMember) {
      setQrDataUrl('');
      setQrPayloadText('');
      return;
    }
    let mounted = true;
    const refreshQr = async () => {
      const built = buildMemberQrPayload(
        selectedMember,
        forceRotatingPreview || selectedMember.rotatingQrEnabled
      );
      setQrPayloadText(built.payload);
      setQrCountdown(built.expiresInSeconds);
      const url = await generateQrDataUrl(built.payload, false);
      if (mounted) setQrDataUrl(url);
    };

    refreshQr();
    const interval = setInterval(refreshQr, 1000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [selectedMember, forceRotatingPreview]);

  const stopCamera = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const processQrToken = async (raw: string) => {
    if (!activeInstitution) return;
    const verification = verifyQrPayload(raw, activeInstitution.id, roster);
    if (!verification.valid || !verification.member || !verification.mode) {
      setLastScanResult({
        ok: false,
        message: 'Verification Rejected',
        detail: verification.reason || 'Invalid QR credential.',
      });
      pushToast(verification.reason || 'Invalid QR credential.', 'error');
      return;
    }

    const res = await recordAttendance({
      member: verification.member,
      verificationMode: verification.mode,
    });

    if (res.action === 'duplicate') {
      setLastScanResult({
        ok: false,
        message: `${verification.member.fullName} — Duplicate Blocked`,
        detail: res.status,
      });
      pushToast(res.status, 'info');
      return;
    }

    setLastScanResult({
      ok: true,
      message: `${verification.member.fullName} (${res.action === 'check_out' ? 'Checked Out' : 'Checked In'})`,
      detail: `Status: ${res.status} · Mode: ${verification.mode.replace('_', ' ')}${res.offline ? ' · Queued Offline' : ''}`,
    });
    pushToast(`${verification.member.fullName} ${res.action === 'check_out' ? 'checked out' : 'checked in'} (${res.status}).`, 'success');
  };

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      streamRef.current = stream;
      setCameraActive(true);

      setTimeout(() => {
        if (!videoRef.current) return;
        videoRef.current.srcObject = stream;
        videoRef.current.play();

        const tick = () => {
          const video = videoRef.current;
          const canvas = canvasRef.current;
          if (!video || !canvas || !streamRef.current) return;
          if (video.readyState === video.HAVE_ENOUGH_DATA) {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
              const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
              const code = jsQR(imgData.data, imgData.width, imgData.height, {
                inversionAttempts: 'dontInvert',
              });
              if (code && code.data && Date.now() - scanCooldownRef.current > 2800) {
                scanCooldownRef.current = Date.now();
                processQrToken(code.data);
              }
            }
          }
          rafRef.current = requestAnimationFrame(tick);
        };
        rafRef.current = requestAnimationFrame(tick);
      }, 150);
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Camera permission denied or unavailable on this device.';
      setCameraError(msg);
      setCameraActive(false);
    }
  };

  const handleDownloadQr = () => {
    if (!qrDataUrl || !selectedMember) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `${selectedMember.memberCode}_QR_Badge.png`;
    a.click();
  };

  const handleShareQr = async () => {
    if (!selectedMember || !qrPayloadText) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${selectedMember.fullName} — NewOpenlink QR Credential`,
          text: `NewOpenlink Credential (${selectedMember.memberCode}): ${qrPayloadText}`,
        });
        return;
      } catch {
        // fallback to clipboard
      }
    }
    await navigator.clipboard.writeText(qrPayloadText);
    pushToast('Verifiable QR credential payload copied to clipboard.', 'success');
  };

  const handleFlagMissedAttendance = async () => {
    if (absentMembers.length === 0 || flaggingMissed) return;
    setFlaggingMissed(true);
    try {
      const namesPreview = absentMembers
        .slice(0, 6)
        .map((m) => `${m.fullName} (${m.memberCode})`)
        .join(', ');
      const suffix = absentMembers.length > 6 ? ` +${absentMembers.length - 6} more` : '';
      await createNotification({
        type: 'missed_attendance',
        severity: 'warning',
        title: `Missed Attendance Alert (${absentMembers.length} Absent)`,
        message: `Members with no check-in recorded for ${today}: ${namesPreview}${suffix}.`,
      });
      pushToast(`Missed attendance alert sent for ${absentMembers.length} absent member(s).`, 'success');
    } finally {
      setFlaggingMissed(false);
    }
  };

  const filteredHistory = useMemo(() => {
    const anchorStr = dateFilter || today;
    const anchorMs = new Date(`${anchorStr}T12:00:00`).getTime();
    return attendance.filter((a) => {
      if (periodFilter === 'daily' && anchorStr && a.dateKey !== anchorStr) return false;
      if (periodFilter === 'weekly' && a.dateKey) {
        const recMs = new Date(`${a.dateKey}T12:00:00`).getTime();
        const diffDays = (anchorMs - recMs) / 86400000;
        if (diffDays < 0 || diffDays >= 7) return false;
      }
      if (periodFilter === 'monthly' && a.dateKey.slice(0, 7) !== anchorStr.slice(0, 7)) return false;
      if (statusFilter !== 'all' && a.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          a.memberName.toLowerCase().includes(q) ||
          a.memberCode.toLowerCase().includes(q) ||
          (a.recordedByName || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [attendance, periodFilter, dateFilter, today, statusFilter, searchQuery]);

  const branchName = (id: string) => branches.find((b) => b.id === id)?.name || id;
  const deptName = (id: string) => departments.find((d) => d.id === id)?.name || id;

  if (!effectivePermissions.canViewAttendance && !effectivePermissions.canCreateQrCodes) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center space-y-3">
        <Lock className="w-8 h-8 text-slate-400 mx-auto" />
        <h2 className="font-display text-lg font-semibold">Restricted Attendance Access</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
          Your current role does not include permission to operate QR attendance scanners or view institutional attendance logs.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">QR Code Attendance</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Verifiable static &amp; rotating QR credentials, live camera scanning, and offline-capable check-ins.
          </p>
        </div>

        {/* Segmented Sub-Navigation */}
        <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-lg self-start">
          {[
            ...(effectivePermissions.canViewAttendance
              ? [{ id: 'scanner' as const, label: 'QR Scanner' }]
              : []),
            ...(effectivePermissions.canCreateQrCodes || effectivePermissions.canViewAttendance
              ? [{ id: 'credentials' as const, label: 'QR Badges' }]
              : []),
            ...(effectivePermissions.canViewAttendance
              ? [{ id: 'history' as const, label: 'Attendance Logs' }]
              : []),
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSubView(tab.id)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subView === tab.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Attendance Dashboard KPI Strip */}
      <div className="no-print grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Registered Members</p>
          <p className="font-display text-2xl font-bold tabular-nums mt-1">{activeRoster.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Present Today</p>
          <p className="font-display text-2xl font-bold tabular-nums text-emerald-600 dark:text-emerald-400 mt-1">
            {presentCount}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex items-start justify-between gap-2">
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Absent Today</p>
            <p className="font-display text-2xl font-bold tabular-nums text-rose-600 dark:text-rose-400 mt-1">
              {absentCount}
            </p>
          </div>
          {effectivePermissions.canViewAttendance && absentCount > 0 && (
            <button
              type="button"
              onClick={handleFlagMissedAttendance}
              disabled={flaggingMissed}
              title="Broadcast missed attendance notification for absent members"
              className="px-2 py-1 rounded-md border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-[11px] font-medium whitespace-nowrap cursor-pointer disabled:opacity-50"
            >
              {flaggingMissed ? 'Alerting...' : 'Flag Missed'}
            </button>
          )}
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Late Arrivals</p>
          <p className="font-display text-2xl font-bold tabular-nums text-amber-600 dark:text-amber-400 mt-1">
            {lateCount}
          </p>
        </div>
        <div className="col-span-2 lg:col-span-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Attendance Rate</p>
          <p className="font-display text-2xl font-bold tabular-nums text-indigo-600 dark:text-indigo-400 mt-1">
            {ratePct}%
          </p>
        </div>
      </div>

      {/* Offline IndexedDB Queue Banner if items pending */}
      {(offlineQueue.length > 0 || offlineActivityQueue.length > 0) && (
        <div className="no-print p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs text-amber-800 dark:text-amber-300">
            <strong>{offlineQueue.length} attendance</strong> &amp; <strong>{offlineActivityQueue.length} activity log(s)</strong> stored in IndexedDB and queued with the Service Worker for Firebase sync.
          </div>
          <button
            type="button"
            onClick={() => triggerServiceWorkerSync()}
            disabled={!isOnline || isSyncingOffline}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-medium self-start cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingOffline ? 'animate-spin' : ''}`} />
            <span>{isSyncingOffline ? 'Syncing...' : isOnline ? 'Sync via Service Worker' : 'Waiting for Network'}</span>
          </button>
        </div>
      )}

      {/* SCANNER VIEW */}
      {subView === 'scanner' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display text-base font-semibold">Live Camera QR Scanner</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Uses rear device camera on Android &amp; desktop webcams to verify credentials.
                </p>
              </div>
              {cameraActive ? (
                <button
                  type="button"
                  onClick={stopCamera}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-medium cursor-pointer"
                >
                  <CameraOff className="w-4 h-4" />
                  <span>Stop Camera</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={startCamera}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>Start Camera</span>
                </button>
              )}
            </div>

            {cameraError && (
              <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
                {cameraError}
              </div>
            )}

            <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
              {cameraActive ? (
                <>
                  <video ref={videoRef} playsInline muted className="w-full h-full object-cover" />
                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                    <div className="w-48 h-48 border-2 border-indigo-400 rounded-xl" />
                  </div>
                </>
              ) : (
                <div className="text-center space-y-2 p-6 text-slate-400">
                  <QrCode className="w-10 h-10 mx-auto opacity-70" />
                  <p className="text-sm font-medium text-slate-200">Camera Standby</p>
                  <p className="text-xs max-w-xs mx-auto">
                    Tap &ldquo;Start Camera&rdquo; to scan a member&apos;s QR badge, or paste a verifiable token below.
                  </p>
                </div>
              )}
              <canvas ref={canvasRef} className="hidden" />
            </div>

            {lastScanResult && (
              <div
                className={`p-3.5 rounded-lg border flex items-start gap-3 ${
                  lastScanResult.ok
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                    : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
                }`}
              >
                {lastScanResult.ok ? (
                  <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                )}
                <div>
                  <p className="text-sm font-semibold">{lastScanResult.message}</p>
                  {lastScanResult.detail && <p className="text-xs opacity-90">{lastScanResult.detail}</p>}
                </div>
              </div>
            )}

            {/* Manual Token Verification Fallback */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (manualToken.trim()) {
                  processQrToken(manualToken);
                  setManualToken('');
                }
              }}
              className="flex gap-2 pt-2"
            >
              <input
                type="text"
                value={manualToken}
                onChange={(e) => setManualToken(e.target.value)}
                placeholder="Paste MERIDIAN:... QR credential string to verify"
                className="flex-1 px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-slate-900 dark:bg-indigo-600 text-white text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
              >
                Verify Token
              </button>
            </form>
          </div>

          {/* Officer Quick Check-In / Check-Out Desk */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display text-base font-semibold">Officer Quick Roster</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Authorized officer check-in / check-out or simulate scanning a member&apos;s QR
                </p>
              </div>
              <ShieldCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            </div>

            <div className="divide-y divide-slate-200 dark:divide-slate-800 max-h-[420px] overflow-y-auto">
              {activeRoster.map((member) => {
                const rec = todayRecords.find((a) => a.rosterId === member.id);
                const offlineForMember = offlineQueue.filter(
                  (q) => q.rosterId === member.id && q.dateKey === today
                );
                const isCompleted =
                  Boolean(rec?.checkOutIso) ||
                  offlineForMember.some((q) => q.action === 'check_out');
                const isCheckedIn =
                  Boolean(rec) ||
                  offlineForMember.some((q) => q.action === 'check_in');
                return (
                  <div key={member.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{member.fullName}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                        {member.memberCode} · {deptName(member.departmentId)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={async () => {
                          const res = await recordAttendance({
                            member,
                            verificationMode: 'manual_officer',
                          });
                          setLastScanResult({
                            ok: res.action !== 'duplicate',
                            message: `${member.fullName} — ${res.action.replace('_', ' ')}`,
                            detail: res.status,
                          });
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer ${
                          isCompleted
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                            : isCheckedIn
                            ? 'bg-amber-600 hover:bg-amber-700 text-white'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        }`}
                      >
                        {isCompleted ? 'Completed' : isCheckedIn ? 'Check Out' : 'Check In'}
                      </button>
                    </div>
                  </div>
                );
              })}
              {activeRoster.length === 0 && (
                <p className="py-8 text-center text-xs text-slate-400">
                  Register staff or students in Staff &amp; Roster first.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* QR CREDENTIALS & PRINTABLE BADGE VIEW */}
      {subView === 'credentials' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="no-print lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <h2 className="font-display text-base font-semibold">Select Registered Member</h2>
            <select
              value={selectedMember?.id || ''}
              onChange={(e) => setSelectedRosterId(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              {activeRoster.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.fullName} ({m.memberCode})
                </option>
              ))}
            </select>

            <label className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer">
              <div>
                <p className="text-sm font-medium">Rotating 30s QR Token</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Prevents screenshot reuse by rotating cryptographic signature every 30 seconds.
                </p>
              </div>
              <input
                type="checkbox"
                checked={forceRotatingPreview || Boolean(selectedMember?.rotatingQrEnabled)}
                onChange={(e) => setForceRotatingPreview(e.target.checked)}
                className="rounded text-indigo-600"
              />
            </label>

            {qrPayloadText && (
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                <p className="text-xs font-medium text-slate-500">Verifiable Credential Payload</p>
                <p className="text-xs font-mono break-all text-slate-800 dark:text-slate-200">
                  {qrPayloadText}
                </p>
                <button
                  type="button"
                  onClick={() => processQrToken(qrPayloadText)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Test Scan This Credential Now</span>
                </button>
              </div>
            )}
          </div>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center space-y-4">
            {selectedMember && qrDataUrl ? (
              <>
                <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-700 bg-white text-slate-900 text-center space-y-3 max-w-xs w-full">
                  <p className="text-xs font-semibold uppercase tracking-wider text-indigo-700">
                    {activeInstitution?.name}
                  </p>
                  <img
                    src={qrDataUrl}
                    alt={`QR Badge for ${selectedMember.fullName}`}
                    className="w-52 h-52 mx-auto"
                  />
                  <div>
                    <h3 className="font-display text-lg font-bold text-slate-900">
                      {selectedMember.fullName}
                    </h3>
                    <p className="text-xs font-mono text-slate-600">
                      {selectedMember.memberCode} · {selectedMember.memberType.toUpperCase()}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {branchName(selectedMember.branchId)} · {deptName(selectedMember.departmentId)}
                    </p>
                  </div>
                  {(forceRotatingPreview || selectedMember.rotatingQrEnabled) && (
                    <p className="text-xs font-mono tabular-nums text-indigo-700">
                      Rotating Token · Refreshes in {qrCountdown}s
                    </p>
                  )}
                </div>

                {effectivePermissions.canCreateQrCodes && (
                  <div className="no-print flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={handleDownloadQr}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download PNG</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleShareQr}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium cursor-pointer"
                    >
                      <Share2 className="w-4 h-4" />
                      <span>Share Credential</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium cursor-pointer"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Print Badge</span>
                    </button>
                  </div>
                )}
              </>
            ) : (
              <p className="text-sm text-slate-400">No active members in roster.</p>
            )}
          </div>
        </div>
      )}

      {/* ATTENDANCE HISTORY VIEW */}
      {subView === 'history' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search member name, code, or officer..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={periodFilter}
                onChange={(e) => setPeriodFilter(e.target.value as 'daily' | 'weekly' | 'monthly' | 'all')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly (7d)</option>
                <option value="monthly">Monthly</option>
                <option value="all">All Dates</option>
              </select>
              {periodFilter !== 'all' && (
                <input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  title={
                    periodFilter === 'daily'
                      ? 'Selected date'
                      : periodFilter === 'weekly'
                      ? '7-day window ending on this date'
                      : 'Selected month anchor date'
                  }
                  className="px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              )}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                <option value="all">All Statuses</option>
                <option value="present">Present</option>
                <option value="late">Late</option>
                <option value="checked_out">Checked Out</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="px-4 py-3 font-medium">Member</th>
                  <th className="px-4 py-3 font-medium">Branch / Dept</th>
                  <th className="px-4 py-3 font-medium">Check-In</th>
                  <th className="px-4 py-3 font-medium">Check-Out</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Verified By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {filteredHistory.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="px-4 py-3">
                      <p className="font-medium text-slate-900 dark:text-white">{row.memberName}</p>
                      <p className="text-xs font-mono text-slate-500">{row.memberCode}</p>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600 dark:text-slate-300">
                      {branchName(row.branchId)} · {deptName(row.departmentId)}
                    </td>
                    <td className="px-4 py-3 text-xs font-mono tabular-nums">
                      {new Date(row.checkInIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="px-4 py-3 text-xs font-mono tabular-nums text-slate-500">
                      {row.checkOutIso
                        ? new Date(row.checkOutIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        : '—'}
                    </td>
                    <td className="px-4 py-3 text-xs font-medium capitalize">
                      <span
                        className={
                          row.status === 'late'
                            ? 'text-amber-600 dark:text-amber-400'
                            : row.status === 'checked_out'
                            ? 'text-slate-600 dark:text-slate-300'
                            : 'text-emerald-600 dark:text-emerald-400'
                        }
                      >
                        {row.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400">
                      {row.recordedByName || 'System'} · {(row.verificationMode || 'qr').replace('_', ' ')}
                    </td>
                  </tr>
                ))}
                {filteredHistory.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-xs text-slate-400">
                      No attendance records match the selected date and filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
