import React, { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
} from 'recharts';
import {
  Bot,
  Building2,
  CalendarCheck,
  PhoneCall,
  Plus,
  QrCode,
  Shield,
  Users,
  ArrowUpRight,
} from 'lucide-react';
import { todayDateKey, useIMS } from '../context/IMSContext';
import type { InstitutionType } from '../types/ims';

export const DashboardView: React.FC<{ superAdminMode?: boolean }> = ({ superAdminMode = false }) => {
  const {
    activeInstitution,
    institutions,
    selectInstitution,
    createInstitution,
    branches,
    departments,
    roster,
    attendance,
    calls,
    notifications,
    selectedBranchFilter,
    setActiveTab,
  } = useIMS();

  const [showNewInstModal, setShowNewInstModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newCode, setNewCode] = useState('');
  const [newType, setNewType] = useState<InstitutionType>('corporate');
  const [newCountry, setNewCountry] = useState('United Kingdom');
  const [creating, setCreating] = useState(false);

  const today = todayDateKey();

  const filteredRoster = useMemo(
    () =>
      selectedBranchFilter === 'all'
        ? roster
        : roster.filter((r) => r.branchId === selectedBranchFilter),
    [roster, selectedBranchFilter]
  );

  const filteredAttendanceToday = useMemo(() => {
    return attendance.filter(
      (a) =>
        a.dateKey === today &&
        (selectedBranchFilter === 'all' || a.branchId === selectedBranchFilter)
    );
  }, [attendance, today, selectedBranchFilter]);

  const filteredCalls = useMemo(
    () =>
      selectedBranchFilter === 'all'
        ? calls
        : calls.filter((c) => !c.branchId || c.branchId === selectedBranchFilter),
    [calls, selectedBranchFilter]
  );

  const totalMembers = filteredRoster.filter((r) => r.status === 'active').length;
  const presentToday = filteredAttendanceToday.length;
  const lateToday = filteredAttendanceToday.filter((a) => a.status === 'late').length;
  const absentToday = Math.max(0, totalMembers - presentToday);
  const attendancePct = totalMembers > 0 ? Math.round((presentToday / totalMembers) * 100) : 0;

  const branchMetrics = useMemo(() => {
    return branches.map((b) => {
      const bMembers = roster.filter((r) => r.branchId === b.id && r.status === 'active').length;
      const bPresent = attendance.filter((a) => a.branchId === b.id && a.dateKey === today).length;
      const bCalls = calls.filter((c) => c.branchId === b.id).length;
      return {
        name: b.code,
        fullName: b.name,
        Present: bPresent,
        Registered: bMembers,
        Calls: bCalls,
      };
    });
  }, [branches, roster, attendance, calls, today]);

  const callCategoryChart = useMemo(() => {
    const map = new Map<string, number>();
    filteredCalls.forEach((c) => {
      map.set(c.category, (map.get(c.category) || 0) + 1);
    });
    return Array.from(map.entries()).map(([category, count]) => ({ category, count }));
  }, [filteredCalls]);

  const handleCreateInst = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newCode.trim()) return;
    setCreating(true);
    try {
      await createInstitution({
        name: newName,
        code: newCode,
        type: newType,
        country: newCountry,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        workStartTime: '09:00',
        seedSampleData: true,
      });
      setShowNewInstModal(false);
      setNewName('');
      setNewCode('');
    } finally {
      setCreating(false);
    }
  };

  if (superAdminMode) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Super Administrator Console
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Global multi-institution oversight, tenant provisioning, and cross-branch governance.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowNewInstModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Register Institution</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Provisioned Institutions</p>
            <p className="font-display text-3xl font-bold tabular-nums mt-1">{institutions.length}</p>
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Active Workspace Branches</p>
            <p className="font-display text-3xl font-bold tabular-nums mt-1">{branches.length}</p>
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Active Workspace Roster</p>
            <p className="font-display text-3xl font-bold tabular-nums mt-1">{roster.length}</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h2 className="font-display text-base font-semibold">Registered Institutions</h2>
            <span className="text-xs text-slate-500 tabular-nums">{institutions.length} total</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="px-5 py-3 font-medium">Institution</th>
                  <th className="px-5 py-3 font-medium">Code</th>
                  <th className="px-5 py-3 font-medium">Type</th>
                  <th className="px-5 py-3 font-medium">Country / TZ</th>
                  <th className="px-5 py-3 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {institutions.map((inst) => (
                  <tr key={inst.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="px-5 py-3.5 font-medium text-slate-900 dark:text-white">{inst.name}</td>
                    <td className="px-5 py-3.5 font-mono text-xs text-slate-600 dark:text-slate-300">{inst.code}</td>
                    <td className="px-5 py-3.5 capitalize text-slate-600 dark:text-slate-300">{inst.type}</td>
                    <td className="px-5 py-3.5 text-xs text-slate-500 dark:text-slate-400">
                      {inst.country || 'Global'} · {inst.timezone || 'UTC'}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        type="button"
                        onClick={() => {
                          selectInstitution(inst.id);
                          setActiveTab('dashboard');
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                          activeInstitution?.id === inst.id
                            ? 'bg-emerald-600 text-white'
                            : 'border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        {activeInstitution?.id === inst.id ? 'Active Workspace' : 'Open Workspace'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {showNewInstModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
            <form
              onSubmit={handleCreateInst}
              className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
            >
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-indigo-600" />
                <h3 className="font-display text-lg font-semibold">Register New Institution</h3>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Institution Name</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Global Health Network"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium mb-1">Code</label>
                  <input
                    type="text"
                    required
                    value={newCode}
                    onChange={(e) => setNewCode(e.target.value)}
                    placeholder="GHN"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as InstitutionType)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                  >
                    <option value="university">University</option>
                    <option value="school">School</option>
                    <option value="hospital">Hospital</option>
                    <option value="corporate">Corporate</option>
                    <option value="government">Government</option>
                    <option value="nonprofit">Nonprofit</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Country</label>
                <input
                  type="text"
                  value={newCountry}
                  onChange={(e) => setNewCountry(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewInstModal(false)}
                  className="px-4 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-4 py-2 text-xs font-medium rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white"
                >
                  {creating ? 'Creating...' : 'Create Institution'}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Quick Operational Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            {activeInstitution?.name}
          </h1>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
            <span className="capitalize">{activeInstitution?.type}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{activeInstitution?.code}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{branches.length} Branches</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{departments.length} Departments</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('attendance')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
          >
            <QrCode className="w-4 h-4" />
            <span>Scan QR Attendance</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('calls')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
          >
            <PhoneCall className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>Record / Log Call</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ai_assistant')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Bot className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Ask AI Assistant</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Attendance Rate Today</span>
            <CalendarCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p className="font-display text-3xl font-bold tabular-nums mt-2">{attendancePct}%</p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {presentToday} present / {totalMembers} active members
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Late &amp; Absent Today</span>
            <Users className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="font-display text-3xl font-bold tabular-nums mt-2">
            {lateToday} <span className="text-base font-normal text-slate-400">/ {absentToday}</span>
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Late arrivals · Unchecked members
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Logged &amp; Recorded Calls</span>
            <PhoneCall className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          </div>
          <p className="font-display text-3xl font-bold tabular-nums mt-2">{filteredCalls.length}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {filteredCalls.filter((c) => Boolean(c.transcript)).length} transcribed by AI
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Operational Structure</span>
            <Building2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="font-display text-3xl font-bold tabular-nums mt-2">
            {branches.length} <span className="text-base font-normal text-slate-400">branches</span>
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
            {departments.length} departments · {notifications.filter((n) => !n.isRead).length} unread alerts
          </p>
        </div>
      </div>

      {/* Analytics Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-display text-base font-semibold">Branch Attendance &amp; Capacity</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Today&apos;s verified check-ins compared against registered branch roster
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('reports')}
              className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              <span>Full Reports</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="h-64 w-full">
            {branchMetrics.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={branchMetrics} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="Registered" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Present" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Add branches and members to view attendance distribution.
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-display text-base font-semibold">Calls by Category</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                AI-classified and manually routed communication volume
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('calls')}
              className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              <span>Call Center</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="h-64 w-full">
            {callCategoryChart.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={callCategoryChart} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="category" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Area type="monotone" dataKey="count" stroke="#2563eb" fill="#3b82f6" fillOpacity={0.18} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Log or record calls to populate category analytics.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Live Recent Activity Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold">Recent Attendance Check-Ins</h3>
            <button
              type="button"
              onClick={() => setActiveTab('attendance')}
              className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              View All
            </button>
          </div>
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {attendance.slice(0, 5).map((rec) => (
              <div key={rec.id} className="px-5 py-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate text-slate-900 dark:text-white">
                    {rec.memberName}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    {rec.memberCode} · {rec.dateKey}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span
                    className={`text-xs font-medium capitalize ${
                      rec.status === 'late'
                        ? 'text-amber-600 dark:text-amber-400'
                        : rec.status === 'checked_out'
                        ? 'text-slate-600 dark:text-slate-300'
                        : 'text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    {rec.status.replace('_', ' ')}
                  </span>
                  <p className="text-xs font-mono tabular-nums text-slate-400">
                    {new Date(rec.checkInIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            {attendance.length === 0 && (
              <p className="px-5 py-8 text-center text-xs text-slate-400">
                No attendance scans recorded yet.
              </p>
            )}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold">Recent Institutional Calls</h3>
            <button
              type="button"
              onClick={() => setActiveTab('calls')}
              className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
            >
              Open Call Desk
            </button>
          </div>
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {calls.slice(0, 5).map((call) => (
              <div key={call.id} className="px-5 py-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate text-slate-900 dark:text-white">
                    {call.callerName} → {call.recipientName}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {call.category} · {call.callSource.replace('_', ' ').toUpperCase()}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-xs font-medium capitalize text-blue-600 dark:text-blue-400">
                    {call.status.replace('_', ' ')}
                  </span>
                  <p className="text-xs font-mono tabular-nums text-slate-400">
                    {Math.floor(call.durationSeconds / 60)}m {call.durationSeconds % 60}s
                  </p>
                </div>
              </div>
            ))}
            {calls.length === 0 && (
              <p className="px-5 py-8 text-center text-xs text-slate-400">
                No calls logged yet.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
