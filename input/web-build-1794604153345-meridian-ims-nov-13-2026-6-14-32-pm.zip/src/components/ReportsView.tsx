import React, { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';
import { FileSpreadsheet, FileText, Lock, Printer, Table } from 'lucide-react';
import { useIMS } from '../context/IMSContext';
import { exportReportToPdf, exportRowsToCsv, exportWorkbookToExcel } from '../lib/exportUtils';

type ReportKind = 'attendance' | 'calls' | 'branches' | 'departments' | 'staff';

const CHART_COLORS = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444'];

export const ReportsView: React.FC = () => {
  const {
    activeInstitution,
    branches,
    departments,
    roster,
    attendance,
    calls,
    effectivePermissions,
  } = useIMS();

  const [reportType, setReportType] = useState<ReportKind>('attendance');
  const [branchFilter, setBranchFilter] = useState('all');

  const branchName = (id?: string) => branches.find((b) => b.id === id)?.name || 'HQ';
  const deptName = (id?: string) => departments.find((d) => d.id === id)?.name || 'General';

  const reportData = useMemo(() => {
    if (reportType === 'attendance') {
      const rows = attendance
        .filter((a) => branchFilter === 'all' || a.branchId === branchFilter)
        .map((a) => [
          a.dateKey,
          a.memberCode,
          a.memberName,
          branchName(a.branchId),
          deptName(a.departmentId),
          a.status,
          new Date(a.checkInIso).toLocaleTimeString(),
          a.checkOutIso ? new Date(a.checkOutIso).toLocaleTimeString() : '—',
        ]);
      return {
        title: 'Institutional Attendance Report',
        headers: ['Date', 'Code', 'Member', 'Branch', 'Department', 'Status', 'Check-In', 'Check-Out'],
        rows,
      };
    }

    if (reportType === 'calls') {
      const rows = calls
        .filter((c) => branchFilter === 'all' || c.branchId === branchFilter)
        .map((c) => [
          new Date(c.startedAtIso).toLocaleDateString(),
          c.callerName,
          c.recipientName,
          c.category,
          c.callSource,
          `${c.durationSeconds}s`,
          c.status,
          c.aiSummary ? c.aiSummary.slice(0, 80) : c.notes || '—',
        ]);
      return {
        title: 'Call Management & AI Intelligence Report',
        headers: ['Date', 'Caller', 'Recipient', 'Category', 'Channel', 'Duration', 'Status', 'Summary'],
        rows,
      };
    }

    if (reportType === 'branches') {
      const rows = branches.map((b) => {
        const bStaff = roster.filter((r) => r.branchId === b.id).length;
        const bAtt = attendance.filter((a) => a.branchId === b.id).length;
        const bCalls = calls.filter((c) => c.branchId === b.id).length;
        return [b.code, b.name, b.city || '—', bStaff, bAtt, bCalls, b.status];
      });
      return {
        title: 'Branch Performance Comparison Report',
        headers: ['Code', 'Branch', 'City', 'Roster Size', 'Total Check-Ins', 'Calls Logged', 'Status'],
        rows,
      };
    }

    if (reportType === 'departments') {
      const rows = departments
        .filter((d) => branchFilter === 'all' || d.branchId === branchFilter)
        .map((d) => {
          const dStaff = roster.filter((r) => r.departmentId === d.id).length;
          const dAtt = attendance.filter((a) => a.departmentId === d.id).length;
          const dCalls = calls.filter((c) => c.departmentId === d.id).length;
          return [d.code, d.name, branchName(d.branchId), d.headName || '—', dStaff, dAtt, dCalls];
        });
      return {
        title: 'Departmental Operations Report',
        headers: ['Code', 'Department', 'Branch', 'Lead', 'Members', 'Attendance Logs', 'Calls'],
        rows,
      };
    }

    const rows = roster
      .filter((r) => branchFilter === 'all' || r.branchId === branchFilter)
      .map((r) => [
        r.memberCode,
        r.fullName,
        r.memberType,
        r.jobTitle || '—',
        branchName(r.branchId),
        deptName(r.departmentId),
        r.status,
      ]);
    return {
      title: 'Employee & Registered Member Report',
      headers: ['Code', 'Full Name', 'Type', 'Title', 'Branch', 'Department', 'Status'],
      rows,
    };
  }, [reportType, branchFilter, attendance, calls, branches, departments, roster]);

  const branchChart = useMemo(() => {
    return branches.map((b) => ({
      name: b.code,
      Members: roster.filter((r) => r.branchId === b.id).length,
      Attendance: attendance.filter((a) => a.branchId === b.id).length,
      Calls: calls.filter((c) => c.branchId === b.id).length,
    }));
  }, [branches, roster, attendance, calls]);

  const statusBreakdown = useMemo(() => {
    const scoped = attendance.filter((a) => branchFilter === 'all' || a.branchId === branchFilter);
    const present = scoped.filter((a) => a.status === 'present').length;
    const late = scoped.filter((a) => a.status === 'late').length;
    const checkedOut = scoped.filter((a) => a.status === 'checked_out').length;
    return [
      { name: 'Present', value: present },
      { name: 'Late', value: late },
      { name: 'Checked Out', value: checkedOut },
    ].filter((s) => s.value > 0);
  }, [attendance, branchFilter]);

  const monthlyStats = useMemo(() => {
    const map = new Map<string, { month: string; Attendance: number; Calls: number }>();
    attendance
      .filter((a) => branchFilter === 'all' || a.branchId === branchFilter)
      .forEach((a) => {
        const month = a.dateKey.slice(0, 7);
        const cur = map.get(month) || { month, Attendance: 0, Calls: 0 };
        cur.Attendance += 1;
        map.set(month, cur);
      });
    calls
      .filter((c) => branchFilter === 'all' || c.branchId === branchFilter)
      .forEach((c) => {
        const month = (c.startedAtIso || '').slice(0, 7) || new Date().toISOString().slice(0, 7);
        const cur = map.get(month) || { month, Attendance: 0, Calls: 0 };
        cur.Calls += 1;
        map.set(month, cur);
      });
    return Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month));
  }, [attendance, calls, branchFilter]);

  if (!effectivePermissions.canGenerateReports) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center space-y-3">
        <Lock className="w-8 h-8 text-slate-400 mx-auto" />
        <h2 className="font-display text-lg font-semibold">Report Access Restricted</h2>
        <p className="text-sm text-slate-500">
          Your role does not include report generation permissions.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Reports &amp; Analytics</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Generate printable executive reports, Excel workbooks, PDF documents, and CSV datasets.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() =>
              exportReportToPdf({
                title: reportData.title,
                institutionName: activeInstitution?.name || 'NewOpenlink',
                subtitle: `${reportData.rows.length} rows`,
                headers: reportData.headers,
                rows: reportData.rows,
                filename: `${activeInstitution?.code || 'IMS'}_${reportType}_report.pdf`,
              })
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Export PDF</span>
          </button>

          <button
            type="button"
            onClick={() =>
              exportWorkbookToExcel(`${activeInstitution?.code || 'IMS'}_${reportType}_report.xlsx`, [
                {
                  name: reportType.toUpperCase(),
                  headers: reportData.headers,
                  rows: reportData.rows,
                },
              ])
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Excel</span>
          </button>

          <button
            type="button"
            onClick={() =>
              exportRowsToCsv(
                `${activeInstitution?.code || 'IMS'}_${reportType}_report.csv`,
                reportData.headers,
                reportData.rows
              )
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium cursor-pointer"
          >
            <Table className="w-4 h-4" />
            <span>CSV</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Interactive Analytics Charts */}
      <div className="no-print grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="font-display text-base font-semibold mb-4">Branch Performance Overview</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={branchChart} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="Members" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Attendance" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Calls" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="font-display text-base font-semibold mb-4">Attendance Status Mix</h2>
          <div className="h-64">
            {statusBreakdown.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusBreakdown}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label
                  >
                    {statusBreakdown.map((_entry, index) => (
                      <Cell key={index} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No attendance logs recorded yet.
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="font-display text-base font-semibold mb-1">Monthly Operational Statistics</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Monthly volume across check-ins and logged communications{branchFilter !== 'all' ? ' (filtered branch)' : ''}
          </p>
          <div className="h-52">
            {monthlyStats.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyStats} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Area type="monotone" dataKey="Attendance" stroke="#4f46e5" fill="#4f46e5" fillOpacity={0.18} />
                  <Area type="monotone" dataKey="Calls" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.18} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Record attendance or call logs to populate monthly statistics.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Report Dataset Selector & Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="no-print p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
            {(
              [
                ['attendance', 'Attendance'],
                ['calls', 'Calls'],
                ['branches', 'Branches'],
                ['departments', 'Departments'],
                ['staff', 'Employees'],
              ] as Array<[ReportKind, string]>
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setReportType(key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                  reportType === key
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <select
            value={branchFilter}
            onChange={(e) => setBranchFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
          >
            <option value="all">All Branches</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>

        <div className="p-4 border-b border-slate-200 dark:border-slate-800">
          <h3 className="font-display text-base font-semibold">{reportData.title}</h3>
          <p className="text-xs text-slate-500">
            {activeInstitution?.name} · {reportData.rows.length} rows
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 border-b border-slate-200 dark:border-slate-800">
              <tr>
                {reportData.headers.map((h) => (
                  <th key={h} className="px-4 py-3 font-medium">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {reportData.rows.map((row, i) => (
                <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  {row.map((cell, j) => (
                    <td key={j} className="px-4 py-3 tabular-nums">
                      {String(cell)}
                    </td>
                  ))}
                </tr>
              ))}
              {reportData.rows.length === 0 && (
                <tr>
                  <td colSpan={reportData.headers.length} className="px-4 py-8 text-center text-slate-400">
                    No records available for this report filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
