import React, { useState } from 'react';
import {
  Activity,
  BarChart3,
  Bell,
  Bot,
  Building2,
  CloudUpload,
  Download,
  FileCheck2,
  LayoutDashboard,
  LogOut,
  Menu,
  Mic,
  Moon,
  MoreHorizontal,
  PhoneCall,
  QrCode,
  Settings,
  Shield,
  Sun,
  Users,
  UserCog,
  WifiOff,
  RefreshCw,
  X,
} from 'lucide-react';
import { useIMS } from '../context/IMSContext';
import { usePWAInstall } from '../hooks/usePWA';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';
import { t } from '../lib/i18n';
import { ROLE_LABELS, type ActiveTab } from '../types/ims';
import fallbackAvatar from '../assets/images/avatar_admin_portrait_1794585621458.jpg';

interface NavGroup {
  category: string;
  items: Array<{
    id: ActiveTab;
    labelKey: string;
    icon: React.ComponentType<{ className?: string }>;
    superOnly?: boolean;
  }>;
}

const NAV_GROUPS: NavGroup[] = [
  {
    category: 'Overview',
    items: [
      { id: 'dashboard', labelKey: 'dashboard', icon: LayoutDashboard },
      { id: 'super_admin', labelKey: 'super_admin', icon: Shield, superOnly: true },
    ],
  },
  {
    category: 'Operations',
    items: [
      { id: 'attendance', labelKey: 'attendance', icon: QrCode },
      { id: 'calls', labelKey: 'calls', icon: PhoneCall },
      { id: 'ai_assistant', labelKey: 'ai_assistant', icon: Bot },
    ],
  },
  {
    category: 'Organization',
    items: [
      { id: 'organization', labelKey: 'organization', icon: Building2 },
      { id: 'staff', labelKey: 'staff', icon: Users },
      { id: 'reports', labelKey: 'reports', icon: BarChart3 },
    ],
  },
  {
    category: 'Governance & Sync',
    items: [
      { id: 'users_rbac', labelKey: 'users_rbac', icon: UserCog },
      { id: 'backups', labelKey: 'backups', icon: CloudUpload },
      { id: 'notifications', labelKey: 'notifications', icon: Bell },
      { id: 'audit', labelKey: 'audit', icon: FileCheck2 },
      { id: 'settings', labelKey: 'settings', icon: Settings },
    ],
  },
];

export const AppShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    firebaseUser,
    userProfile,
    institutions,
    activeInstitution,
    selectInstitution,
    branches,
    selectedBranchFilter,
    setSelectedBranchFilter,
    activeTab,
    setActiveTab,
    triggerVoiceAssistant,
    theme,
    toggleTheme,
    language,
    notifications,
    offlineQueue,
    offlineActivityQueue,
    isOnline,
    simulatedOffline,
    setSimulatedOffline,
    isSyncingOffline,
    triggerServiceWorkerSync,
    effectiveRole,
    previewRole,
    setPreviewRole,
    toasts,
    dismissToast,
    logout,
  } = useIMS();

  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [iosModalOpen, setIosModalOpen] = useState(false);

  const isSuper =
    userProfile?.role === 'super_admin' ||
    firebaseUser?.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const totalQueuedOffline = offlineQueue.length + offlineActivityQueue.length;

  const handleNavSelect = (id: ActiveTab) => {
    setActiveTab(id);
    setMobileDrawerOpen(false);
    setMoreMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col lg:flex-row">
      {/* Desktop Sidebar */}
      <aside className="no-print hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-30">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <svg className="w-7 h-7 shrink-0" viewBox="0 0 512 512" fill="none" aria-hidden="true">
            <rect width="512" height="512" rx="96" fill="#0F172A" />
            <rect x="88" y="112" width="64" height="288" rx="12" fill="#3B82F6" />
            <rect x="360" y="112" width="64" height="288" rx="12" fill="#6366F1" />
            <path d="M152 144L256 272L360 144" stroke="#E2E8F0" strokeWidth="44" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-display font-bold text-base tracking-tight truncate">
            NewOpenlink
          </span>
        </div>

        {/* Active Institution Switcher */}
        <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 space-y-2">
          <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">
            Active Institution
          </label>
          <select
            value={activeInstitution?.id || ''}
            onChange={(e) => selectInstitution(e.target.value)}
            aria-label="Select active institution"
            className="w-full px-2.5 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            {institutions.map((inst) => (
              <option key={inst.id} value={inst.id}>
                {inst.name} ({inst.code})
              </option>
            ))}
          </select>

          <select
            value={selectedBranchFilter}
            onChange={(e) => setSelectedBranchFilter(e.target.value)}
            aria-label="Filter by branch"
            className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Branches ({branches.length})</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.code})
              </option>
            ))}
          </select>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
          {NAV_GROUPS.map((group) => {
            const visibleItems = group.items.filter((item) => !item.superOnly || isSuper);
            if (visibleItems.length === 0) return null;
            return (
              <div key={group.category} className="space-y-1">
                <p className="px-3 text-xs font-semibold text-slate-400 dark:text-slate-500">
                  {group.category}
                </p>
                {visibleItems.map((item) => {
                  const Icon = item.icon;
                  const active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleNavSelect(item.id)}
                      className={`w-full flex items-center justify-between gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        active
                          ? 'bg-indigo-600 text-white'
                          : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span className="flex items-center gap-2.5 truncate">
                        <Icon className="w-4 h-4 shrink-0" />
                        <span className="truncate">{t(language, item.labelKey)}</span>
                      </span>
                      {item.id === 'notifications' && unreadCount > 0 && (
                        <span className="text-xs font-mono tabular-nums font-semibold">
                          {unreadCount}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* User Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <img
            src={firebaseUser?.photoURL || fallbackAvatar}
            alt={firebaseUser?.displayName || 'Administrator'}
            referrerPolicy="no-referrer"
            className="w-9 h-9 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold truncate text-slate-900 dark:text-white">
              {userProfile?.displayName || firebaseUser?.displayName || 'Admin'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
              {ROLE_LABELS[effectiveRole]}
            </p>
          </div>
          <button
            type="button"
            onClick={logout}
            title={t(language, 'sign_out')}
            aria-label="Sign out"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0 pb-16 lg:pb-0">
        {/* Top Horizontal Toolbar */}
        <header className="no-print sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200 dark:border-slate-800">
          <div className="px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
            {/* Left: Mobile Menu + Breadcrumb */}
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(true)}
                aria-label="Open navigation menu"
                className="lg:hidden p-2 -ml-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 min-h-11 min-w-11 flex items-center justify-center"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span className="truncate font-medium text-slate-700 dark:text-slate-200">
                    {activeInstitution?.name || 'NewOpenlink'}
                  </span>
                  <span aria-hidden="true">/</span>
                  <span className="truncate">{t(language, activeTab)}</span>
                </div>
              </div>
            </div>

            {/* Center/Right Horizontal Quick Tools + More Menu */}
            <div className="flex items-center gap-2 shrink-0">
              {previewRole && (
                <button
                  type="button"
                  onClick={() => setPreviewRole(null)}
                  className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>Previewing: {ROLE_LABELS[previewRole]}</span>
                  <X className="w-3.5 h-3.5" />
                </button>
              )}

              {totalQueuedOffline > 0 && (
                <button
                  type="button"
                  onClick={() => triggerServiceWorkerSync()}
                  disabled={!isOnline || isSyncingOffline}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingOffline ? 'animate-spin' : ''}`} />
                  <span className="tabular-nums">{totalQueuedOffline} Pending Sync</span>
                </button>
              )}

              {!isInstalled && isInstallable && (
                <button
                  type="button"
                  onClick={install}
                  className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Install App</span>
                </button>
              )}

              {!isInstalled && !isInstallable && isIOS && (
                <button
                  type="button"
                  onClick={() => setIosModalOpen(true)}
                  className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Install iOS</span>
                </button>
              )}

              <button
                type="button"
                onClick={triggerVoiceAssistant}
                title="Voice AI Assistant"
                aria-label="Open Voice AI Assistant"
                className="inline-flex items-center gap-1.5 px-2.5 py-2 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Mic className="w-4 h-4" />
                <span className="hidden sm:inline">Voice AI</span>
              </button>

              <button
                type="button"
                onClick={() => handleNavSelect('notifications')}
                aria-label="Open notifications"
                className="relative p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 px-1.5 min-w-4 h-4 rounded-md bg-rose-600 text-white text-[10px] font-mono tabular-nums flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={toggleTheme}
                aria-label="Toggle theme"
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              {/* More Tools Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setMoreMenuOpen((v) => !v)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <MoreHorizontal className="w-4 h-4" />
                  <span className="hidden sm:inline">{t(language, 'more')}</span>
                </button>

                {moreMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg py-1.5 z-50">
                    <button
                      type="button"
                      onClick={() => handleNavSelect('users_rbac')}
                      className="w-full px-3.5 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5"
                    >
                      <UserCog className="w-4 h-4 text-slate-500" />
                      <span>Users & Role Permissions</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleNavSelect('backups')}
                      className="w-full px-3.5 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5"
                    >
                      <CloudUpload className="w-4 h-4 text-slate-500" />
                      <span>Backup & Cloud Sync</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleNavSelect('audit')}
                      className="w-full px-3.5 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5"
                    >
                      <FileCheck2 className="w-4 h-4 text-slate-500" />
                      <span>Security Audit Logs</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleNavSelect('settings')}
                      className="w-full px-3.5 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5"
                    >
                      <Settings className="w-4 h-4 text-slate-500" />
                      <span>Settings & Android APK</span>
                    </button>
                    {isSuper && (
                      <button
                        type="button"
                        onClick={() => handleNavSelect('super_admin')}
                        className="w-full px-3.5 py-2 text-left text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5"
                      >
                        <Activity className="w-4 h-4 text-indigo-600" />
                        <span>Super Admin Console</span>
                      </button>
                    )}
                    <div className="my-1 border-t border-slate-200 dark:border-slate-800" />
                    <button
                      type="button"
                      onClick={logout}
                      className="w-full px-3.5 py-2 text-left text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2.5"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{t(language, 'sign_out')}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {!isOnline && (
            <div className="px-4 sm:px-6 py-1.5 bg-amber-500 text-white text-xs font-medium flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <WifiOff className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">
                  {simulatedOffline
                    ? 'Offline Test Mode active — Attendance & activity logs are queuing in IndexedDB for Service Worker sync.'
                    : t(language, 'offline_banner')}
                </span>
              </div>
              {simulatedOffline && (
                <button
                  type="button"
                  onClick={() => setSimulatedOffline(false)}
                  className="px-2.5 py-0.5 rounded bg-white/20 hover:bg-white/30 text-white text-xs font-semibold shrink-0 cursor-pointer"
                >
                  Reconnect &amp; Sync
                </button>
              )}
            </div>
          )}
        </header>

        {/* Main Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-[1440px] w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Mobile Slide-Over Drawer */}
      {mobileDrawerOpen && (
        <div className="no-print fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={() => setMobileDrawerOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] bg-white dark:bg-slate-900 h-full flex flex-col border-r border-slate-200 dark:border-slate-800 z-10">
            <div className="px-4 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <span className="font-display font-bold text-base">NewOpenlink</span>
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(false)}
                className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2">
              <select
                value={activeInstitution?.id || ''}
                onChange={(e) => selectInstitution(e.target.value)}
                className="w-full px-2.5 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
              >
                {institutions.map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name}
                  </option>
                ))}
              </select>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-4">
              {NAV_GROUPS.map((group) => {
                const visibleItems = group.items.filter((i) => !i.superOnly || isSuper);
                if (visibleItems.length === 0) return null;
                return (
                  <div key={group.category} className="space-y-1">
                    <p className="px-3 text-xs font-semibold text-slate-400">{group.category}</p>
                    {visibleItems.map((item) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleNavSelect(item.id)}
                          className={`w-full min-h-11 flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium ${
                            activeTab === item.id
                              ? 'bg-indigo-600 text-white'
                              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                          <span>{t(language, item.labelKey)}</span>
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </nav>
          </div>
        </div>
      )}

      {/* Mobile Bottom Thumb Navigation (<= 15% mobile height) */}
      <nav className="no-print lg:hidden fixed bottom-0 inset-x-0 z-30 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 grid grid-cols-5 h-16">
        {[
          { id: 'dashboard' as ActiveTab, label: 'Home', icon: LayoutDashboard },
          { id: 'attendance' as ActiveTab, label: 'QR Scan', icon: QrCode },
          { id: 'calls' as ActiveTab, label: 'Calls', icon: PhoneCall },
          { id: 'ai_assistant' as ActiveTab, label: 'AI', icon: Bot },
        ].map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavSelect(item.id)}
              className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
                active
                  ? 'text-indigo-600 dark:text-indigo-400'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setMobileDrawerOpen(true)}
          className="flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium text-slate-500 dark:text-slate-400"
        >
          <MoreHorizontal className="w-5 h-5" />
          <span>{t(language, 'more')}</span>
        </button>
      </nav>

      {/* iOS Install Guide Modal */}
      {iosModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-sm rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-3">
            <h3 className="font-display text-lg font-semibold">Install NewOpenlink on iOS</h3>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              1. Tap the Safari <strong>Share</strong> button.<br />
              2. Scroll down and select <strong>Add to Home Screen</strong>.
            </p>
            <button
              type="button"
              onClick={() => setIosModalOpen(false)}
              className="w-full py-2.5 rounded-lg bg-slate-900 dark:bg-indigo-600 text-white text-sm font-medium"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Toast Stack */}
      <div className="no-print fixed bottom-20 lg:bottom-5 right-4 z-50 flex flex-col gap-2 max-w-sm">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`px-4 py-3 rounded-lg border text-xs font-medium shadow-lg flex items-center justify-between gap-3 ${
              toast.tone === 'error'
                ? 'bg-rose-600 text-white border-rose-700'
                : toast.tone === 'success'
                ? 'bg-emerald-600 text-white border-emerald-700'
                : 'bg-slate-900 text-white border-slate-800'
            }`}
          >
            <span>{toast.title}</span>
            <button type="button" onClick={() => dismissToast(toast.id)} className="opacity-80 hover:opacity-100">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
