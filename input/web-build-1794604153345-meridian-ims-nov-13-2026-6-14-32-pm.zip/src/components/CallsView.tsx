import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bot,
  FileAudio,
  Lock,
  Mic,
  Pause,
  PhoneCall,
  PhoneIncoming,
  Plus,
  Search,
  Square,
  Trash2,
  Upload,
  Wand2,
  Info,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { useIMS } from '../context/IMSContext';
import type { CallRecord } from '../types/ims';

interface SipWebhookEvent {
  id: string;
  callerName: string;
  callerNumber: string;
  recipientName: string;
  recipientNumber: string;
  direction: 'inbound' | 'outbound' | 'internal';
  durationSeconds: number;
  pbxTrunk: string;
  consentRecorded: boolean;
  receivedAt: string;
}

export const CallsView: React.FC = () => {
  const {
    activeInstitution,
    branches,
    departments,
    roster,
    calls,
    callCategories,
    effectivePermissions,
    isOnline,
    createCallRecord,
    updateCallRecord,
    deleteCallRecord,
    createCallCategory,
    deleteCallCategory,
    createNotification,
    pushToast,
  } = useIMS();

  const [subTab, setSubTab] = useState<'log' | 'recorder' | 'pbx' | 'categories'>('log');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [selectedCallId, setSelectedCallId] = useState<string | null>(null);

  // Live App Recorder State
  const [callerName, setCallerName] = useState('');
  const [callerNumber, setCallerNumber] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [recipientNumber, setRecipientNumber] = useState('');
  const [direction, setDirection] = useState<CallRecord['direction']>('inbound');
  const [callSource, setCallSource] = useState<CallRecord['callSource']>('app_webrtc');
  const [branchId, setBranchId] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [assignedRosterId, setAssignedRosterId] = useState('');
  const [category, setCategory] = useState('General Inquiry');
  const [consentRecorded, setConsentRecorded] = useState(true);
  const [encryptRecording, setEncryptRecording] = useState(true);
  const [notes, setNotes] = useState('');

  const [recordingState, setRecordingState] = useState<'idle' | 'recording' | 'paused'>('idle');
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [recordedPreviewUrl, setRecordedPreviewUrl] = useState<string | null>(null);
  const [savingCall, setSavingCall] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  // AI Processing State
  const [transcribingId, setTranscribingId] = useState<string | null>(null);
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);

  // SIP Inbox State
  const [sipEvents, setSipEvents] = useState<SipWebhookEvent[]>([]);
  const [loadingSip, setLoadingSip] = useState(false);

  // Recording Vault Sync Verification State
  const [recordingSyncMap, setRecordingSyncMap] = useState<
    Record<string, { synced: boolean; encrypted: boolean; sizeBytes?: number; createdAt?: string }>
  >({});
  const [checkingSync, setCheckingSync] = useState(false);
  const [lastSyncCheckedAt, setLastSyncCheckedAt] = useState<string | null>(null);

  // Custom Category State
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  useEffect(() => {
    if (!branchId && branches.length > 0) setBranchId(branches[0].id);
    if (!departmentId && departments.length > 0) setDepartmentId(departments[0].id);
    if (!category && callCategories.length > 0) setCategory(callCategories[0].name);
  }, [branches, departments, callCategories, branchId, departmentId, category]);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (recordedPreviewUrl) URL.revokeObjectURL(recordedPreviewUrl);
    };
  }, [recordedPreviewUrl]);

  const [editingNotes, setEditingNotes] = useState('');

  const loadSipInbox = async () => {
    if (!isOnline) return;
    setLoadingSip(true);
    try {
      const res = await fetch('/api/telephony/sip-inbox');
      const data = await res.json();
      setSipEvents(data.events || []);
    } catch {
      // ignore
    } finally {
      setLoadingSip(false);
    }
  };

  useEffect(() => {
    if (subTab === 'pbx') loadSipInbox();
  }, [subTab, isOnline]);

  const checkRecordingSyncStatus = async () => {
    const recIds = Array.from(
      new Set(calls.map((c) => c.recordingId).filter((id): id is string => Boolean(id)))
    );
    if (recIds.length === 0 || !isOnline) return;
    setCheckingSync(true);
    try {
      const res = await fetch('/api/recordings/sync-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recordingIds: recIds }),
      });
      if (!res.ok) return;
      const data = (await res.json()) as {
        statuses?: Record<
          string,
          { synced: boolean; encrypted: boolean; sizeBytes?: number; createdAt?: string }
        >;
        checkedAt?: string;
      };
      if (data.statuses) setRecordingSyncMap(data.statuses);
      if (data.checkedAt) setLastSyncCheckedAt(data.checkedAt);
    } catch {
      // ignore transient network check error
    } finally {
      setCheckingSync(false);
    }
  };

  useEffect(() => {
    void checkRecordingSyncStatus();
  }, [calls, isOnline]);

  const startLiveRecording = async () => {
    if (activeInstitution?.recordingConsentRequired && !consentRecorded) {
      pushToast('Recording consent confirmation is required by institutional policy.', 'error');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      mr.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: mr.mimeType || 'audio/webm' });
        setRecordedBlob(blob);
        setRecordedPreviewUrl(URL.createObjectURL(blob));
      };
      mr.start(500);
      mediaRecorderRef.current = mr;
      setRecordingState('recording');
      setElapsedSeconds(0);
      timerRef.current = window.setInterval(() => {
        setElapsedSeconds((s) => s + 1);
      }, 1000);
    } catch (err) {
      pushToast(
        err instanceof Error ? err.message : 'Microphone permission denied.',
        'error'
      );
    }
  };

  const togglePauseRecording = () => {
    const mr = mediaRecorderRef.current;
    if (!mr) return;
    if (recordingState === 'recording') {
      mr.pause();
      if (timerRef.current) clearInterval(timerRef.current);
      setRecordingState('paused');
    } else if (recordingState === 'paused') {
      mr.resume();
      timerRef.current = window.setInterval(() => setElapsedSeconds((s) => s + 1), 1000);
      setRecordingState('recording');
    }
  };

  const stopLiveRecording = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    mediaRecorderRef.current?.stop();
    setRecordingState('idle');
  };

  const handleAudioFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setRecordedBlob(file);
    setCallSource('uploaded_audio');
    if (recordedPreviewUrl) URL.revokeObjectURL(recordedPreviewUrl);
    setRecordedPreviewUrl(URL.createObjectURL(file));
    pushToast(`Loaded audio file "${file.name}".`, 'info');
  };

  const blobToBase64 = (blob: Blob): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(String(reader.result || ''));
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

  const handleSaveCall = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!callerName.trim() || !recipientName.trim()) {
      pushToast('Caller and recipient names are required.', 'error');
      return;
    }

    if (recordedBlob && !isOnline) {
      pushToast('Audio upload & server AES-256-GCM encryption require an active network connection.', 'error');
      return;
    }

    setSavingCall(true);
    try {
      let recordingId: string | undefined;
      let isEnc: boolean | undefined;

      if (recordedBlob) {
        const base64 = await blobToBase64(recordedBlob);
        const upRes = await fetch('/api/recordings/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioBase64: base64,
            mimeType: recordedBlob.type || 'audio/webm',
            encrypt: encryptRecording,
            institutionId: activeInstitution?.id || 'default',
          }),
        });
        const upData = await upRes.json();
        if (!upRes.ok) throw new Error(upData.error || 'Failed to upload recording');
        recordingId = upData.recordingId;
        isEnc = upData.encrypted;
      }

      const assignedMember = roster.find((r) => r.id === assignedRosterId);
      const newCallId = await createCallRecord({
        callerName,
        callerNumber,
        recipientName,
        recipientNumber,
        direction,
        callSource,
        durationSeconds: elapsedSeconds || 60,
        branchId: branchId || undefined,
        departmentId: departmentId || undefined,
        assignedToRosterId: assignedMember?.id,
        assignedToName: assignedMember?.fullName,
        category: category || 'General Inquiry',
        status: 'completed',
        consentRecorded,
        consentNotice: consentRecorded
          ? 'Consent confirmed and logged prior to recording.'
          : 'No audio consent recorded (metadata only).',
        recordingId,
        recordingEncrypted: isEnc,
        notes: notes.trim() || undefined,
      });

      if (assignedMember) {
        await createNotification({
          type: 'assigned_call',
          severity: 'info',
          title: 'New Call Assigned',
          message: `${callerName} → ${recipientName} assigned to ${assignedMember.fullName}.`,
        });
      }

      setCallerName('');
      setCallerNumber('');
      setRecipientName('');
      setRecipientNumber('');
      setNotes('');
      setElapsedSeconds(0);
      setRecordedBlob(null);
      setRecordedPreviewUrl(null);
      setSelectedCallId(newCallId);
      setSubTab('log');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Failed to save call.', 'error');
    } finally {
      setSavingCall(false);
    }
  };

  const handleTranscribeCall = async (call: CallRecord) => {
    if (!isOnline) {
      pushToast('Reconnect to the network to run Gemini audio transcription.', 'error');
      return;
    }
    if (!call.recordingId) {
      pushToast('This call record has no uploaded/recorded audio file attached.', 'info');
      return;
    }
    setTranscribingId(call.id);
    try {
      const res = await fetch('/api/ai/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recordingId: call.recordingId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Transcription failed');
      await updateCallRecord(call.id, { transcript: data.transcript });
      pushToast('Call transcribed with Gemini.', 'success');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Transcription error.', 'error');
    } finally {
      setTranscribingId(null);
    }
  };

  const handleAiAnalyzeCall = async (call: CallRecord) => {
    if (!isOnline) {
      pushToast('Reconnect to the network to run Gemini AI call analysis.', 'error');
      return;
    }
    if (!call.transcript && !call.notes) {
      pushToast('Add notes or transcribe audio before running AI summarization.', 'info');
      return;
    }
    setAnalyzingId(call.id);
    try {
      const res = await fetch('/api/ai/analyze-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerName: call.callerName,
          recipientName: call.recipientName,
          transcript: call.transcript,
          notes: call.notes,
          availableCategories: callCategories.map((c) => c.name),
          availableDepartments: departments.map((d) => d.name),
          model: activeInstitution?.aiModel,
          provider: activeInstitution?.aiProvider,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI analysis failed');
      const keyPointsText = Array.isArray(data.keyPoints) && data.keyPoints.length > 0
        ? `\nKey Points:\n• ${data.keyPoints.join('\n• ')}`
        : '';
      await updateCallRecord(call.id, {
        aiSummary: `${data.summary || ''}${keyPointsText}`.trim().slice(0, 3900),
        aiSuggestedCategory: data.suggestedCategory || call.category,
      });
      pushToast('AI summary & category suggestion generated.', 'success');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'AI analysis error.', 'error');
    } finally {
      setAnalyzingId(null);
    }
  };

  const simulateSipWebhook = async () => {
    if (!isOnline) {
      pushToast('SIP webhook simulation requires an active server connection.', 'error');
      return;
    }
    try {
      const res = await fetch('/api/telephony/sip-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerName: 'External Admissions Inquiry',
          callerNumber: '+44 20 7946 0994',
          recipientName: 'Main PBX Reception',
          recipientNumber: 'SIP/100',
          direction: 'inbound',
          durationSeconds: 195,
          pbxTrunk: 'Asterisk-EU-West-01',
          consentRecorded: true,
        }),
      });
      if (res.ok) {
        pushToast('Test PBX/SIP webhook received by server.', 'success');
        await loadSipInbox();
      }
    } catch {
      pushToast('Failed to send test SIP webhook.', 'error');
    }
  };

  const importSipEvent = async (ev: SipWebhookEvent) => {
    await createCallRecord({
      callerName: ev.callerName,
      callerNumber: ev.callerNumber,
      recipientName: ev.recipientName,
      recipientNumber: ev.recipientNumber,
      direction: ev.direction,
      callSource: 'pbx_sip',
      durationSeconds: ev.durationSeconds,
      branchId: branches[0]?.id,
      departmentId: departments[0]?.id,
      category: callCategories[0]?.name || 'General Inquiry',
      status: 'completed',
      consentRecorded: ev.consentRecorded,
      consentNotice: `Captured via ${ev.pbxTrunk} SIP Trunk`,
      notes: `Imported from PBX webhook ${ev.id}`,
    });
    setSubTab('log');
  };

  const filteredCalls = useMemo(() => {
    return calls.filter((c) => {
      if (categoryFilter !== 'all' && c.category !== categoryFilter) return false;
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (departmentFilter !== 'all' && (c.departmentId || '') !== departmentFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          c.callerName.toLowerCase().includes(q) ||
          c.recipientName.toLowerCase().includes(q) ||
          (c.transcript || '').toLowerCase().includes(q) ||
          (c.aiSummary || '').toLowerCase().includes(q) ||
          c.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [calls, categoryFilter, statusFilter, departmentFilter, searchQuery]);

  const selectedCall = useMemo(
    () => calls.find((c) => c.id === selectedCallId) || filteredCalls[0] || null,
    [calls, filteredCalls, selectedCallId]
  );

  useEffect(() => {
    setEditingNotes(selectedCall?.notes || '');
  }, [selectedCall?.id, selectedCall?.notes]);

  if (!effectivePermissions.canAccessRecordings) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center space-y-3">
        <Lock className="w-8 h-8 text-slate-400 mx-auto" />
        <h2 className="font-display text-lg font-semibold">Restricted Call Recording Access</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
          Your current role does not include permission to access institutional call records or encrypted audio recordings.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Call Management &amp; Recording</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Encrypted call archival, PBX/SIP webhooks, in-app VoIP capture, and Gemini AI transcription.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-lg self-start">
          {[
            { id: 'log' as const, label: 'Call History' },
            { id: 'recorder' as const, label: 'Record / Upload Call' },
            { id: 'pbx' as const, label: 'PBX / SIP Bridge' },
            { id: 'categories' as const, label: 'Categories' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSubTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subTab === tab.id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Honest Android & OS Recording Compliance Notice */}
      <div className="p-4 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 flex items-start gap-3">
        <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-700 dark:text-slate-300 space-y-1">
          <p className="font-semibold text-slate-900 dark:text-white">
            Supported Recording Architecture &amp; Android Device Restrictions
          </p>
          <p>
            Android 10+ and iOS restrict third-party apps from capturing ordinary cellular SIM voice streams directly. NewOpenlink records supported channels cleanly: <strong>(1) App-to-App WebRTC/VoIP calls</strong>, <strong>(2) Institutional PBX / SIP Trunk server recordings</strong>, <strong>(3) Uploaded device audio files</strong>, and <strong>(4) Native Android Companion Bridge</strong> via Telecom <code className="font-mono">InCallService</code> where carrier/OS policy permits.
          </p>
        </div>
      </div>

      {/* CALL HISTORY & AI DETAIL VIEW */}
      {subTab === 'log' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search caller, transcript, AI summary..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  <option value="all">All Categories ({calls.length})</option>
                  {callCategories.map((cat) => (
                    <option key={cat.id} value={cat.name}>
                      {cat.name}
                    </option>
                  ))}
                </select>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  <option value="all">All Statuses</option>
                  <option value="completed">Completed</option>
                  <option value="follow_up">Follow Up</option>
                  <option value="escalated">Escalated</option>
                  <option value="missed">Missed</option>
                  <option value="archived">Archived</option>
                </select>
                <select
                  value={departmentFilter}
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  <option value="all">All Depts</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
              {(() => {
                const audioCalls = calls.filter((c) => Boolean(c.recordingId));
                const verifiedCount = audioCalls.filter(
                  (c) => c.recordingId && recordingSyncMap[c.recordingId]?.synced
                ).length;
                return (
                  <span className="text-slate-600 dark:text-slate-300 tabular-nums">
                    Recording Sync:{' '}
                    <strong>
                      {isOnline ? `${verifiedCount}/${audioCalls.length} Vault Verified` : 'Offline'}
                    </strong>
                  </span>
                );
              })()}
              <button
                type="button"
                onClick={() => void checkRecordingSyncStatus()}
                disabled={!isOnline || checkingSync}
                className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:underline disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${checkingSync ? 'animate-spin' : ''}`} />
                <span>{checkingSync ? 'Verifying...' : 'Verify Sync'}</span>
              </button>
            </div>

            <div className="divide-y divide-slate-200 dark:divide-slate-800 max-h-[560px] overflow-y-auto">
              {filteredCalls.map((call) => {
                const active = selectedCall?.id === call.id;
                const syncInfo = call.recordingId ? recordingSyncMap[call.recordingId] : undefined;
                return (
                  <button
                    key={call.id}
                    type="button"
                    onClick={() => setSelectedCallId(call.id)}
                    className={`w-full text-left p-4 transition-colors cursor-pointer ${
                      active
                        ? 'bg-indigo-50/70 dark:bg-indigo-950/40'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {call.callerName} → {call.recipientName}
                      </p>
                      <span className="text-xs font-mono tabular-nums text-slate-500 shrink-0">
                        {Math.floor(call.durationSeconds / 60)}m {call.durationSeconds % 60}s
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                      <span>{call.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="uppercase font-mono text-[11px]">{call.callSource.replace('_', ' ')}</span>
                      <span aria-hidden="true">·</span>
                      {call.recordingId ? (
                        !isOnline ? (
                          <span className="text-amber-600 dark:text-amber-400">Offline (Check Paused)</span>
                        ) : syncInfo?.synced ? (
                          <span className="text-emerald-600 dark:text-emerald-400">Vault Synced</span>
                        ) : syncInfo && !syncInfo.synced ? (
                          <span className="text-rose-600 dark:text-rose-400">Audio Unsynced</span>
                        ) : (
                          <span className="text-indigo-600 dark:text-indigo-400">Audio Attached</span>
                        )
                      ) : (
                        <span>Metadata Synced</span>
                      )}
                    </div>
                  </button>
                );
              })}
              {filteredCalls.length === 0 && (
                <p className="p-8 text-center text-xs text-slate-400">
                  No matching calls found. Record or log a call to get started.
                </p>
              )}
            </div>
          </div>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
            {selectedCall ? (
              <>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <h2 className="font-display text-lg font-bold">
                      {selectedCall.callerName} → {selectedCall.recipientName}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      {new Date(selectedCall.startedAtIso).toLocaleString()} · {selectedCall.direction} ·{' '}
                      {selectedCall.consentRecorded ? 'Consent Verified' : 'Metadata Only'}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {selectedCall.recordingId && (
                      <button
                        type="button"
                        onClick={() => handleTranscribeCall(selectedCall)}
                        disabled={transcribingId === selectedCall.id}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white text-xs font-medium cursor-pointer"
                      >
                        <FileAudio className="w-3.5 h-3.5" />
                        <span>
                          {transcribingId === selectedCall.id ? 'Transcribing...' : 'Transcribe Audio'}
                        </span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleAiAnalyzeCall(selectedCall)}
                      disabled={analyzingId === selectedCall.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 text-xs font-medium cursor-pointer"
                    >
                      <Wand2 className="w-3.5 h-3.5" />
                      <span>{analyzingId === selectedCall.id ? 'Analyzing...' : 'AI Summarize'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteCallRecord(selectedCall.id)}
                      aria-label="Delete call"
                      className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Audio Player + Sync Status */}
                {selectedCall.recordingId ? (
                  (() => {
                    const sync = recordingSyncMap[selectedCall.recordingId];
                    const kb = sync?.sizeBytes ? `${Math.max(1, Math.round(sync.sizeBytes / 1024))} KB` : null;
                    return (
                      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                          <span className="font-medium flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5 text-emerald-600" />
                            {selectedCall.recordingEncrypted
                              ? 'AES-256-GCM Encrypted Server Recording'
                              : 'Stored Recording'}
                          </span>
                          <div className="flex items-center gap-2">
                            {!isOnline ? (
                              <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                                <AlertCircle className="w-3.5 h-3.5" />
                                <span>Offline — Vault Unverified</span>
                              </span>
                            ) : sync?.synced ? (
                              <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Synced to Vault{kb ? ` (${kb})` : ''}</span>
                              </span>
                            ) : sync && !sync.synced ? (
                              <span className="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400 font-medium">
                                <AlertCircle className="w-3.5 h-3.5" />
                                <span>Audio File Missing on Vault</span>
                              </span>
                            ) : (
                              <span className="text-slate-400">Checking sync...</span>
                            )}
                            <span className="font-mono text-slate-400">{selectedCall.recordingId}</span>
                          </div>
                        </div>
                        <audio
                          controls
                          src={`/api/recordings/${selectedCall.recordingId}`}
                          className="w-full h-10"
                        />
                        {lastSyncCheckedAt && (
                          <p className="text-[11px] font-mono text-slate-400">
                            Sync verified: {new Date(lastSyncCheckedAt).toLocaleTimeString()}
                          </p>
                        )}
                      </div>
                    );
                  })()
                ) : (
                  <div className="px-3.5 py-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                    <span>Call metadata synced to Firestore (no audio stream attached).</span>
                    <span className="font-mono text-emerald-600 dark:text-emerald-400">Metadata Synced</span>
                  </div>
                )}

                {/* Routing & Reassignment Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Status</label>
                    <select
                      value={selectedCall.status}
                      onChange={async (e) => {
                        const nextStatus = e.target.value as CallRecord['status'];
                        await updateCallRecord(selectedCall.id, {
                          status: nextStatus,
                        });
                        if (nextStatus === 'escalated') {
                          await createNotification({
                            type: 'important_call',
                            severity: 'urgent',
                            title: 'Escalated Call Alert',
                            message: `${selectedCall.callerName} → ${selectedCall.recipientName} (${selectedCall.category}) marked as escalated.`,
                          });
                        }
                      }}
                      className="w-full px-2.5 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                    >
                      <option value="completed">Completed</option>
                      <option value="follow_up">Follow Up</option>
                      <option value="escalated">Escalated</option>
                      <option value="missed">Missed</option>
                      <option value="archived">Archived</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Category</label>
                    <select
                      value={selectedCall.category}
                      onChange={(e) => updateCallRecord(selectedCall.id, { category: e.target.value })}
                      className="w-full px-2.5 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                    >
                      {callCategories.map((cat) => (
                        <option key={cat.id} value={cat.name}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Department</label>
                    <select
                      value={selectedCall.departmentId || ''}
                      onChange={(e) => updateCallRecord(selectedCall.id, { departmentId: e.target.value })}
                      className="w-full px-2.5 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                    >
                      <option value="">Unassigned</option>
                      {departments.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Assigned Staff</label>
                    <select
                      value={selectedCall.assignedToRosterId || ''}
                      onChange={async (e) => {
                        const member = roster.find((r) => r.id === e.target.value);
                        await updateCallRecord(selectedCall.id, {
                          assignedToRosterId: e.target.value,
                          assignedToName: member?.fullName || '',
                        });
                        if (member) {
                          await createNotification({
                            type: 'assigned_call',
                            severity: 'info',
                            title: 'Call Assigned to Staff',
                            message: `${selectedCall.callerName} → ${selectedCall.recipientName} assigned to ${member.fullName}.`,
                          });
                        }
                      }}
                      className="w-full px-2.5 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                    >
                      <option value="">Unassigned</option>
                      {roster.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.fullName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* AI Summary & Suggested Category */}
                {selectedCall.aiSummary && (
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
                        <Bot className="w-4 h-4" />
                        Gemini AI Summary
                      </span>
                      {selectedCall.aiSuggestedCategory &&
                        selectedCall.aiSuggestedCategory !== selectedCall.category && (
                          <button
                            type="button"
                            onClick={() =>
                              updateCallRecord(selectedCall.id, {
                                category: selectedCall.aiSuggestedCategory,
                              })
                            }
                            className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                          >
                            Apply suggested: {selectedCall.aiSuggestedCategory}
                          </button>
                        )}
                    </div>
                    <p className="text-xs leading-relaxed whitespace-pre-line text-slate-700 dark:text-slate-200">
                      {selectedCall.aiSummary}
                    </p>
                  </div>
                )}

                {/* Transcript */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Call Transcript
                  </label>
                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs leading-relaxed whitespace-pre-line max-h-48 overflow-y-auto">
                    {selectedCall.transcript || 'No transcript yet. Click "Transcribe Audio" on recorded calls.'}
                  </div>
                </div>

                {/* Notes */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Operator Notes
                    </label>
                    {editingNotes !== (selectedCall.notes || '') && (
                      <button
                        type="button"
                        onClick={() => updateCallRecord(selectedCall.id, { notes: editingNotes.trim() })}
                        className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                      >
                        Save Notes
                      </button>
                    )}
                  </div>
                  <textarea
                    rows={2}
                    value={editingNotes}
                    onChange={(e) => setEditingNotes(e.target.value)}
                    placeholder="Add operator notes or follow-up details..."
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
              </>
            ) : (
              <div className="py-16 text-center text-sm text-slate-400">
                Select a call record from the left list or create a new recording.
              </div>
            )}
          </div>
        </div>
      )}

      {/* LIVE RECORDER & UPLOAD VIEW */}
      {subTab === 'recorder' && (
        <form
          onSubmit={handleSaveCall}
          className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6"
        >
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-base font-semibold">Audio Capture &amp; Upload</h2>
              {activeInstitution?.autoRecordSupportedCalls && (
                <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
                  Auto-Record Enabled
                </span>
              )}
            </div>

            <div className="p-5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-4 text-center">
              <p className="font-mono text-3xl font-bold tabular-nums">
                {String(Math.floor(elapsedSeconds / 60)).padStart(2, '0')}:
                {String(elapsedSeconds % 60).padStart(2, '0')}
              </p>

              <div className="flex flex-wrap items-center justify-center gap-2">
                {recordingState === 'idle' ? (
                  <>
                    <button
                      type="button"
                      onClick={startLiveRecording}
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-medium cursor-pointer"
                    >
                      <Mic className="w-4 h-4" />
                      <span>Start In-App Recording</span>
                    </button>
                    {activeInstitution?.autoRecordSupportedCalls && (
                      <button
                        type="button"
                        onClick={() => {
                          setCallSource('app_webrtc');
                          void startLiveRecording();
                        }}
                        className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium cursor-pointer"
                      >
                        <PhoneCall className="w-4 h-4" />
                        <span>Start App-to-App Call (Auto-Record)</span>
                      </button>
                    )}
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={togglePauseRecording}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-600 text-white text-xs font-medium cursor-pointer"
                    >
                      <Pause className="w-4 h-4" />
                      <span>{recordingState === 'paused' ? 'Resume' : 'Pause'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={stopLiveRecording}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900 dark:bg-indigo-600 text-white text-xs font-medium cursor-pointer"
                    >
                      <Square className="w-4 h-4" />
                      <span>Stop</span>
                    </button>
                  </>
                )}
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-900 text-xs font-medium cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>Upload Audio File (.mp3, .wav, .webm)</span>
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={handleAudioFileUpload}
                    className="hidden"
                  />
                </label>
              </div>

              {recordedPreviewUrl && (
                <div className="pt-2">
                  <audio controls src={recordedPreviewUrl} className="w-full h-10" />
                </div>
              )}
            </div>

            <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={consentRecorded}
                onChange={(e) => setConsentRecorded(e.target.checked)}
                className="mt-0.5 rounded text-indigo-600"
              />
              <span className="text-xs text-slate-600 dark:text-slate-300">
                Legal recording consent notice delivered and acknowledged by call participants.
              </span>
            </label>

            <label className="flex items-start gap-2.5 p-3 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={encryptRecording}
                onChange={(e) => setEncryptRecording(e.target.checked)}
                className="mt-0.5 rounded text-indigo-600"
              />
              <span className="text-xs text-slate-600 dark:text-slate-300">
                Encrypt audio stream at rest using server-side AES-256-GCM vault.
              </span>
            </label>
          </div>

          <div className="lg:col-span-7 space-y-4">
            <h2 className="font-display text-base font-semibold">Call Metadata &amp; Assignment</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1">Caller Name</label>
                <input
                  type="text"
                  required
                  value={callerName}
                  onChange={(e) => setCallerName(e.target.value)}
                  placeholder="Dr. Grace Mensah"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Caller Number / SIP URI</label>
                <input
                  type="text"
                  value={callerNumber}
                  onChange={(e) => setCallerNumber(e.target.value)}
                  placeholder="+44 20 7946 0112"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Recipient Name</label>
                <input
                  type="text"
                  required
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  placeholder="Admissions Desk"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Recipient Extension</label>
                <input
                  type="text"
                  value={recipientNumber}
                  onChange={(e) => setRecipientNumber(e.target.value)}
                  placeholder="Ext 204"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1">Direction</label>
                <select
                  value={direction}
                  onChange={(e) => setDirection(e.target.value as CallRecord['direction'])}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  <option value="inbound">Inbound</option>
                  <option value="outbound">Outbound</option>
                  <option value="internal">Internal</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Call Channel</label>
                <select
                  value={callSource}
                  onChange={(e) => setCallSource(e.target.value as CallRecord['callSource'])}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  <option value="app_webrtc">App-to-App / WebRTC</option>
                  <option value="pbx_sip">Institutional PBX / SIP</option>
                  <option value="android_sim_bridge">Android SIM Companion</option>
                  <option value="uploaded_audio">Uploaded Audio File</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  {callCategories.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                  {callCategories.length === 0 && <option value="General Inquiry">General Inquiry</option>}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1">Branch</label>
                <select
                  value={branchId}
                  onChange={(e) => setBranchId(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Department</label>
                <select
                  value={departmentId}
                  onChange={(e) => setDepartmentId(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Assign Employee</label>
                <select
                  value={assignedRosterId}
                  onChange={(e) => setAssignedRosterId(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  <option value="">Unassigned</option>
                  {roster.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.fullName}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium mb-1">Call Notes</label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Key context, caller request, or follow-up instructions..."
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>

            <button
              type="submit"
              disabled={savingCall}
              className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white text-sm font-medium cursor-pointer"
            >
              {savingCall ? 'Encrypting & Saving Call Record...' : 'Save Call Record & Recording'}
            </button>
          </div>
        </form>
      )}

      {/* PBX / SIP WEBHOOK INTEGRATION VIEW */}
      {subTab === 'pbx' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-base font-semibold">Institutional PBX / SIP Trunk Webhook</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Point Asterisk, FreePBX, 3CX, or Twilio CDR webhooks to <code className="font-mono">POST /api/telephony/sip-webhook</code>.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={simulateSipWebhook}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
              >
                <PhoneIncoming className="w-3.5 h-3.5" />
                <span>Simulate Incoming SIP Event</span>
              </button>
              <button
                type="button"
                onClick={loadSipInbox}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${loadingSip ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
            {sipEvents.map((ev) => (
              <div key={ev.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold">
                    {ev.callerName} ({ev.callerNumber}) → {ev.recipientName}
                  </p>
                  <p className="text-xs text-slate-500 font-mono">
                    Trunk: {ev.pbxTrunk} · {ev.durationSeconds}s · {new Date(ev.receivedAt).toLocaleString()}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => importSipEvent(ev)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium self-start cursor-pointer"
                >
                  Import to Call Log
                </button>
              </div>
            ))}
            {sipEvents.length === 0 && (
              <p className="p-8 text-center text-xs text-slate-400">
                No PBX/SIP webhook events received yet. Click &ldquo;Simulate Incoming SIP Event&rdquo; to test the endpoint.
              </p>
            )}
          </div>
        </div>
      )}

      {/* CUSTOM CALL CATEGORIES */}
      {subTab === 'categories' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (newCatName.trim().length < 2) return;
              await createCallCategory({ name: newCatName, description: newCatDesc });
              setNewCatName('');
              setNewCatDesc('');
            }}
            className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3"
          >
            <h2 className="font-display text-base font-semibold">Create Call Category</h2>
            <div>
              <label className="block text-xs font-medium mb-1">Category Name</label>
              <input
                type="text"
                required
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                placeholder="e.g. Financial Aid"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Routing Description</label>
              <input
                type="text"
                value={newCatDesc}
                onChange={(e) => setNewCatDesc(e.target.value)}
                placeholder="Tuition & billing inquiries"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Category</span>
            </button>
          </form>

          <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
            {callCategories.map((cat) => (
              <div key={cat.id} className="p-4 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold">{cat.name}</p>
                  <p className="text-xs text-slate-500">{cat.description || 'Custom institutional routing category'}</p>
                </div>
                <button
                  type="button"
                  onClick={() => deleteCallCategory(cat.id)}
                  className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
