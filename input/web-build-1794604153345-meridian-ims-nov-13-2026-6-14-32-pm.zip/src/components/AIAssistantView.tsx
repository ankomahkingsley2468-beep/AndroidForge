import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Bot,
  CheckCircle2,
  Mic,
  MicOff,
  Send,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Square,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { todayDateKey, useIMS } from '../context/IMSContext';
import { ROLE_LABELS, type ActiveTab } from '../types/ims';

interface ChatTurn {
  role: 'user' | 'assistant';
  text: string;
  viaVoice?: boolean;
  actionTaken?: string;
  guardBlocked?: boolean;
}

interface AttendanceAnalysis {
  headline: string;
  overallHealth: string;
  anomalies: string[];
  recommendations: string[];
}

type VoicePhase = 'idle' | 'listening' | 'processing' | 'speaking';

interface PendingVoiceAction {
  action: string;
  tab?: ActiveTab;
  label: string;
  spokenCommand: string;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
}

const ACTION_TO_TAB: Record<
  string,
  { tab: ActiveTab; label: string; requiredPermission?: 'attendance' | 'calls' | 'reports' | 'admin' }
> = {
  navigate_attendance: { tab: 'attendance', label: 'QR Attendance', requiredPermission: 'attendance' },
  navigate_calls: { tab: 'calls', label: 'Call Management', requiredPermission: 'calls' },
  navigate_reports: { tab: 'reports', label: 'Reports & Analytics', requiredPermission: 'reports' },
  navigate_notifications: { tab: 'notifications', label: 'Notifications' },
  navigate_backups: { tab: 'backups', label: 'Backups & Sync', requiredPermission: 'admin' },
  navigate_settings: { tab: 'settings', label: 'Settings', requiredPermission: 'admin' },
  navigate_dashboard: { tab: 'dashboard', label: 'Dashboard' },
};

export const AIAssistantView: React.FC = () => {
  const {
    activeInstitution,
    branches,
    departments,
    roster,
    attendance,
    calls,
    notifications,
    offlineQueue,
    effectiveRole,
    effectivePermissions,
    isOnline,
    setActiveTab,
    voiceLaunchRequested,
    logAudit,
    pushToast,
  } = useIMS();

  const [messages, setMessages] = useState<ChatTurn[]>([
    {
      role: 'assistant',
      text: `Ready to assist with ${activeInstitution?.name || 'your institution'}. Type a question or tap the microphone for hands-free voice commands like "Summarize today's calls" or "Check attendance status".`,
    },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);

  const [analysis, setAnalysis] = useState<AttendanceAnalysis | null>(null);
  const [analyzingAttendance, setAnalyzingAttendance] = useState(false);

  // Voice Control & Guard State
  const [voicePhase, setVoicePhase] = useState<VoicePhase>('idle');
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [confirmActionsGuard, setConfirmActionsGuard] = useState(true);
  const [pendingVoiceAction, setPendingVoiceAction] = useState<PendingVoiceAction | null>(null);
  const [liveCaption, setLiveCaption] = useState('');
  const [audioLevels, setAudioLevels] = useState<number[]>([15, 22, 18, 28, 20, 25, 16, 20]);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const liveCaptionRef = useRef<string>('');
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const cancelledRef = useRef(false);
  const lastHandledLaunchRef = useRef(0);

  const isAdminTier =
    ['super_admin', 'institution_admin', 'branch_admin'].includes(effectiveRole) ||
    effectivePermissions.canChangeSettings;

  // RBAC-scoped context snapshot so Voice / Text AI strictly honors role permissions
  const contextSnapshot = useMemo(() => {
    const today = todayDateKey();
    const canAtt = effectivePermissions.canViewAttendance;
    const canCalls = effectivePermissions.canAccessRecordings;

    const todayAtt = canAtt ? attendance.filter((a) => a.dateKey === today) : [];
    const activeMembers = roster.filter((r) => r.status === 'active');
    const offlineToday = canAtt
      ? offlineQueue.filter(
          (q) =>
            q.dateKey === today &&
            q.action === 'check_in' &&
            !todayAtt.some((a) => a.rosterId === q.rosterId)
        )
      : [];
    const presentCount = todayAtt.length + offlineToday.length;
    const lateCount =
      todayAtt.filter((a) => a.status === 'late').length +
      offlineToday.filter((q) => q.status === 'late').length;

    return {
      todayDateKey: today,
      actorRole: effectiveRole,
      permissions: {
        canViewAttendance: canAtt,
        canAccessRecordings: canCalls,
        canGenerateReports: effectivePermissions.canGenerateReports,
        canChangeSettings: effectivePermissions.canChangeSettings,
      },
      institution: {
        name: activeInstitution?.name,
        type: activeInstitution?.type,
        workStartTime: activeInstitution?.workStartTime,
      },
      counts: {
        branches: branches.length,
        departments: departments.length,
        activeRoster: activeMembers.length,
        ...(canAtt
          ? {
              presentToday: presentCount,
              absentToday: Math.max(0, activeMembers.length - presentCount),
              lateToday: lateCount,
              attendanceRatePercent:
                activeMembers.length > 0 ? Math.round((presentCount / activeMembers.length) * 100) : 0,
            }
          : { attendanceRedactedByRbac: true }),
        ...(canCalls
          ? {
              totalCalls: calls.length,
              todayCalls: calls.filter((c) => c.startedAtIso.slice(0, 10) === today).length,
            }
          : { callsRedactedByRbac: true }),
        unreadNotifications: notifications.filter((n) => !n.isRead).length,
      },
      branches: branches.map((b) => ({ name: b.name, code: b.code, city: b.city })),
      departments: departments.map((d) => ({ name: d.name, code: d.code, headName: d.headName })),
      recentAttendance: canAtt
        ? attendance.slice(0, 25).map((a) => ({
            memberName: a.memberName,
            memberCode: a.memberCode,
            dateKey: a.dateKey,
            status: a.status,
            checkInIso: a.checkInIso,
          }))
        : [],
      recentCalls: canCalls
        ? calls.slice(0, 20).map((c) => ({
            callerName: c.callerName,
            recipientName: c.recipientName,
            category: c.category,
            status: c.status,
            startedAtIso: c.startedAtIso,
            durationSeconds: c.durationSeconds,
            aiSummary: c.aiSummary,
            notes: c.notes,
          }))
        : [],
    };
  }, [
    activeInstitution,
    branches,
    departments,
    roster,
    attendance,
    calls,
    notifications,
    offlineQueue,
    effectiveRole,
    effectivePermissions,
  ]);

  const checkVoiceActionPermission = useCallback(
    (action: string): { allowed: boolean; reason?: string } => {
      if (action === 'run_attendance_scan') {
        if (!effectivePermissions.canViewAttendance) {
          return {
            allowed: false,
            reason: `Role "${ROLE_LABELS[effectiveRole]}" does not have permission to run Attendance Anomaly Scans.`,
          };
        }
        return { allowed: true };
      }
      const target = ACTION_TO_TAB[action];
      if (!target) return { allowed: true };

      if (
        target.requiredPermission === 'attendance' &&
        !effectivePermissions.canViewAttendance &&
        !effectivePermissions.canCreateQrCodes
      ) {
        return {
          allowed: false,
          reason: `Role "${ROLE_LABELS[effectiveRole]}" cannot access QR Attendance modules.`,
        };
      }
      if (target.requiredPermission === 'calls' && !effectivePermissions.canAccessRecordings) {
        return {
          allowed: false,
          reason: `Role "${ROLE_LABELS[effectiveRole]}" cannot access Call Recordings.`,
        };
      }
      if (target.requiredPermission === 'reports' && !effectivePermissions.canGenerateReports) {
        return {
          allowed: false,
          reason: `Role "${ROLE_LABELS[effectiveRole]}" cannot access Reports & Analytics.`,
        };
      }
      if (target.requiredPermission === 'admin' && !isAdminTier) {
        return {
          allowed: false,
          reason: `Voice Guard restricted "${target.label}" to administrators.`,
        };
      }
      return { allowed: true };
    },
    [effectivePermissions, effectiveRole, isAdminTier]
  );

  const stopSpeechPlayback = useCallback(() => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setVoicePhase((prev) => (prev === 'speaking' ? 'idle' : prev));
  }, []);

  const speakResponse = useCallback(
    async (text: string) => {
      const clean = text.replace(/\s+/g, ' ').trim();
      if (!clean) return;
      stopSpeechPlayback();
      setVoicePhase('speaking');

      const fallbackBrowserSpeech = () => {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          const utter = new SpeechSynthesisUtterance(clean.slice(0, 700));
          utter.rate = 1.02;
          utter.onend = () => setVoicePhase((p) => (p === 'speaking' ? 'idle' : p));
          utter.onerror = () => setVoicePhase((p) => (p === 'speaking' ? 'idle' : p));
          window.speechSynthesis.speak(utter);
        } else {
          setVoicePhase('idle');
        }
      };

      if (!isOnline) {
        fallbackBrowserSpeech();
        return;
      }

      try {
        const res = await fetch('/api/ai/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: clean.slice(0, 900) }),
        });
        if (!res.ok) {
          fallbackBrowserSpeech();
          return;
        }
        const data = (await res.json()) as { audioBase64?: string; mimeType?: string };
        if (!data.audioBase64) {
          fallbackBrowserSpeech();
          return;
        }
        const audio = new Audio(`data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`);
        audioPlayerRef.current = audio;
        audio.onended = () => setVoicePhase((p) => (p === 'speaking' ? 'idle' : p));
        audio.onerror = () => fallbackBrowserSpeech();
        await audio.play();
      } catch {
        fallbackBrowserSpeech();
      }
    },
    [isOnline, stopSpeechPlayback]
  );

  const runAttendanceAnomalyScan = useCallback(async () => {
    if (!effectivePermissions.canViewAttendance) {
      pushToast('Voice Guard: Attendance permission required for anomaly scan.', 'error');
      return;
    }
    if (!isOnline) {
      pushToast('Reconnect to the network to run Gemini attendance pattern analysis.', 'error');
      return;
    }
    setAnalyzingAttendance(true);
    try {
      const res = await fetch('/api/ai/analyze-attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          summaryPayload: {
            workStartTime: activeInstitution?.workStartTime,
            totalActiveRoster: roster.filter((r) => r.status === 'active').length,
            branches: contextSnapshot.branches,
            attendanceRecords: contextSnapshot.recentAttendance,
          },
          model: activeInstitution?.aiModel,
          provider: activeInstitution?.aiProvider,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Attendance analysis failed.');
      setAnalysis(data);
      pushToast('Attendance pattern analysis complete.', 'success');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Analysis failed.', 'error');
    } finally {
      setAnalyzingAttendance(false);
    }
  }, [
    effectivePermissions.canViewAttendance,
    activeInstitution,
    roster,
    contextSnapshot,
    isOnline,
    pushToast,
  ]);

  const executeVoiceAction = useCallback(
    (
      action: string | undefined,
      spokenCommand: string
    ): { actionTaken?: string; guardBlocked?: boolean; guardMessage?: string } => {
      if (!action || action === 'answer_only') return {};

      const perm = checkVoiceActionPermission(action);
      if (!perm.allowed) {
        const msg = perm.reason || 'Voice command blocked by role permissions.';
        pushToast(`Voice Guard: ${msg}`, 'error');
        void logAudit('Voice Guard Blocked', 'voice_command', action, `${spokenCommand} — ${msg}`);
        return {
          actionTaken: 'Blocked by Voice Guard',
          guardBlocked: true,
          guardMessage: msg,
        };
      }

      if (action === 'run_attendance_scan') {
        if (confirmActionsGuard) {
          setPendingVoiceAction({
            action,
            label: 'Run Attendance Anomaly Scan',
            spokenCommand,
          });
          return { actionTaken: 'Awaiting Guard Confirmation' };
        }
        void runAttendanceAnomalyScan();
        return { actionTaken: 'Attendance Anomaly Scan triggered' };
      }

      const target = ACTION_TO_TAB[action];
      if (target) {
        if (confirmActionsGuard) {
          setPendingVoiceAction({
            action,
            tab: target.tab,
            label: `Open ${target.label}`,
            spokenCommand,
          });
          return { actionTaken: `Awaiting Confirmation: ${target.label}` };
        }
        pushToast(`Voice command: Opening ${target.label}`, 'info');
        setTimeout(() => setActiveTab(target.tab), 1100);
        return { actionTaken: `Opened ${target.label}` };
      }
      return {};
    },
    [checkVoiceActionPermission, confirmActionsGuard, logAudit, pushToast, runAttendanceAnomalyScan, setActiveTab]
  );

  const confirmPendingVoiceAction = () => {
    if (!pendingVoiceAction) return;
    const item = pendingVoiceAction;
    setPendingVoiceAction(null);
    if (item.action === 'run_attendance_scan') {
      void runAttendanceAnomalyScan();
    } else if (item.tab) {
      setActiveTab(item.tab);
    }
    void logAudit('Voice Action Confirmed', 'voice_command', item.action, item.spokenCommand);
  };

  const cleanupListeningHardware = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (speechRecRef.current) {
      try {
        speechRecRef.current.stop();
      } catch {
        // ignore
      }
      speechRecRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => undefined);
      audioCtxRef.current = null;
    }
    setAudioLevels([15, 22, 18, 28, 20, 25, 16, 20]);
  }, []);

  useEffect(() => {
    return () => {
      cleanupListeningHardware();
      stopSpeechPlayback();
    };
  }, [cleanupListeningHardware, stopSpeechPlayback]);

  const blobToBase64 = (blob: Blob): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(String(reader.result || ''));
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

  const submitVoicePayload = useCallback(
    async (payload: { audioBlob?: Blob; transcriptText?: string }) => {
      if (!isOnline) {
        pushToast('Voice AI Assistant requires an active network connection.', 'error');
        setVoicePhase('idle');
        return;
      }

      setVoicePhase('processing');
      setSending(true);
      try {
        let audioBase64: string | undefined;
        let mimeType: string | undefined;
        if (payload.audioBlob && payload.audioBlob.size > 0) {
          audioBase64 = await blobToBase64(payload.audioBlob);
          mimeType = payload.audioBlob.type || 'audio/webm';
        }

        const res = await fetch('/api/ai/voice-command', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioBase64,
            mimeType,
            transcriptText: payload.transcriptText,
            context: contextSnapshot,
            history: messages,
            model: activeInstitution?.aiModel,
            provider: activeInstitution?.aiProvider,
          }),
        });
        const data = (await res.json()) as {
          transcript?: string;
          action?: string;
          reply?: string;
          error?: string;
        };
        if (!res.ok) throw new Error(data.error || 'Voice command failed.');

        const userSpoken = data.transcript || payload.transcriptText || 'Voice command';
        const guardResult = executeVoiceAction(data.action, userSpoken);
        const replyText = guardResult.guardBlocked
          ? guardResult.guardMessage || 'That voice action is restricted for your current role.'
          : data.reply || 'Done.';

        setMessages((prev) => [
          ...prev,
          { role: 'user', text: userSpoken, viaVoice: true },
          {
            role: 'assistant',
            text: replyText,
            viaVoice: true,
            actionTaken: guardResult.actionTaken,
            guardBlocked: guardResult.guardBlocked,
          },
        ]);

        if (autoSpeak) {
          await speakResponse(replyText);
        } else {
          setVoicePhase('idle');
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unable to process voice command.';
        pushToast(msg, 'error');
        setVoicePhase('idle');
      } finally {
        setSending(false);
        setLiveCaption('');
        liveCaptionRef.current = '';
      }
    },
    [
      isOnline,
      contextSnapshot,
      messages,
      activeInstitution?.aiModel,
      activeInstitution?.aiProvider,
      executeVoiceAction,
      autoSpeak,
      speakResponse,
      pushToast,
    ]
  );

  const stopVoiceRecording = useCallback(
    (cancel = false) => {
      cancelledRef.current = cancel;
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      } else {
        cleanupListeningHardware();
        setVoicePhase('idle');
      }
    },
    [cleanupListeningHardware]
  );

  const startVoiceListening = useCallback(async () => {
    if (voicePhase === 'listening') {
      stopVoiceRecording(false);
      return;
    }
    if (!isOnline) {
      pushToast('Reconnect to the network to use the Voice AI Assistant.', 'error');
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      pushToast('Voice Guard: Microphone capture is not supported in this browser.', 'error');
      return;
    }
    stopSpeechPlayback();
    setPendingVoiceAction(null);
    cancelledRef.current = false;
    setLiveCaption('');
    liveCaptionRef.current = '';

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunksRef.current.push(ev.data);
      };
      mr.onstop = () => {
        cleanupListeningHardware();
        if (cancelledRef.current) {
          setVoicePhase('idle');
          setLiveCaption('');
          return;
        }
        const blob = new Blob(chunksRef.current, { type: mr.mimeType || 'audio/webm' });
        void submitVoicePayload({
          audioBlob: blob,
          transcriptText: liveCaptionRef.current || undefined,
        });
      };

      mr.start(250);
      mediaRecorderRef.current = mr;
      setVoicePhase('listening');

      const SpeechCtor =
        (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike }).SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike }).webkitSpeechRecognition;
      if (SpeechCtor) {
        try {
          const rec = new SpeechCtor();
          rec.continuous = true;
          rec.interimResults = true;
          rec.lang = 'en-US';
          rec.onresult = (ev) => {
            let text = '';
            for (let i = 0; i < ev.results.length; i += 1) {
              text += ev.results[i][0]?.transcript || '';
            }
            const clean = text.trim();
            liveCaptionRef.current = clean;
            setLiveCaption(clean);
          };
          rec.onerror = () => undefined;
          rec.start();
          speechRecRef.current = rec;
        } catch {
          // ignore
        }
      }

      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        audioCtxRef.current = ctx;
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 64;
        source.connect(analyser);

        const dataArr = new Uint8Array(analyser.frequencyBinCount);
        let speechDetected = false;
        let silenceStart = 0;
        const recordingStartedAt = Date.now();

        const monitor = () => {
          if (!streamRef.current || mr.state === 'inactive') return;
          analyser.getByteFrequencyData(dataArr);
          const bars: number[] = [];
          let sum = 0;
          for (let i = 0; i < 8; i += 1) {
            const val = dataArr[i * 2] || 0;
            sum += val;
            bars.push(Math.max(12, Math.min(100, Math.round((val / 255) * 100))));
          }
          setAudioLevels(bars);

          const avg = sum / 8;
          const now = Date.now();
          if (avg > 20) {
            speechDetected = true;
            silenceStart = 0;
          } else if (speechDetected && now - recordingStartedAt > 1200) {
            if (!silenceStart) silenceStart = now;
            if (now - silenceStart > 1600) {
              stopVoiceRecording(false);
              return;
            }
          } else if (now - recordingStartedAt > 12000) {
            stopVoiceRecording(false);
            return;
          }
          rafRef.current = requestAnimationFrame(monitor);
        };
        rafRef.current = requestAnimationFrame(monitor);
      }
    } catch (err) {
      cleanupListeningHardware();
      setVoicePhase('idle');
      pushToast(
        err instanceof Error ? err.message : 'Microphone permission denied or unavailable.',
        'error'
      );
    }
  }, [
    voicePhase,
    isOnline,
    stopSpeechPlayback,
    cleanupListeningHardware,
    submitVoicePayload,
    stopVoiceRecording,
    pushToast,
  ]);

  useEffect(() => {
    if (voiceLaunchRequested > lastHandledLaunchRef.current) {
      lastHandledLaunchRef.current = voiceLaunchRequested;
      if (voicePhase === 'idle') {
        void startVoiceListening();
      }
    }
  }, [voiceLaunchRequested, voicePhase, startVoiceListening]);

  const sendPrompt = async (promptText: string) => {
    const trimmed = promptText.trim();
    if (!trimmed || sending) return;
    if (!isOnline) {
      pushToast('AI Operations Assistant requires an active network connection.', 'error');
      return;
    }
    const nextHistory: ChatTurn[] = [...messages, { role: 'user', text: trimmed }];
    setMessages(nextHistory);
    setInput('');
    setSending(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: trimmed,
          context: contextSnapshot,
          history: nextHistory,
          model: activeInstitution?.aiModel,
          provider: activeInstitution?.aiProvider,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Assistant request failed.');
      setMessages((prev) => [...prev, { role: 'assistant', text: data.reply }]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to reach AI assistant.';
      pushToast(msg, 'error');
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: `Error: ${msg}` },
      ]);
    } finally {
      setSending(false);
    }
  };

  const quickPrompts = [
    ...(effectivePermissions.canAccessRecordings ? ["Summarize today's calls"] : []),
    ...(effectivePermissions.canViewAttendance
      ? ['Check attendance status', 'Run attendance anomaly scan', 'Open QR scanner']
      : []),
    'Draft a concise executive operations briefing for leadership.',
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">AI Operations Assistant</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Hands-free voice &amp; text intelligence powered by {activeInstitution?.aiProvider || 'Google Gemini'} ({activeInstitution?.aiModel || 'gemini-4-hydrogen'}).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setConfirmActionsGuard((v) => !v)}
            title="Require confirmation before voice commands navigate or run automated scans"
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer ${
              confirmActionsGuard
                ? 'border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                : 'border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>
              {confirmActionsGuard ? 'Voice Guard: Confirm Actions' : 'Voice Guard: Instant Run'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (autoSpeak) stopSpeechPlayback();
              setAutoSpeak((v) => !v);
            }}
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer ${
              autoSpeak
                ? 'border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300'
                : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
            }`}
          >
            {autoSpeak ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span>{autoSpeak ? 'Auto-Speak: ON' : 'Auto-Speak: OFF'}</span>
          </button>

          {voicePhase === 'speaking' && (
            <button
              type="button"
              onClick={stopSpeechPlayback}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 dark:bg-slate-800 text-white text-xs font-medium cursor-pointer"
            >
              <Square className="w-3.5 h-3.5" />
              <span>Stop Speaking</span>
            </button>
          )}
        </div>
      </div>

      {/* Hands-Free Voice Control Panel + RBAC Guard Status */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0">
            <button
              type="button"
              onClick={() => void startVoiceListening()}
              disabled={voicePhase === 'processing'}
              aria-label={voicePhase === 'listening' ? 'Stop voice recording and send' : 'Start hands-free voice command'}
              className={`relative w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-all cursor-pointer disabled:opacity-60 ${
                voicePhase === 'listening'
                  ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/30'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm'
              }`}
            >
              {voicePhase === 'listening' ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <div className="min-w-0">
              <p className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <span>
                  {voicePhase === 'listening'
                    ? 'Listening — speak your command...'
                    : voicePhase === 'processing'
                    ? 'Transcribing & verifying guard rules...'
                    : voicePhase === 'speaking'
                    ? 'Speaking response...'
                    : 'Hands-Free Microphone Voice Control'}
                </span>
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                {liveCaption
                  ? `Heard: "${liveCaption}"`
                  : 'Tap the microphone and say: "Summarize today\'s calls", "Check attendance status", or "Open QR scanner".'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {voicePhase === 'listening' ? (
              <>
                <div className="flex items-end gap-1 h-8 px-2" aria-hidden="true">
                  {audioLevels.map((lvl, idx) => (
                    <span
                      key={idx}
                      style={{ height: `${Math.max(18, lvl)}%` }}
                      className="w-1 rounded-full bg-rose-500 transition-all duration-75"
                    />
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => stopVoiceRecording(false)}
                  className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
                >
                  Stop &amp; Send
                </button>
                <button
                  type="button"
                  onClick={() => stopVoiceRecording(true)}
                  className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium cursor-pointer"
                >
                  Cancel
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => void startVoiceListening()}
                disabled={voicePhase === 'processing'}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-900 dark:bg-indigo-600 hover:opacity-90 disabled:opacity-60 text-white text-xs font-medium cursor-pointer"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>{voicePhase === 'processing' ? 'Processing...' : 'Start Voice Command'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Voice Guard Scope & Pending Action Confirmation */}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>
              Voice Guard Scope ({ROLE_LABELS[effectiveRole]}): Calls{' '}
              <strong>{effectivePermissions.canAccessRecordings ? 'Allowed' : 'Restricted'}</strong> · Attendance{' '}
              <strong>{effectivePermissions.canViewAttendance ? 'Allowed' : 'Restricted'}</strong> · Admin{' '}
              <strong>{isAdminTier ? 'Allowed' : 'Restricted'}</strong>
            </span>
          </span>
        </div>

        {pendingVoiceAction && (
          <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs text-amber-900 dark:text-amber-200">
              <strong>Voice Guard Confirmation:</strong> Execute <strong>{pendingVoiceAction.label}</strong>{' '}
              <span className="opacity-80">(&ldquo;{pendingVoiceAction.spokenCommand}&rdquo;)</span>?
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={confirmPendingVoiceAction}
                className="px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium cursor-pointer"
              >
                Confirm &amp; Run
              </button>
              <button
                type="button"
                onClick={() => setPendingVoiceAction(null)}
                className="px-3 py-1.5 rounded-md border border-amber-300 dark:border-amber-700 text-xs font-medium cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Conversational Assistant */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col h-[560px]">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="text-sm font-semibold">Institutional Intelligence Chat</span>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {activeInstitution?.aiModel || 'gemini-4-hydrogen'}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap space-y-1.5 ${
                    m.role === 'user'
                      ? 'bg-indigo-600 text-white'
                      : m.guardBlocked
                      ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100'
                  }`}
                >
                  {m.viaVoice && m.role === 'user' && (
                    <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider opacity-80">
                      <Mic className="w-3 h-3" />
                      <span>Voice Command</span>
                    </div>
                  )}
                  <p>{m.text}</p>
                  {m.actionTaken && (
                    <p
                      className={`text-[11px] font-medium ${
                        m.guardBlocked
                          ? 'text-rose-700 dark:text-rose-300'
                          : 'text-indigo-600 dark:text-indigo-300'
                      }`}
                    >
                      Action: {m.actionTaken}
                    </p>
                  )}
                  {m.role === 'assistant' && idx > 0 && (
                    <button
                      type="button"
                      onClick={() => void speakResponse(m.text)}
                      className="inline-flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-300 cursor-pointer pt-1"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>Listen</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
            {sending && (
              <div className="flex justify-start">
                <div className="rounded-xl px-4 py-3 text-xs bg-slate-100 dark:bg-slate-800 text-slate-500">
                  Analyzing institutional records...
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {quickPrompts.map((qp) => (
                <button
                  key={qp}
                  type="button"
                  onClick={() => {
                    if (qp === 'Run attendance anomaly scan') {
                      void runAttendanceAnomalyScan();
                    } else if (qp === 'Open QR scanner') {
                      setActiveTab('attendance');
                    } else {
                      void sendPrompt(qp);
                    }
                  }}
                  className="px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs text-slate-600 dark:text-slate-300 cursor-pointer"
                >
                  {qp}
                </button>
              ))}
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void sendPrompt(input);
              }}
              className="flex gap-2"
            >
              <button
                type="button"
                onClick={() => void startVoiceListening()}
                disabled={voicePhase === 'processing'}
                title="Speak voice command"
                aria-label="Speak voice command"
                className={`px-3 py-2.5 rounded-lg border text-sm inline-flex items-center justify-center cursor-pointer shrink-0 ${
                  voicePhase === 'listening'
                    ? 'bg-rose-600 border-rose-600 text-white'
                    : 'border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {voicePhase === 'listening' ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask or speak about attendance status, call summaries, staff, or branches..."
                className="flex-1 px-3.5 py-2.5 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="submit"
                disabled={sending || !input.trim()}
                className="px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-sm font-medium inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>

        {/* Dedicated Attendance Anomaly Analyzer */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold">Attendance Anomaly Scan</h2>
            <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Detect late arrival clusters, missing check-ins, and branch compliance risks automatically.
          </p>
          <button
            type="button"
            onClick={() => void runAttendanceAnomalyScan()}
            disabled={analyzingAttendance || !effectivePermissions.canViewAttendance}
            className="w-full py-2.5 rounded-lg bg-slate-900 dark:bg-indigo-600 hover:opacity-90 disabled:opacity-60 text-white text-xs font-medium cursor-pointer"
          >
            {analyzingAttendance
              ? 'Scanning Patterns...'
              : effectivePermissions.canViewAttendance
              ? 'Run Attendance Pattern Analysis'
              : 'Attendance Permission Required'}
          </button>

          {analysis && (
            <div className="space-y-4 pt-2 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                {analysis.overallHealth === 'nominal' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                )}
                <p className="text-sm font-semibold">{analysis.headline}</p>
              </div>
              {analysis.anomalies?.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Detected Patterns
                  </p>
                  <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400 list-disc pl-4">
                    {analysis.anomalies.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                </div>
              )}
              {analysis.recommendations?.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Recommendations
                  </p>
                  <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400 list-disc pl-4">
                    {analysis.recommendations.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
