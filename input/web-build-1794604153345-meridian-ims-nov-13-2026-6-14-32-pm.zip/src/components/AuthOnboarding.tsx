import React, { useState } from 'react';
import { Building2, CheckCircle2, Globe, ShieldCheck, ArrowRight, LogOut } from 'lucide-react';
import { useIMS } from '../context/IMSContext';
import type { InstitutionType } from '../types/ims';
import heroImage from '../assets/images/ims_campus_hero_1794585621461.jpg';

export const AuthOnboarding: React.FC = () => {
  const {
    firebaseUser,
    authLoading,
    authError,
    signInWithGoogle,
    retryProfileSync,
    logout,
    createInstitution,
    institutions,
    selectInstitution,
    theme,
    toggleTheme,
  } = useIMS();

  const [name, setName] = useState('');
  const [type, setType] = useState<InstitutionType>('university');
  const [code, setCode] = useState('');
  const [country, setCountry] = useState('United Kingdom');
  const [timezone, setTimezone] = useState(
    Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
  );
  const [workStartTime, setWorkStartTime] = useState('09:00');
  const [seedSampleData, setSeedSampleData] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (name.trim().length < 2 || code.trim().length < 2) {
      setFormError('Institution name and code must each be at least 2 characters.');
      return;
    }
    setSubmitting(true);
    try {
      await createInstitution({
        name,
        type,
        code,
        country,
        timezone,
        workStartTime,
        seedSampleData,
      });
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Unable to create institution.');
    } finally {
      setSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm font-medium">Initializing NewOpenlink workspace...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
      {/* Clean 3-zone top bar */}
      <header className="w-full border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
            <svg className="w-7 h-7 shrink-0" viewBox="0 0 512 512" fill="none" aria-hidden="true">
              <rect width="512" height="512" rx="96" fill="#0F172A" />
              <rect x="88" y="112" width="64" height="288" rx="12" fill="#3B82F6" />
              <rect x="360" y="112" width="64" height="288" rx="12" fill="#6366F1" />
              <path d="M152 144L256 272L360 144" stroke="#E2E8F0" strokeWidth="44" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span className="font-display text-lg font-bold tracking-tight">NewOpenlink</span>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
            <span className="whitespace-nowrap shrink-0">Multi-Branch Operations</span>
            <span className="whitespace-nowrap shrink-0">QR Attendance</span>
            <span className="whitespace-nowrap shrink-0">Call Intelligence</span>
            <span className="whitespace-nowrap shrink-0">Android Ready</span>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={toggleTheme}
              className="px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            </button>
            {firebaseUser && (
              <button
                type="button"
                onClick={logout}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        {/* Left visual + institutional capabilities */}
        <div className="lg:col-span-7 flex flex-col justify-between bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="relative h-64 sm:h-80 w-full bg-slate-900">
            <img
              src={heroImage}
              alt="Modern multi-branch institutional campus"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/45 to-transparent flex flex-col justify-end p-6 sm:p-8">
              <p className="text-xs font-medium text-indigo-300 tracking-wide">
                Global Institutional Operations Platform
              </p>
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white mt-1 max-w-xl [text-wrap:balance]">
                Unified branch, attendance, and call intelligence for modern institutions.
              </h1>
            </div>
          </div>

          <div className="p-6 sm:p-8 grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <Building2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>Multi-Institution</span>
              </div>
              <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                Manage campuses, regional branches, departments, and six role tiers with isolated security rules.
              </p>
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Verifiable QR & Offline</span>
              </div>
              <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                Rotating QR credentials block screenshot reuse while offline queues sync automatically on reconnect.
              </p>
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>AI Call Intelligence</span>
              </div>
              <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
                Encrypted SIP, WebRTC, and uploaded recordings with Gemini transcription and categorization.
              </p>
            </div>
          </div>
        </div>

        {/* Right authentication or institution registration panel */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 flex flex-col justify-center">
          {!firebaseUser ? (
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                  Sign in to NewOpenlink
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1.5">
                  Authenticate with your institutional Google account to access dashboards, QR scanners, and call records.
                </p>
              </div>

              {authError && (
                <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
                  {authError}
                </div>
              )}

              <button
                type="button"
                onClick={signInWithGoogle}
                className="w-full min-h-11 px-4 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
              >
                <Globe className="w-4 h-4" />
                <span>Continue with Google Account</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 space-y-1">
                <p>Protected by Firebase Authentication and tenant-isolated Firestore security rules.</p>
                <p>Works as an installable Android PWA with offline attendance capture.</p>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400">
                  Signed in as {firebaseUser.email}
                </p>
                <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white mt-1">
                  Register Your Institution
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  Set up an institutional workspace to start managing branches, staff, QR attendance, and call records.
                </p>
              </div>

              {authError && (
                <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-300 flex items-center justify-between gap-2">
                  <span>{authError}</span>
                  <button
                    type="button"
                    onClick={() => void retryProfileSync()}
                    className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-700 text-white font-medium shrink-0 cursor-pointer"
                  >
                    Retry
                  </button>
                </div>
              )}

              {institutions.length > 0 && (
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                    Existing Institutions
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {institutions.map((inst) => (
                      <button
                        key={inst.id}
                        type="button"
                        onClick={() => selectInstitution(inst.id)}
                        className="px-3 py-1.5 text-xs font-medium rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-indigo-500 transition-colors"
                      >
                        {inst.name} ({inst.code})
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <form onSubmit={handleCreate} className="space-y-3.5">
                {formError && (
                  <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
                    {formError}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Institution Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. St. Jude Global Academy"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Institution Type
                    </label>
                    <select
                      value={type}
                      onChange={(e) => setType(e.target.value as InstitutionType)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="university">University / College</option>
                      <option value="school">K-12 School</option>
                      <option value="hospital">Hospital / Healthcare</option>
                      <option value="corporate">Corporate Enterprise</option>
                      <option value="government">Government Agency</option>
                      <option value="nonprofit">Nonprofit / NGO</option>
                      <option value="other">Other Institution</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Short Code
                    </label>
                    <input
                      type="text"
                      required
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      placeholder="SJGA"
                      maxLength={16}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono uppercase focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-1">
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Work Start
                    </label>
                    <input
                      type="time"
                      value={workStartTime}
                      onChange={(e) => setWorkStartTime(e.target.value)}
                      className="w-full px-2.5 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div className="col-span-1">
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Country
                    </label>
                    <input
                      type="text"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <div className="col-span-1">
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Timezone
                    </label>
                    <input
                      type="text"
                      value={timezone}
                      onChange={(e) => setTimezone(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <label className="flex items-start gap-2.5 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={seedSampleData}
                    onChange={(e) => setSeedSampleData(e.target.checked)}
                    className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-xs text-slate-600 dark:text-slate-400">
                    Include sample regional branch, 5 registered members with QR codes, today&apos;s attendance logs, and sample call transcripts.
                  </span>
                </label>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full min-h-11 px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-medium text-sm transition-colors cursor-pointer"
                >
                  {submitting ? 'Provisioning Institution...' : 'Create Institution Workspace'}
                </button>
              </form>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
