import React, { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  Check,
  CloudUpload,
  Database,
  Download,
  FileCheck2,
  FileSpreadsheet,
  FileText,
  HardDrive,
  Lock,
  Printer,
  RefreshCw,
  Search,
  Send,
  Shield,
  Smartphone,
  Trash2,
  WifiOff,
} from 'lucide-react';
import { useIMS } from '../context/IMSContext';
import {
  exportReportToPdf,
  exportRowsToCsv,
  exportWorkbookToExcel,
  triggerBlobDownload,
} from '../lib/exportUtils';
import { LANGUAGE_LABELS, type LanguageCode } from '../lib/i18n';
import type { NotificationItem } from '../types/ims';

function formatFirestoreTimestamp(ts: unknown): string {
  if (!ts) return 'Pending';
  if (typeof ts === 'string') return new Date(ts).toLocaleString();
  if (typeof ts === 'object' && ts !== null && 'toDate' in ts && typeof (ts as { toDate: () => Date }).toDate === 'function') {
    return (ts as { toDate: () => Date }).toDate().toLocaleString();
  }
  return 'Synced';
}

export const SystemViews: React.FC<{
  mode: 'backups' | 'notifications' | 'audit' | 'settings';
}> = ({ mode }) => {
  const {
    activeInstitution,
    branches,
    departments,
    roster,
    attendance,
    calls,
    callCategories,
    members,
    notifications,
    auditLogs,
    backups,
    offlineQueue,
    offlineActivityQueue,
    isOnline,
    simulatedOffline,
    setSimulatedOffline,
    swStatus,
    lastSyncedAt,
    headlessSyncStatus,
    isSyncingOffline,
    triggerServiceWorkerSync,
    retryFailedOfflineItems,
    discardQueuedItem,
    recordBackup,
    logAudit,
    createNotification,
    markNotificationRead,
    markAllNotificationsRead,
    updateInstitutionSettings,
    effectiveRole,
    effectivePermissions,
    theme,
    toggleTheme,
    language,
    setLanguage,
    pushToast,
  } = useIMS();

  // Backups state
  const [creatingBackup, setCreatingBackup] = useState(false);
  const [encryptBackup, setEncryptBackup] = useState(true);
  const [lastBackupDownloadId, setLastBackupDownloadId] = useState<string | null>(null);

  // Notification broadcast & filter state
  const [notifType, setNotifType] = useState<NotificationItem['type']>('announcement');
  const [notifSeverity, setNotifSeverity] = useState<NotificationItem['severity']>('info');
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifFilter, setNotifFilter] = useState<'all' | 'unread' | NotificationItem['type']>('all');
  const [pushPerm, setPushPerm] = useState<string>(() =>
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'unsupported'
  );

  // Audit search & filters
  const [auditSearch, setAuditSearch] = useState('');
  const [auditResourceFilter, setAuditResourceFilter] = useState('all');
  const [auditDateFilter, setAuditDateFilter] = useState('');

  // Recording Vault Sync Verification State
  const [recSyncStatuses, setRecSyncStatuses] = useState<
    Record<string, { synced: boolean; encrypted: boolean; sizeBytes?: number }>
  >({});
  const [verifyingRecSync, setVerifyingRecSync] = useState(false);

  // Settings form state
  const [instName, setInstName] = useState(activeInstitution?.name || '');
  const [workStart, setWorkStart] = useState(activeInstitution?.workStartTime || '09:00');
  const [timezone, setTimezone] = useState(activeInstitution?.timezone || 'UTC');
  const [consentReq, setConsentReq] = useState(
    Boolean(activeInstitution?.recordingConsentRequired ?? true)
  );
  const [autoRecord, setAutoRecord] = useState(
    Boolean(activeInstitution?.autoRecordSupportedCalls ?? false)
  );
  const [rotatingQr, setRotatingQr] = useState(
    Boolean(activeInstitution?.rotatingQrEnabled ?? true)
  );
  const [aiModel, setAiModel] = useState(activeInstitution?.aiModel || 'gemini-4-hydrogen');
  const [aiProvider, setAiProvider] = useState(activeInstitution?.aiProvider || 'Google Gemini');
  const [settingsTab, setSettingsTab] = useState<'profile' | 'security' | 'ai' | 'android'>('profile');

  useEffect(() => {
    setInstName(activeInstitution?.name || '');
    setWorkStart(activeInstitution?.workStartTime || '09:00');
    setTimezone(activeInstitution?.timezone || 'UTC');
    setConsentReq(Boolean(activeInstitution?.recordingConsentRequired ?? true));
    setAutoRecord(Boolean(activeInstitution?.autoRecordSupportedCalls ?? false));
    setRotatingQr(Boolean(activeInstitution?.rotatingQrEnabled ?? true));
    setAiModel(activeInstitution?.aiModel || 'gemini-4-hydrogen');
    setAiProvider(activeInstitution?.aiProvider || 'Google Gemini');
  }, [activeInstitution]);

  const isAdminTier =
    ['super_admin', 'institution_admin', 'branch_admin'].includes(effectiveRole) ||
    effectivePermissions.canChangeSettings;

  const verifyRecordingVaultSync = async () => {
    const ids = Array.from(
      new Set(calls.map((c) => c.recordingId).filter((id): id is string => Boolean(id)))
    );
    if (ids.length === 0 || !isOnline) return;
    setVerifyingRecSync(true);
    try {
      const res = await fetch('/api/recordings/sync-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recordingIds: ids }),
      });
      if (res.ok) {
        const data = (await res.json()) as {
          statuses?: Record<string, { synced: boolean; encrypted: boolean; sizeBytes?: number }>;
        };
        if (data.statuses) setRecSyncStatuses(data.statuses);
      }
    } catch {
      // ignore
    } finally {
      setVerifyingRecSync(false);
    }
  };

  useEffect(() => {
    if (mode === 'backups' && isOnline) {
      void verifyRecordingVaultSync();
    }
  }, [mode, calls, isOnline]);

  const auditResourceTypes = useMemo(
    () => Array.from(new Set(auditLogs.map((l) => l.resourceType))).sort(),
    [auditLogs]
  );

  const filteredAudit = useMemo(() => {
    return auditLogs.filter((l) => {
      if (auditResourceFilter !== 'all' && l.resourceType !== auditResourceFilter) return false;
      if (auditDateFilter) {
        let iso = '';
        if (typeof l.createdAt === 'string') iso = l.createdAt.slice(0, 10);
        else if (
          typeof l.createdAt === 'object' &&
          l.createdAt !== null &&
          'toDate' in l.createdAt &&
          typeof (l.createdAt as { toDate: () => Date }).toDate === 'function'
        ) {
          iso = (l.createdAt as { toDate: () => Date }).toDate().toISOString().slice(0, 10);
        }
        if (iso !== auditDateFilter) return false;
      }
      if (auditSearch.trim()) {
        const q = auditSearch.toLowerCase();
        return (
          l.action.toLowerCase().includes(q) ||
          l.actorName.toLowerCase().includes(q) ||
          l.resourceType.toLowerCase().includes(q) ||
          (l.details || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [auditLogs, auditResourceFilter, auditDateFilter, auditSearch]);

  const buildFullSnapshot = () => ({
    exportedAt: new Date().toISOString(),
    institution: activeInstitution,
    branches,
    departments,
    roster,
    attendance,
    calls,
    callCategories,
    members,
    notifications,
  });

  const handleCreateServerBackup = async (destination: 'cloud_snapshot' | 'google_drive_export' | 'local_encrypted_archive') => {
    if (!activeInstitution) return;
    if (!isOnline) {
      pushToast('Server vault backups require network connectivity. Offline queues remain saved in IndexedDB.', 'error');
      return;
    }
    setCreatingBackup(true);
    try {
      const snapshot = buildFullSnapshot();
      const recordCount =
        branches.length + departments.length + roster.length + attendance.length + calls.length;

      const res = await fetch('/api/backups/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          institutionId: activeInstitution.id,
          snapshot,
          encrypt: encryptBackup,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Backup failed');

      setLastBackupDownloadId(data.backupId);
      await recordBackup({
        destination,
        recordCount,
        checksum: data.checksum,
        encrypted: data.encrypted,
      });

      if (destination === 'google_drive_export') {
        const blob = new Blob([JSON.stringify(snapshot, null, 2)], {
          type: 'application/json',
        });
        triggerBlobDownload(
          blob,
          `${activeInstitution.code}_GDrive_Backup_${new Date().toISOString().slice(0, 10)}.json`
        );
      } else if (destination === 'local_encrypted_archive') {
        window.location.href = `/api/backups/${data.backupId}/download`;
      }
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Backup failed.', 'error');
    } finally {
      setCreatingBackup(false);
    }
  };

  if (mode === 'backups') {
    if (!isAdminTier) {
      return (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center space-y-3">
          <Lock className="w-8 h-8 text-slate-400 mx-auto" />
          <h2 className="font-display text-lg font-semibold">Restricted Backup &amp; Sync Controls</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            Only institutional or branch administrators can manage cloud vault snapshots and backup archives.
          </p>
        </div>
      );
    }
    return (
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Database Backups &amp; Synchronization</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Create checksummed cloud snapshots, download encrypted archives, export Google Drive bundles, and sync offline scans.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2">
              <CloudUpload className="w-5 h-5 text-indigo-600" />
              <h2 className="font-display text-base font-semibold">Cloud Vault Snapshot</h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Saves a SHA-256 verified institutional snapshot on the server and records its checksum in Firestore.
            </p>
            <label className="flex items-center gap-2 text-xs cursor-pointer">
              <input
                type="checkbox"
                checked={encryptBackup}
                onChange={(e) => setEncryptBackup(e.target.checked)}
                className="rounded text-indigo-600"
              />
              <span>AES-256-GCM Encrypt Snapshot</span>
            </label>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                disabled={creatingBackup}
                onClick={() => handleCreateServerBackup('cloud_snapshot')}
                className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white text-xs font-medium cursor-pointer"
              >
                {creatingBackup ? 'Creating Snapshot...' : 'Create Cloud Snapshot'}
              </button>
              <button
                type="button"
                disabled={creatingBackup}
                onClick={() => handleCreateServerBackup('local_encrypted_archive')}
                className="w-full py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Encrypted Archive (.imsvault)</span>
              </button>
              {lastBackupDownloadId && (
                <a
                  href={`/api/backups/${lastBackupDownloadId}/download`}
                  className="text-xs text-center text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Re-download latest ({lastBackupDownloadId})
                </a>
              )}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2">
              <HardDrive className="w-5 h-5 text-emerald-600" />
              <h2 className="font-display text-base font-semibold">Google Drive &amp; External Sync</h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Export a structured institutional JSON package ready for Google Drive backup folders or cross-region cold storage.
            </p>
            <button
              type="button"
              disabled={creatingBackup}
              onClick={() => handleCreateServerBackup('google_drive_export')}
              className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium cursor-pointer"
            >
              Export Google Drive Backup Bundle
            </button>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              To automate scheduled Drive uploads, connect a Workspace OAuth client in your deployment environment and mount the backup folder ID.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <RefreshCw className="w-5 h-5 text-amber-600" />
                <h2 className="font-display text-base font-semibold">Service Worker &amp; IndexedDB Queue</h2>
              </div>
              <button
                type="button"
                onClick={() => setSimulatedOffline(!simulatedOffline)}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium cursor-pointer ${
                  simulatedOffline
                    ? 'bg-amber-600 text-white'
                    : 'border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <WifiOff className="w-3 h-3" />
                <span>{simulatedOffline ? 'Exit Offline Test' : 'Test Offline'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Captures attendance scans &amp; activity logs in IndexedDB when offline, syncing automatically to Firebase via Service Worker Background Sync (<code className="font-mono">meridian-firebase-sync</code>).
            </p>
            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
              <p>
                Service Worker: <strong className="capitalize">{swStatus}</strong> · Network: <strong>{isOnline ? 'Online' : simulatedOffline ? 'Simulated Offline' : 'Offline'}</strong>
              </p>
              <p className="tabular-nums">
                IndexedDB Attendance Queue: <strong>{offlineQueue.length}</strong> · Activity Logs: <strong>{offlineActivityQueue.length}</strong>
              </p>
              {lastSyncedAt && (
                <p className="text-[11px] text-slate-500 font-mono">
                  Last client sync: {new Date(lastSyncedAt).toLocaleTimeString()}
                </p>
              )}
              {headlessSyncStatus?.lastHeadlessSyncAt && (
                <p className="text-[11px] text-slate-500 font-mono">
                  Last SW headless sync: {new Date(headlessSyncStatus.lastHeadlessSyncAt).toLocaleTimeString()} ({headlessSyncStatus.lastHeadlessSyncAttCount || 0} att, {headlessSyncStatus.lastHeadlessSyncActCount || 0} log)
                </p>
              )}
            </div>
              <button
                type="button"
                disabled={!isOnline || (offlineQueue.length === 0 && offlineActivityQueue.length === 0) || isSyncingOffline}
                onClick={() => triggerServiceWorkerSync()}
                className="w-full py-2 rounded-lg bg-slate-900 dark:bg-indigo-600 disabled:opacity-50 text-white text-xs font-medium cursor-pointer"
              >
                {isSyncingOffline ? 'Synchronizing IndexedDB...' : 'Trigger Service Worker Sync'}
              </button>
            </div>
          </div>

          {/* Call Recording Vault Sync Status */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            {(() => {
              const audioCalls = calls.filter((c) => Boolean(c.recordingId));
              const syncedCount = audioCalls.filter(
                (c) => c.recordingId && recSyncStatuses[c.recordingId]?.synced
              ).length;
              const encryptedCount = audioCalls.filter((c) => c.recordingEncrypted).length;
              const metadataOnlyCount = calls.length - audioCalls.length;
              return (
                <>
                  <div className="space-y-1">
                    <h3 className="font-display text-sm font-semibold">Call Recording Vault Sync Status</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                      Audio Recordings: <strong>{audioCalls.length}</strong> · Verified in Server Vault:{' '}
                      <strong>{isOnline ? syncedCount : 'Offline'}</strong> · AES-256-GCM Encrypted:{' '}
                      <strong>{encryptedCount}</strong> · Metadata-Only Calls: <strong>{metadataOnlyCount}</strong>
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={!isOnline || verifyingRecSync || audioCalls.length === 0}
                    onClick={() => void verifyRecordingVaultSync()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 text-xs font-medium shrink-0 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${verifyingRecSync ? 'animate-spin' : ''}`} />
                    <span>{verifyingRecSync ? 'Verifying...' : 'Verify Recording Vault'}</span>
                  </button>
                </>
              );
            })()}
          </div>

        {/* IndexedDB Offline Queue Inspector */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-600" />
              <div>
                <h3 className="font-display text-base font-semibold">IndexedDB Queue Inspector</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Stores: <code className="font-mono">attendance_queue</code> &amp; <code className="font-mono">activity_log_queue</code> in <code className="font-mono">meridian-ims-offline-db</code>
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {(offlineQueue.some((i) => i.lastError) || offlineActivityQueue.some((a) => a.lastError)) && (
                <button
                  type="button"
                  disabled={!isOnline || isSyncingOffline}
                  onClick={() => retryFailedOfflineItems()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-medium cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry Failed</span>
                </button>
              )}
              {(offlineQueue.length > 0 || offlineActivityQueue.length > 0) && (
                <button
                  type="button"
                  onClick={() => {
                    const blob = new Blob(
                      [
                        JSON.stringify(
                          {
                            exportedAt: new Date().toISOString(),
                            institutionId: activeInstitution?.id,
                            attendanceQueue: offlineQueue,
                            activityLogQueue: offlineActivityQueue,
                          },
                          null,
                          2
                        ),
                      ],
                      { type: 'application/json' }
                    );
                    triggerBlobDownload(
                      blob,
                      `NewOpenlink_Offline_Queue_${new Date().toISOString().slice(0, 10)}.json`
                    );
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Queue (.json)</span>
                </button>
              )}
              <button
                type="button"
                onClick={async () => {
                  await logAudit(
                    isOnline ? 'Sync Queue Verification Log' : 'Offline Activity Capture',
                    'system',
                    undefined,
                    isOnline ? 'Direct Firebase audit entry' : 'Captured in IndexedDB while offline'
                  );
                  pushToast(
                    isOnline
                      ? 'Activity logged directly to Firebase (toggle Test Offline to queue in IndexedDB).'
                      : 'Offline activity log saved to IndexedDB queue.',
                    'info'
                  );
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium cursor-pointer"
              >
                <span>{isOnline ? 'Log Sample Activity' : 'Capture Offline Activity Log'}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-800">
            <div className="p-4 space-y-2.5">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-200 tabular-nums">
                Queued Attendance Scans ({offlineQueue.length})
              </p>
              {offlineQueue.length === 0 ? (
                <p className="text-xs text-slate-400 py-4">No pending attendance scans in IndexedDB.</p>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {offlineQueue.map((item) => (
                    <div
                      key={item.localId}
                      className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <p className="font-medium truncate">
                          {item.memberName} ({item.memberCode}) · {item.action.replace('_', ' ')}
                        </p>
                        <p className="text-[11px] font-mono text-slate-500 truncate">
                          {item.localId} · {item.status} · {new Date(item.checkInIso).toLocaleTimeString()}
                        </p>
                        {item.lastError && (
                          <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-0.5">{item.lastError}</p>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => discardQueuedItem('attendance', item.localId)}
                        title="Discard queued item"
                        className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-4 space-y-2.5">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-200 tabular-nums">
                Queued Activity Logs ({offlineActivityQueue.length})
              </p>
              {offlineActivityQueue.length === 0 ? (
                <p className="text-xs text-slate-400 py-4">No pending activity logs in IndexedDB.</p>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {offlineActivityQueue.map((act) => (
                    <div
                      key={act.localId}
                      className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0">
                        <p className="font-medium truncate">
                          {act.action} <span className="text-slate-500">({act.resourceType})</span>
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">
                          {act.details || act.actorName} · {new Date(act.queuedAtMs).toLocaleTimeString()}
                        </p>
                        {act.lastError && (
                          <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-0.5">{act.lastError}</p>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => discardQueuedItem('activity', act.localId)}
                        title="Discard queued log"
                        className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Backup History */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800">
            <h3 className="font-display text-base font-semibold">Backup Snapshot Registry</h3>
          </div>
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {backups.map((b) => (
              <div key={b.id} className="px-5 py-3 flex items-center justify-between gap-3 text-xs">
                <div>
                  <p className="font-semibold text-slate-900 dark:text-white">
                    {b.destination.replace(/_/g, ' ').toUpperCase()}
                  </p>
                  <p className="text-slate-500 font-mono">
                    SHA-256: {b.checksum} · {b.recordCount} records · {b.encrypted ? 'AES-256-GCM' : 'Plain JSON'}
                  </p>
                </div>
                <span className="text-slate-500">{b.createdByName || 'Admin'}</span>
              </div>
            ))}
            {backups.length === 0 && (
              <p className="px-5 py-8 text-center text-xs text-slate-400">
                No backup snapshots created yet.
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'notifications') {
    const filteredNotifications = notifications.filter((n) => {
      if (notifFilter === 'unread') return !n.isRead;
      if (notifFilter !== 'all') return n.type === notifFilter;
      return true;
    });
    const unreadCount = notifications.filter((n) => !n.isRead).length;

    const handleEnableBrowserAlerts = async () => {
      if (typeof window === 'undefined' || !('Notification' in window)) {
        pushToast('Browser notifications are not supported on this device.', 'info');
        return;
      }
      const res = await Notification.requestPermission();
      setPushPerm(res);
      pushToast(
        res === 'granted'
          ? 'Device notification alerts enabled.'
          : `Notification permission status: ${res}.`,
        res === 'granted' ? 'success' : 'info'
      );
    };

    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight">Notifications &amp; Announcements</h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Real-time attendance alerts, late arrival flags, call escalations, and administrative broadcasts.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {pushPerm !== 'granted' && pushPerm !== 'unsupported' && (
              <button
                type="button"
                onClick={handleEnableBrowserAlerts}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
              >
                Enable Push Alerts
              </button>
            )}
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={() => markAllNotificationsRead()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Mark All Read ({unreadCount})</span>
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (!notifTitle.trim() || !notifMessage.trim()) return;
              await createNotification({
                type: notifType,
                severity: notifSeverity,
                title: notifTitle,
                message: notifMessage,
              });
              setNotifTitle('');
              setNotifMessage('');
              pushToast('Announcement broadcast sent.', 'success');
            }}
            className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3"
          >
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-indigo-600" />
              <h2 className="font-display text-base font-semibold">Broadcast Notification</h2>
            </div>
            <select
              value={notifType}
              onChange={(e) => setNotifType(e.target.value as NotificationItem['type'])}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              <option value="announcement">Administrative Announcement</option>
              <option value="attendance">Attendance Notice</option>
              <option value="late_arrival">Late Arrival Flag</option>
              <option value="missed_attendance">Missed Attendance Alert</option>
              <option value="important_call">Important Call Escalation</option>
              <option value="assigned_call">Assigned Call Alert</option>
              <option value="system">System Update</option>
            </select>
            <select
              value={notifSeverity}
              onChange={(e) => setNotifSeverity(e.target.value as NotificationItem['severity'])}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="urgent">Urgent</option>
            </select>
            <input
              type="text"
              required
              value={notifTitle}
              onChange={(e) => setNotifTitle(e.target.value)}
              placeholder="Headline"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
            <textarea
              rows={3}
              required
              value={notifMessage}
              onChange={(e) => setNotifMessage(e.target.value)}
              placeholder="Announcement details..."
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Publish Notification</span>
            </button>
          </form>

          <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
              <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
                Showing {filteredNotifications.length} of {notifications.length} notification(s)
              </span>
              <select
                value={notifFilter}
                onChange={(e) =>
                  setNotifFilter(e.target.value as 'all' | 'unread' | NotificationItem['type'])
                }
                className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                <option value="all">All Notifications</option>
                <option value="unread">Unread Only</option>
                <option value="attendance">Attendance Registration</option>
                <option value="late_arrival">Late Arrivals</option>
                <option value="missed_attendance">Missed Attendance</option>
                <option value="important_call">Important Calls</option>
                <option value="assigned_call">Assigned Calls</option>
                <option value="announcement">Announcements</option>
                <option value="system">System Updates</option>
              </select>
            </div>
            <div className="divide-y divide-slate-200 dark:divide-slate-800">
              {filteredNotifications.map((n) => (
                <div key={n.id} className="p-4 flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span
                        className={`font-semibold uppercase ${
                          n.severity === 'urgent'
                            ? 'text-rose-600'
                            : n.severity === 'warning'
                            ? 'text-amber-600'
                            : 'text-indigo-600'
                        }`}
                      >
                        {n.severity}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{n.type.replace('_', ' ')}</span>
                      {!n.isRead && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-indigo-600 font-semibold">Unread</span>
                        </>
                      )}
                    </div>
                    <p className="text-sm font-semibold mt-0.5">{n.title}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{n.message}</p>
                  </div>
                  {!n.isRead && (
                    <button
                      type="button"
                      onClick={() => markNotificationRead(n.id)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700 text-xs hover:bg-slate-50 dark:hover:bg-slate-800 shrink-0 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Mark Read</span>
                    </button>
                  )}
                </div>
              ))}
              {filteredNotifications.length === 0 && (
                <p className="p-8 text-center text-xs text-slate-400">
                  No notifications match the selected filter.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'audit') {
    if (!isAdminTier) {
      return (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center space-y-3">
          <Lock className="w-8 h-8 text-slate-400 mx-auto" />
          <h2 className="font-display text-lg font-semibold">Restricted Security Audit Trail</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            Audit logs are restricted to institutional and branch administrators.
          </p>
        </div>
      );
    }
    const auditHeaders = ['Timestamp', 'Action', 'Actor', 'Role', 'Resource Type', 'Resource ID', 'Details'];
    const auditRows = filteredAudit.map((l) => [
      formatFirestoreTimestamp(l.createdAt),
      l.action,
      l.actorName,
      l.actorRole,
      l.resourceType,
      l.resourceId || '',
      l.details || '',
    ]);
    const dateStamp = new Date().toISOString().slice(0, 10);
    const baseName = `${activeInstitution?.code || 'NewOpenlink'}_Audit_Trail_${dateStamp}`;

    return (
      <div className="space-y-6">
        <div className="no-print flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight">Security Audit Logs</h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Append-only operational trail protected against alteration or deletion by Firestore rules.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={filteredAudit.length === 0}
              onClick={() => {
                exportRowsToCsv(`${baseName}.csv`, auditHeaders, auditRows);
                void logAudit('Export Audit Logs', 'audit_log', 'csv', `Exported ${filteredAudit.length} rows`);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 text-xs font-medium cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>
            <button
              type="button"
              disabled={filteredAudit.length === 0}
              onClick={() => {
                exportWorkbookToExcel(`${baseName}.xlsx`, [
                  { name: 'Security Audit Trail', headers: auditHeaders, rows: auditRows },
                ]);
                void logAudit('Export Audit Logs', 'audit_log', 'xlsx', `Exported ${filteredAudit.length} rows`);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 text-xs font-medium cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Excel</span>
            </button>
            <button
              type="button"
              disabled={filteredAudit.length === 0}
              onClick={() => {
                exportReportToPdf({
                  title: 'Security Audit Trail Report',
                  institutionName: activeInstitution?.name || 'NewOpenlink',
                  subtitle: `${filteredAudit.length} audit event(s)${auditResourceFilter !== 'all' ? ` · Resource: ${auditResourceFilter}` : ''}`,
                  headers: auditHeaders,
                  rows: auditRows,
                  filename: `${baseName}.pdf`,
                });
                void logAudit('Export Audit Logs', 'audit_log', 'pdf', `Exported ${filteredAudit.length} rows`);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-medium cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>PDF</span>
            </button>
            <button
              type="button"
              disabled={filteredAudit.length === 0}
              onClick={() => {
                const payload = {
                  exportedAt: new Date().toISOString(),
                  institution: activeInstitution?.name,
                  totalEvents: filteredAudit.length,
                  events: filteredAudit.map((l) => ({
                    id: l.id,
                    timestamp: formatFirestoreTimestamp(l.createdAt),
                    action: l.action,
                    actorName: l.actorName,
                    actorRole: l.actorRole,
                    resourceType: l.resourceType,
                    resourceId: l.resourceId || null,
                    details: l.details || null,
                  })),
                };
                triggerBlobDownload(
                  new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }),
                  `${baseName}.json`
                );
                void logAudit('Export Audit Logs', 'audit_log', 'json', `Exported ${filteredAudit.length} rows`);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 text-xs font-medium cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-indigo-600" />
              <span>JSON</span>
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
          </div>
        </div>

        {/* Audit Filters */}
        <div className="no-print flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={auditSearch}
              onChange={(e) => setAuditSearch(e.target.value)}
              placeholder="Search action, actor, or details..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
            />
          </div>
          <select
            value={auditResourceFilter}
            onChange={(e) => setAuditResourceFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
          >
            <option value="all">All Resource Types ({auditLogs.length})</option>
            {auditResourceTypes.map((rt) => (
              <option key={rt} value={rt}>
                {rt}
              </option>
            ))}
          </select>
          <input
            type="date"
            value={auditDateFilter}
            onChange={(e) => setAuditDateFilter(e.target.value)}
            className="px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
          />
          {auditDateFilter && (
            <button
              type="button"
              onClick={() => setAuditDateFilter('')}
              className="px-2.5 py-2 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
            >
              Clear Date
            </button>
          )}
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="px-4 py-3 font-medium">Timestamp</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                  <th className="px-4 py-3 font-medium">Actor</th>
                  <th className="px-4 py-3 font-medium">Resource</th>
                  <th className="px-4 py-3 font-medium">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {filteredAudit.map((log) => (
                  <tr key={log.id}>
                    <td className="px-4 py-3 font-mono text-slate-500 whitespace-nowrap">
                      {formatFirestoreTimestamp(log.createdAt)}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <FileCheck2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{log.action}</span>
                    </td>
                    <td className="px-4 py-3">
                      {log.actorName} <span className="text-slate-400">({log.actorRole})</span>
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-500">
                      {log.resourceType} {log.resourceId ? `· ${log.resourceId}` : ''}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{log.details || '—'}</td>
                  </tr>
                ))}
                {filteredAudit.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-slate-400">
                      No audit events logged yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // SETTINGS & ANDROID PACKAGING BLUEPRINT
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">System Settings &amp; Android Packaging</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Configure institution defaults, legal consent, AI model selection, theme, language, and Android APK readiness.
          </p>
        </div>

        <div className="flex flex-wrap gap-1 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-lg self-start">
          {(
            [
              ['profile', 'Institution & UI'],
              ['security', 'Security & Consent'],
              ['ai', 'AI Models'],
              ['android', 'Android APK Setup'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setSettingsTab(id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                settingsTab === id
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {settingsTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-base font-semibold">Institution Profile</h2>
            <div>
              <label className="block text-xs font-medium mb-1">Institution Name</label>
              <input
                type="text"
                value={instName}
                onChange={(e) => setInstName(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium mb-1">Work Start Time (Late Cutoff)</label>
                <input
                  type="time"
                  value={workStart}
                  onChange={(e) => setWorkStart(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1">Timezone</label>
                <input
                  type="text"
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
            </div>
            {effectivePermissions.canChangeSettings && (
              <button
                type="button"
                onClick={() =>
                  updateInstitutionSettings({
                    name: instName,
                    workStartTime: workStart,
                    timezone,
                  })
                }
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
              >
                Save Institution Profile
              </button>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
            <h2 className="font-display text-base font-semibold">Appearance &amp; Localization</h2>
            <div className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-800">
              <div>
                <p className="text-sm font-medium">Interface Theme</p>
                <p className="text-xs text-slate-500">Current: {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}</p>
              </div>
              <button
                type="button"
                onClick={toggleTheme}
                className="px-3.5 py-2 rounded-lg bg-slate-900 dark:bg-indigo-600 text-white text-xs font-medium cursor-pointer"
              >
                Switch to {theme === 'dark' ? 'Light' : 'Dark'}
              </button>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Interface Language</label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                {(Object.keys(LANGUAGE_LABELS) as LanguageCode[]).map((code) => (
                  <option key={code} value={code}>
                    {LANGUAGE_LABELS[code]}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {settingsTab === 'security' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 max-w-2xl">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-600" />
            <h2 className="font-display text-base font-semibold">Security &amp; Compliance Controls</h2>
          </div>

          <label className="flex items-start gap-3 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer">
            <input
              type="checkbox"
              checked={consentReq}
              onChange={(e) => setConsentReq(e.target.checked)}
              className="mt-0.5 rounded text-indigo-600"
            />
            <div>
              <p className="text-sm font-medium">Require Explicit Call Recording Consent</p>
              <p className="text-xs text-slate-500">
                Blocks in-app audio capture unless legal participant consent has been confirmed.
              </p>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer">
            <input
              type="checkbox"
              checked={autoRecord}
              onChange={(e) => setAutoRecord(e.target.checked)}
              className="mt-0.5 rounded text-indigo-600"
            />
            <div>
              <p className="text-sm font-medium">Auto-Record Supported App-to-App &amp; SIP Calls</p>
              <p className="text-xs text-slate-500">
                Automatically initializes encrypted audio capture on supported VoIP/PBX channels when participant consent is confirmed.
              </p>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer">
            <input
              type="checkbox"
              checked={rotatingQr}
              onChange={(e) => setRotatingQr(e.target.checked)}
              className="mt-0.5 rounded text-indigo-600"
            />
            <div>
              <p className="text-sm font-medium">Default to Rotating 30s QR Credentials</p>
              <p className="text-xs text-slate-500">
                Issues time-windowed cryptographic QR badges to prevent screenshot sharing.
              </p>
            </div>
          </label>

          {effectivePermissions.canChangeSettings && (
            <button
              type="button"
              onClick={() =>
                updateInstitutionSettings({
                  recordingConsentRequired: consentReq,
                  autoRecordSupportedCalls: autoRecord,
                  rotatingQrEnabled: rotatingQr,
                })
              }
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
            >
              Save Security Policies
            </button>
          )}
        </div>
      )}

      {settingsTab === 'ai' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 max-w-2xl">
          <h2 className="font-display text-base font-semibold">Configurable AI Model Integration</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            All AI calls execute securely on the server via environment secrets. Select the active reasoning model tier and provider adapter.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">AI Provider Adapter</label>
              <select
                value={aiProvider}
                onChange={(e) => setAiProvider(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                <option value="Google Gemini">Google Gemini (Server SDK)</option>
                <option value="OpenAI-Compatible Gateway">Custom Server Gateway</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Reasoning Model</label>
              <select
                value={aiModel}
                onChange={(e) => setAiModel(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                <option value="gemini-4-hydrogen">gemini-4-hydrogen (Balanced Reasoning)</option>
                <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (High Speed)</option>
              </select>
            </div>
          </div>

          {effectivePermissions.canChangeSettings && (
            <button
              type="button"
              onClick={() => updateInstitutionSettings({ aiProvider, aiModel })}
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
            >
              Save AI Configuration
            </button>
          )}
        </div>
      )}

      {settingsTab === 'android' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-600" />
            <h2 className="font-display text-base font-semibold">Android APK Packaging &amp; Native Bridge Blueprint</h2>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            NewOpenlink ships with full Progressive Web App (PWA) installability, mobile bottom-thumb navigation, offline Firestore caching, and WebRTC/Camera APIs. To compile a signed Android APK for Google Play or enterprise MDM distribution, wrap the production <code className="font-mono">dist/</code> bundle with Capacitor 6+ and attach the required native Android components below.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <p className="text-xs font-semibold">1. Included AndroidManifest.xml Permissions</p>
              <p className="text-[11px] font-mono text-indigo-600 dark:text-indigo-400">
                /android-native/app/src/main/AndroidManifest.xml
              </p>
              <pre className="text-[11px] font-mono overflow-x-auto text-slate-700 dark:text-slate-300">
{`<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />`}
              </pre>
            </div>

            <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
              <p className="text-xs font-semibold">2. Implemented Native Kotlin Bridge Modules (/android-native/)</p>
              <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 list-disc pl-4">
                <li><code className="font-mono">telephony/TelecomConnectionService.kt</code>: Registers App-to-App VoIP &amp; SIP calls with Android Telecom framework for system call UI &amp; Bluetooth audio routing.</li>
                <li><code className="font-mono">recording/RecordingForegroundService.kt</code>: Enforces participant consent and displays the mandatory Android 14+ microphone foreground indicator during supported call capture.</li>
                <li><code className="font-mono">sync/OfflineSyncWorker.kt</code>: WorkManager periodic worker with <code className="font-mono">NetworkType.CONNECTED</code> constraint to flush offline attendance when connectivity returns.</li>
                <li><strong>OS Restriction Note</strong>: Standard Android 10+ devices prohibit third-party apps from recording cellular SIM voice lines; use SIP/PBX trunking or enterprise MDM dialers for cellular capture.</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
