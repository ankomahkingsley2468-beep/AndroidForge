import React, { useEffect, useMemo, useState } from 'react';
import {
  Building2,
  Eye,
  FolderTree,
  Plus,
  QrCode,
  Search,
  Shield,
  Trash2,
  UserPlus,
} from 'lucide-react';
import { useIMS } from '../context/IMSContext';
import {
  DEFAULT_ROLE_PERMISSIONS,
  ROLE_LABELS,
  type RolePermissions,
  type RosterMember,
  type UserRole,
} from '../types/ims';

export const OrganizationStaffView: React.FC<{ mode: 'organization' | 'staff' | 'users_rbac' }> = ({
  mode,
}) => {
  const {
    branches,
    departments,
    roster,
    members,
    effectivePermissions,
    previewRole,
    setPreviewRole,
    createBranch,
    deleteBranch,
    createDepartment,
    deleteDepartment,
    createRosterMember,
    updateRosterMember,
    deleteRosterMember,
    saveMemberRbac,
    setSelectedBadgeRosterId,
    setActiveTab,
    pushToast,
  } = useIMS();

  // Branch form
  const [brName, setBrName] = useState('');
  const [brCode, setBrCode] = useState('');
  const [brCity, setBrCity] = useState('');
  const [brCountry, setBrCountry] = useState('');
  const [brPhone, setBrPhone] = useState('');

  // Department form
  const [deptBranchId, setDeptBranchId] = useState('');
  const [deptName, setDeptName] = useState('');
  const [deptCode, setDeptCode] = useState('');
  const [deptHead, setDeptHead] = useState('');

  // Roster form
  const [rosName, setRosName] = useState('');
  const [rosCode, setRosCode] = useState('');
  const [rosBranchId, setRosBranchId] = useState('');
  const [rosDeptId, setRosDeptId] = useState('');
  const [rosType, setRosType] = useState<RosterMember['memberType']>('employee');
  const [rosTitle, setRosTitle] = useState('');
  const [rosEmail, setRosEmail] = useState('');
  const [rosPhone, setRosPhone] = useState('');
  const [rosRotating, setRosRotating] = useState(true);
  const [rosterSearch, setRosterSearch] = useState('');

  // RBAC User Invite / Edit form
  const [rbacUid, setRbacUid] = useState('');
  const [rbacEmail, setRbacEmail] = useState('');
  const [rbacName, setRbacName] = useState('');
  const [rbacRole, setRbacRole] = useState<UserRole>('attendance_officer');
  const [rbacPerms, setRbacPerms] = useState<RolePermissions>(
    DEFAULT_ROLE_PERMISSIONS.attendance_officer
  );

  useEffect(() => {
    if (!deptBranchId && branches.length > 0) setDeptBranchId(branches[0].id);
    if (!rosBranchId && branches.length > 0) setRosBranchId(branches[0].id);
  }, [branches, deptBranchId, rosBranchId]);

  useEffect(() => {
    const branchDepts = departments.filter((d) => !rosBranchId || d.branchId === rosBranchId);
    if (branchDepts.length > 0 && !branchDepts.some((d) => d.id === rosDeptId)) {
      setRosDeptId(branchDepts[0].id);
    }
  }, [departments, rosBranchId, rosDeptId]);

  const getBranchName = (id: string) => branches.find((b) => b.id === id)?.name || id;
  const getDeptName = (id: string) => departments.find((d) => d.id === id)?.name || id;

  const filteredRoster = useMemo(() => {
    if (!rosterSearch.trim()) return roster;
    const q = rosterSearch.toLowerCase();
    return roster.filter(
      (r) =>
        r.fullName.toLowerCase().includes(q) ||
        r.memberCode.toLowerCase().includes(q) ||
        (r.jobTitle || '').toLowerCase().includes(q)
    );
  }, [roster, rosterSearch]);

  if (mode === 'organization') {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Branches &amp; Departments</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Configure multi-location campuses, regional offices, and operational departments.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Branches Panel */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h2 className="font-display text-base font-semibold">Institutional Branches ({branches.length})</h2>
            </div>

            {effectivePermissions.canChangeSettings && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!brName.trim() || !brCode.trim()) return;
                  await createBranch({
                    name: brName,
                    code: brCode,
                    city: brCity,
                    country: brCountry,
                    phone: brPhone,
                  });
                  setBrName('');
                  setBrCode('');
                  setBrCity('');
                  setBrCountry('');
                  setBrPhone('');
                }}
                className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3"
              >
                <div className="grid grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    required
                    value={brName}
                    onChange={(e) => setBrName(e.target.value)}
                    placeholder="Branch Name"
                    className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                  <input
                    type="text"
                    required
                    value={brCode}
                    onChange={(e) => setBrCode(e.target.value)}
                    placeholder="Code (e.g. WEST-03)"
                    className="px-3 py-2 text-xs font-mono uppercase rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                  <input
                    type="text"
                    value={brCity}
                    onChange={(e) => setBrCity(e.target.value)}
                    placeholder="City"
                    className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                  <input
                    type="text"
                    value={brPhone}
                    onChange={(e) => setBrPhone(e.target.value)}
                    placeholder="Phone"
                    className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                </div>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Branch</span>
                </button>
              </form>
            )}

            <div className="divide-y divide-slate-200 dark:divide-slate-800">
              {branches.map((b) => (
                <div key={b.id} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold">{b.name}</p>
                    <p className="text-xs text-slate-500 font-mono">
                      {b.code} · {b.city || 'HQ'} {b.phone ? `· ${b.phone}` : ''}
                    </p>
                  </div>
                  {effectivePermissions.canChangeSettings && branches.length > 1 && (
                    <button
                      type="button"
                      onClick={() => deleteBranch(b.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Departments Panel */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2">
              <FolderTree className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h2 className="font-display text-base font-semibold">Departments ({departments.length})</h2>
            </div>

            {effectivePermissions.canManageEmployees && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!deptBranchId || !deptName.trim() || !deptCode.trim()) return;
                  await createDepartment({
                    branchId: deptBranchId,
                    name: deptName,
                    code: deptCode,
                    headName: deptHead,
                  });
                  setDeptName('');
                  setDeptCode('');
                  setDeptHead('');
                }}
                className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3"
              >
                <div className="grid grid-cols-2 gap-2.5">
                  <select
                    value={deptBranchId}
                    onChange={(e) => setDeptBranchId(e.target.value)}
                    className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  >
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    required
                    value={deptCode}
                    onChange={(e) => setDeptCode(e.target.value)}
                    placeholder="Dept Code (FIN)"
                    className="px-3 py-2 text-xs font-mono uppercase rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                  <input
                    type="text"
                    required
                    value={deptName}
                    onChange={(e) => setDeptName(e.target.value)}
                    placeholder="Department Name"
                    className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                  <input
                    type="text"
                    value={deptHead}
                    onChange={(e) => setDeptHead(e.target.value)}
                    placeholder="Department Head"
                    className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                </div>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Department</span>
                </button>
              </form>
            )}

            <div className="divide-y divide-slate-200 dark:divide-slate-800">
              {departments.map((d) => (
                <div key={d.id} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold">{d.name}</p>
                    <p className="text-xs text-slate-500">
                      {d.code} · {getBranchName(d.branchId)} {d.headName ? `· Lead: ${d.headName}` : ''}
                    </p>
                  </div>
                  {effectivePermissions.canChangeSettings && (
                    <button
                      type="button"
                      onClick={() => deleteDepartment(d.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'staff') {
    const branchDepts = departments.filter((d) => !rosBranchId || d.branchId === rosBranchId);
    return (
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Staff, Students &amp; Roster</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Manage registered institutional members across branches and issue verifiable QR credentials.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {effectivePermissions.canManageEmployees && (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (!rosName.trim() || !rosCode.trim() || !rosBranchId || !rosDeptId) {
                  pushToast('Complete required member fields.', 'error');
                  return;
                }
                await createRosterMember({
                  branchId: rosBranchId,
                  departmentId: rosDeptId,
                  memberCode: rosCode,
                  fullName: rosName,
                  email: rosEmail,
                  phone: rosPhone,
                  memberType: rosType,
                  jobTitle: rosTitle,
                  rotatingQrEnabled: rosRotating,
                });
                setRosName('');
                setRosCode('');
                setRosTitle('');
                setRosEmail('');
                setRosPhone('');
              }}
              className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3"
            >
              <div className="flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-indigo-600" />
                <h2 className="font-display text-base font-semibold">Register Member</h2>
              </div>
              <input
                type="text"
                required
                value={rosName}
                onChange={(e) => setRosName(e.target.value)}
                placeholder="Full Name"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
              <div className="grid grid-cols-2 gap-2.5">
                <input
                  type="text"
                  required
                  value={rosCode}
                  onChange={(e) => setRosCode(e.target.value)}
                  placeholder="ID Code (EMP-201)"
                  className="px-3 py-2 text-sm font-mono uppercase rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
                <select
                  value={rosType}
                  onChange={(e) => setRosType(e.target.value as RosterMember['memberType'])}
                  className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                >
                  <option value="employee">Employee</option>
                  <option value="student">Student</option>
                  <option value="faculty">Faculty</option>
                  <option value="contractor">Contractor</option>
                  <option value="visitor">Visitor</option>
                </select>
              </div>
              <select
                value={rosBranchId}
                onChange={(e) => setRosBranchId(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
              <select
                value={rosDeptId}
                onChange={(e) => setRosDeptId(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              >
                {branchDepts.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={rosTitle}
                onChange={(e) => setRosTitle(e.target.value)}
                placeholder="Role / Program Title"
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
              />
              <div className="grid grid-cols-2 gap-2.5">
                <input
                  type="email"
                  value={rosEmail}
                  onChange={(e) => setRosEmail(e.target.value)}
                  placeholder="Email"
                  className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
                <input
                  type="text"
                  value={rosPhone}
                  onChange={(e) => setRosPhone(e.target.value)}
                  placeholder="Phone"
                  className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rosRotating}
                  onChange={(e) => setRosRotating(e.target.checked)}
                  className="rounded text-indigo-600"
                />
                <span>Enable rotating 30s QR credential</span>
              </label>
              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
              >
                Register &amp; Issue QR Credential
              </button>
            </form>
          )}

          <div
            className={`${
              effectivePermissions.canManageEmployees ? 'lg:col-span-8' : 'lg:col-span-12'
            } bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden`}
          >
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
              <div className="relative flex-1 max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={rosterSearch}
                  onChange={(e) => setRosterSearch(e.target.value)}
                  placeholder="Search directory..."
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>
              <span className="text-xs text-slate-500 tabular-nums">{filteredRoster.length} members</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3 font-medium">Member</th>
                    <th className="px-4 py-3 font-medium">Type / Title</th>
                    <th className="px-4 py-3 font-medium">Branch &amp; Dept</th>
                    <th className="px-4 py-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filteredRoster.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-900 dark:text-white">{m.fullName}</p>
                        <p className="text-xs font-mono text-slate-500">{m.memberCode}</p>
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-600 dark:text-slate-300">
                        <span className="capitalize">{m.memberType}</span>
                        {m.jobTitle ? ` · ${m.jobTitle}` : ''}
                      </td>
                      <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400">
                        {getBranchName(m.branchId)} · {getDeptName(m.departmentId)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1">
                          {effectivePermissions.canManageEmployees && (
                            <button
                              type="button"
                              onClick={() =>
                                updateRosterMember(m.id, {
                                  status: m.status === 'active' ? 'inactive' : 'active',
                                })
                              }
                              className={`px-2 py-1 rounded text-[11px] font-medium cursor-pointer ${
                                m.status === 'active'
                                  ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                              }`}
                            >
                              {m.status === 'active' ? 'Active' : 'Inactive'}
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedBadgeRosterId(m.id);
                              setActiveTab('attendance');
                            }}
                            title="Open QR Badge"
                            className="p-2 rounded-lg text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 cursor-pointer"
                          >
                            <QrCode className="w-4 h-4" />
                          </button>
                          {effectivePermissions.canChangeSettings && (
                            <button
                              type="button"
                              onClick={() => deleteRosterMember(m.id)}
                              className="p-2 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // USERS & RBAC PERMISSIONS MODE
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">User Management &amp; Role Permissions</h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Configure all six institutional roles, granular access controls, and preview role-restricted views.
          </p>
        </div>

        {/* Live Role Preview Switcher */}
        <div className="flex items-center gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2">
          <Eye className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-medium text-slate-500">Preview Role:</span>
          <select
            value={previewRole || ''}
            onChange={(e) => setPreviewRole((e.target.value || null) as UserRole | null)}
            className="text-xs font-semibold bg-transparent focus:outline-none"
          >
            <option value="">Actual Assigned Role</option>
            {(Object.keys(ROLE_LABELS) as UserRole[]).map((roleKey) => (
              <option key={roleKey} value={roleKey}>
                {ROLE_LABELS[roleKey]}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Role Permission Matrix Reference */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2">
          <Shield className="w-4 h-4 text-indigo-600" />
          <h2 className="font-display text-base font-semibold">Six-Tier Default Role Matrix</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3 font-medium">Role</th>
                <th className="px-4 py-3 font-medium">Recordings</th>
                <th className="px-4 py-3 font-medium">Attendance</th>
                <th className="px-4 py-3 font-medium">Reports</th>
                <th className="px-4 py-3 font-medium">Manage Staff</th>
                <th className="px-4 py-3 font-medium">Create QR</th>
                <th className="px-4 py-3 font-medium">Settings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {(Object.keys(ROLE_LABELS) as UserRole[]).map((role) => {
                const p = DEFAULT_ROLE_PERMISSIONS[role];
                return (
                  <tr key={role}>
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                      {ROLE_LABELS[role]}
                    </td>
                    <td className="px-4 py-3">{p.canAccessRecordings ? 'Allowed' : 'Denied'}</td>
                    <td className="px-4 py-3">{p.canViewAttendance ? 'Allowed' : 'Denied'}</td>
                    <td className="px-4 py-3">{p.canGenerateReports ? 'Allowed' : 'Denied'}</td>
                    <td className="px-4 py-3">{p.canManageEmployees ? 'Allowed' : 'Denied'}</td>
                    <td className="px-4 py-3">{p.canCreateQrCodes ? 'Allowed' : 'Denied'}</td>
                    <td className="px-4 py-3">{p.canChangeSettings ? 'Allowed' : 'Denied'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign / Update Institutional Member Permissions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {effectivePermissions.canChangeSettings && (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              const uid = rbacUid.trim() || `usr_${Date.now()}`;
              await saveMemberRbac({
                uid,
                email: rbacEmail,
                displayName: rbacName,
                role: rbacRole,
                status: 'active',
                permissions: rbacPerms,
              });
              setRbacUid('');
              setRbacEmail('');
              setRbacName('');
            }}
            className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3"
          >
            <h3 className="font-display text-base font-semibold">Assign User Role &amp; Permissions</h3>
            <input
              type="text"
              required
              value={rbacName}
              onChange={(e) => setRbacName(e.target.value)}
              placeholder="Full Name"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
            <input
              type="email"
              required
              value={rbacEmail}
              onChange={(e) => setRbacEmail(e.target.value)}
              placeholder="Institutional Email"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
            <input
              type="text"
              value={rbacUid}
              onChange={(e) => setRbacUid(e.target.value)}
              placeholder="Firebase User UID (optional if new)"
              className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            />
            <select
              value={rbacRole}
              onChange={(e) => {
                const r = e.target.value as UserRole;
                setRbacRole(r);
                setRbacPerms(DEFAULT_ROLE_PERMISSIONS[r]);
              }}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950"
            >
              {(Object.keys(ROLE_LABELS) as UserRole[]).map((role) => (
                <option key={role} value={role}>
                  {ROLE_LABELS[role]}
                </option>
              ))}
            </select>

            <div className="grid grid-cols-2 gap-2 pt-1">
              {(
                [
                  ['canAccessRecordings', 'Access Recordings'],
                  ['canViewAttendance', 'View Attendance'],
                  ['canGenerateReports', 'Generate Reports'],
                  ['canManageEmployees', 'Manage Employees'],
                  ['canCreateQrCodes', 'Create QR Codes'],
                  ['canChangeSettings', 'Change Settings'],
                ] as Array<[keyof RolePermissions, string]>
              ).map(([key, label]) => (
                <label key={key} className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rbacPerms[key]}
                    onChange={(e) =>
                      setRbacPerms((prev) => ({ ...prev, [key]: e.target.checked }))
                    }
                    className="rounded text-indigo-600"
                  />
                  <span>{label}</span>
                </label>
              ))}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium cursor-pointer"
            >
              Save Member Access Policy
            </button>
          </form>
        )}

        <div
          className={`${
            effectivePermissions.canChangeSettings ? 'lg:col-span-7' : 'lg:col-span-12'
          } bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800`}
        >
          <div className="px-5 py-4 flex items-center justify-between">
            <h3 className="font-display text-base font-semibold">Active Institution Accounts ({members.length})</h3>
          </div>
          {members.map((m) => (
            <div key={m.uid} className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <p className="text-sm font-semibold">{m.displayName}</p>
                <p className="text-xs text-slate-500">
                  {m.email} · {ROLE_LABELS[m.role]} · {m.status}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-xs text-slate-500 font-mono">
                  {[
                    m.canAccessRecordings && 'Calls',
                    m.canViewAttendance && 'Attendance',
                    m.canGenerateReports && 'Reports',
                    m.canManageEmployees && 'Staff',
                  ]
                    .filter(Boolean)
                    .join(' · ') || 'Read-Only'}
                </div>
                {effectivePermissions.canChangeSettings && (
                  <button
                    type="button"
                    onClick={() => {
                      setRbacUid(m.uid);
                      setRbacEmail(m.email);
                      setRbacName(m.displayName);
                      setRbacRole(m.role);
                      setRbacPerms({
                        canAccessRecordings: Boolean(m.canAccessRecordings),
                        canViewAttendance: Boolean(m.canViewAttendance),
                        canGenerateReports: Boolean(m.canGenerateReports),
                        canManageEmployees: Boolean(m.canManageEmployees),
                        canCreateQrCodes: Boolean(m.canCreateQrCodes),
                        canChangeSettings: Boolean(m.canChangeSettings),
                      });
                    }}
                    className="px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium cursor-pointer"
                  >
                    Edit
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
