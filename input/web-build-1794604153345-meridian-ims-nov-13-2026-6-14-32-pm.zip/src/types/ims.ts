export type UserRole =
  | 'super_admin'
  | 'institution_admin'
  | 'branch_admin'
  | 'department_manager'
  | 'employee'
  | 'attendance_officer';

export type InstitutionType =
  | 'university'
  | 'school'
  | 'hospital'
  | 'corporate'
  | 'government'
  | 'nonprofit'
  | 'other';

export interface RolePermissions {
  canAccessRecordings: boolean;
  canViewAttendance: boolean;
  canGenerateReports: boolean;
  canManageEmployees: boolean;
  canCreateQrCodes: boolean;
  canChangeSettings: boolean;
}

export const ROLE_LABELS: Record<UserRole, string> = {
  super_admin: 'Super Administrator',
  institution_admin: 'Institution Administrator',
  branch_admin: 'Branch Administrator',
  department_manager: 'Department Manager',
  employee: 'Employee',
  attendance_officer: 'Attendance Officer',
};

export const DEFAULT_ROLE_PERMISSIONS: Record<UserRole, RolePermissions> = {
  super_admin: {
    canAccessRecordings: true,
    canViewAttendance: true,
    canGenerateReports: true,
    canManageEmployees: true,
    canCreateQrCodes: true,
    canChangeSettings: true,
  },
  institution_admin: {
    canAccessRecordings: true,
    canViewAttendance: true,
    canGenerateReports: true,
    canManageEmployees: true,
    canCreateQrCodes: true,
    canChangeSettings: true,
  },
  branch_admin: {
    canAccessRecordings: true,
    canViewAttendance: true,
    canGenerateReports: true,
    canManageEmployees: true,
    canCreateQrCodes: true,
    canChangeSettings: false,
  },
  department_manager: {
    canAccessRecordings: true,
    canViewAttendance: true,
    canGenerateReports: true,
    canManageEmployees: true,
    canCreateQrCodes: true,
    canChangeSettings: false,
  },
  employee: {
    canAccessRecordings: false,
    canViewAttendance: false,
    canGenerateReports: false,
    canManageEmployees: false,
    canCreateQrCodes: false,
    canChangeSettings: false,
  },
  attendance_officer: {
    canAccessRecordings: false,
    canViewAttendance: true,
    canGenerateReports: true,
    canManageEmployees: false,
    canCreateQrCodes: true,
    canChangeSettings: false,
  },
};

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  institutionId?: string;
  branchId?: string;
  departmentId?: string;
  language?: string;
  themePreference?: 'light' | 'dark' | 'system';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Institution {
  id: string;
  name: string;
  type: InstitutionType;
  code: string;
  country?: string;
  timezone?: string;
  ownerUid: string;
  workStartTime?: string;
  recordingConsentRequired?: boolean;
  autoRecordSupportedCalls?: boolean;
  rotatingQrEnabled?: boolean;
  aiProvider?: string;
  aiModel?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface InstitutionMember extends RolePermissions {
  uid: string;
  institutionId: string;
  email: string;
  displayName: string;
  role: UserRole;
  branchId?: string;
  departmentId?: string;
  status: 'active' | 'suspended' | 'invited';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Branch {
  id: string;
  institutionId: string;
  name: string;
  code: string;
  city?: string;
  country?: string;
  address?: string;
  phone?: string;
  status: 'active' | 'inactive';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface Department {
  id: string;
  institutionId: string;
  branchId: string;
  name: string;
  code: string;
  headName?: string;
  status: 'active' | 'inactive';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface RosterMember {
  id: string;
  institutionId: string;
  branchId: string;
  departmentId: string;
  memberCode: string;
  fullName: string;
  email?: string;
  phone?: string;
  memberType: 'employee' | 'student' | 'faculty' | 'contractor' | 'visitor';
  jobTitle?: string;
  qrSecret: string;
  rotatingQrEnabled?: boolean;
  status: 'active' | 'inactive';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AttendanceRecord {
  id: string;
  institutionId: string;
  rosterId: string;
  memberName: string;
  memberCode: string;
  branchId: string;
  departmentId: string;
  dateKey: string;
  checkInIso: string;
  checkOutIso?: string;
  status: 'present' | 'late' | 'absent' | 'checked_out';
  verificationMode?: 'static_qr' | 'rotating_qr' | 'manual_officer';
  deviceInfo?: string;
  recordedByUid: string;
  recordedByName?: string;
  offlineCaptured?: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface OfflineAttendanceQueueItem {
  localId: string;
  institutionId: string;
  rosterId: string;
  memberName: string;
  memberCode: string;
  branchId: string;
  departmentId: string;
  dateKey: string;
  checkInIso: string;
  status: 'present' | 'late';
  verificationMode: 'static_qr' | 'rotating_qr' | 'manual_officer';
  deviceInfo: string;
  recordedByUid: string;
  recordedByName: string;
  action: 'check_in' | 'check_out';
  existingAttendanceId?: string;
  queuedAtMs?: number;
  lastError?: string;
}

export interface OfflineActivityLogQueueItem {
  localId: string;
  institutionId: string;
  actorUid: string;
  actorName: string;
  actorRole: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  details?: string;
  queuedAtMs: number;
  lastError?: string;
}

export interface CallRecord {
  id: string;
  institutionId: string;
  callerName: string;
  callerNumber?: string;
  recipientName: string;
  recipientNumber?: string;
  direction: 'inbound' | 'outbound' | 'internal';
  callSource: 'pbx_sip' | 'app_webrtc' | 'android_sim_bridge' | 'uploaded_audio';
  startedAtIso: string;
  durationSeconds: number;
  branchId?: string;
  departmentId?: string;
  assignedToRosterId?: string;
  assignedToName?: string;
  category: string;
  status: 'completed' | 'missed' | 'follow_up' | 'escalated' | 'archived';
  consentRecorded: boolean;
  consentNotice?: string;
  recordingId?: string;
  recordingEncrypted?: boolean;
  transcript?: string;
  aiSummary?: string;
  aiSuggestedCategory?: string;
  notes?: string;
  createdByUid: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CallCategory {
  id: string;
  institutionId: string;
  name: string;
  description?: string;
  defaultDepartmentId?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface NotificationItem {
  id: string;
  institutionId: string;
  type:
    | 'attendance'
    | 'late_arrival'
    | 'missed_attendance'
    | 'important_call'
    | 'assigned_call'
    | 'announcement'
    | 'system';
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'urgent';
  isRead: boolean;
  createdByUid: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AuditLog {
  id: string;
  institutionId: string;
  actorUid: string;
  actorName: string;
  actorRole: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  details?: string;
  createdAt?: unknown;
}

export interface BackupRecord {
  id: string;
  institutionId: string;
  destination: 'cloud_snapshot' | 'google_drive_export' | 'local_encrypted_archive';
  createdByUid: string;
  createdByName?: string;
  recordCount: number;
  checksum: string;
  encrypted: boolean;
  createdAt?: unknown;
}

export type ActiveTab =
  | 'dashboard'
  | 'super_admin'
  | 'attendance'
  | 'calls'
  | 'ai_assistant'
  | 'organization'
  | 'staff'
  | 'reports'
  | 'users_rbac'
  | 'backups'
  | 'notifications'
  | 'audit'
  | 'settings';
