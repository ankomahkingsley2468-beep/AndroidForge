import type {
  OfflineActivityLogQueueItem,
  OfflineAttendanceQueueItem,
} from '../types/ims';

export const OFFLINE_DB_NAME = 'meridian-ims-offline-db';
export const OFFLINE_DB_VERSION = 2;
export const ATTENDANCE_STORE = 'attendance_queue';
export const ACTIVITY_STORE = 'activity_log_queue';
export const META_STORE = 'sync_meta';
export const SYNC_TAG = 'meridian-firebase-sync';

function openOfflineDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(OFFLINE_DB_NAME, OFFLINE_DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(ATTENDANCE_STORE)) {
        const attStore = db.createObjectStore(ATTENDANCE_STORE, { keyPath: 'localId' });
        attStore.createIndex('institutionId', 'institutionId', { unique: false });
        attStore.createIndex('queuedAtMs', 'queuedAtMs', { unique: false });
      }
      if (!db.objectStoreNames.contains(ACTIVITY_STORE)) {
        const actStore = db.createObjectStore(ACTIVITY_STORE, { keyPath: 'localId' });
        actStore.createIndex('institutionId', 'institutionId', { unique: false });
        actStore.createIndex('queuedAtMs', 'queuedAtMs', { unique: false });
      }
      if (!db.objectStoreNames.contains(META_STORE)) {
        db.createObjectStore(META_STORE, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('Failed to open IndexedDB'));
  });
}

async function putInStore<T>(storeName: string, record: T): Promise<void> {
  const db = await openOfflineDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).put(record);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error(`Failed writing to ${storeName}`));
    };
  });
}

async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  const db = await openOfflineDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => {
      db.close();
      resolve((req.result || []) as T[]);
    };
    req.onerror = () => {
      db.close();
      reject(req.error || new Error(`Failed reading ${storeName}`));
    };
  });
}

async function deleteFromStore(storeName: string, key: string): Promise<void> {
  const db = await openOfflineDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(key);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error(`Failed deleting ${key} from ${storeName}`));
    };
  });
}

export async function getQueuedAttendance(): Promise<OfflineAttendanceQueueItem[]> {
  if (typeof indexedDB === 'undefined') return [];
  const items = await getAllFromStore<OfflineAttendanceQueueItem>(ATTENDANCE_STORE);
  return items.sort((a, b) => (a.queuedAtMs || 0) - (b.queuedAtMs || 0));
}

export async function getQueuedActivityLogs(): Promise<OfflineActivityLogQueueItem[]> {
  if (typeof indexedDB === 'undefined') return [];
  const items = await getAllFromStore<OfflineActivityLogQueueItem>(ACTIVITY_STORE);
  return items.sort((a, b) => a.queuedAtMs - b.queuedAtMs);
}

export async function removeQueuedAttendance(localId: string): Promise<void> {
  await deleteFromStore(ATTENDANCE_STORE, localId);
}

export async function removeQueuedActivityLog(localId: string): Promise<void> {
  await deleteFromStore(ACTIVITY_STORE, localId);
}

export async function updateQueuedAttendanceError(
  item: OfflineAttendanceQueueItem,
  errorMsg: string
): Promise<void> {
  await putInStore(ATTENDANCE_STORE, { ...item, lastError: errorMsg.slice(0, 200) });
}

export async function updateQueuedActivityError(
  item: OfflineActivityLogQueueItem,
  errorMsg: string
): Promise<void> {
  await putInStore(ACTIVITY_STORE, { ...item, lastError: errorMsg.slice(0, 200) });
}

async function sendToServiceWorker(message: Record<string, unknown>): Promise<boolean> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return false;
  try {
    const reg = await navigator.serviceWorker.ready;
    const target = reg.active || navigator.serviceWorker.controller;
    if (target) {
      target.postMessage(message);
    }
    if ('sync' in reg) {
      try {
        await (reg as ServiceWorkerRegistration & { sync: { register: (tag: string) => Promise<void> } }).sync.register(SYNC_TAG);
      } catch {
        // Background Sync API permission may be denied in incognito/non-installed context; online listener handles fallback
      }
    }
    return Boolean(target);
  } catch {
    return false;
  }
}

export async function enqueueAttendanceOffline(item: OfflineAttendanceQueueItem): Promise<void> {
  const payload: OfflineAttendanceQueueItem = {
    ...item,
    queuedAtMs: item.queuedAtMs || Date.now(),
  };
  await putInStore(ATTENDANCE_STORE, payload);
  await sendToServiceWorker({ type: 'ENQUEUE_OFFLINE_ATTENDANCE', payload });
}

export async function enqueueActivityLogOffline(item: OfflineActivityLogQueueItem): Promise<void> {
  const payload: OfflineActivityLogQueueItem = {
    ...item,
    queuedAtMs: item.queuedAtMs || Date.now(),
  };
  await putInStore(ACTIVITY_STORE, payload);
  await sendToServiceWorker({ type: 'ENQUEUE_OFFLINE_ACTIVITY', payload });
}

export async function registerBackgroundSyncWithSW(): Promise<void> {
  await sendToServiceWorker({ type: 'REGISTER_SYNC' });
}

export async function triggerServiceWorkerQueueFlush(): Promise<boolean> {
  return sendToServiceWorker({ type: 'TRIGGER_SYNC' });
}

export interface HeadlessSyncStatus {
  lastHeadlessSyncAt?: string;
  lastHeadlessSyncAttCount?: number;
  lastHeadlessSyncActCount?: number;
  lastHeadlessSyncError?: string;
}

async function getFromStore<T>(storeName: string, key: string): Promise<T | null> {
  const db = await openOfflineDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => {
      db.close();
      resolve((req.result || null) as T | null);
    };
    req.onerror = () => {
      db.close();
      reject(req.error || new Error(`Failed reading ${key} from ${storeName}`));
    };
  });
}

export async function getHeadlessSyncStatus(): Promise<HeadlessSyncStatus | null> {
  if (typeof indexedDB === 'undefined') return null;
  try {
    return await getFromStore<HeadlessSyncStatus>(META_STORE, 'headless_sync_status');
  } catch {
    return null;
  }
}

export async function clearQueueErrors(): Promise<void> {
  if (typeof indexedDB === 'undefined') return;
  const [attItems, actItems] = await Promise.all([
    getQueuedAttendance(),
    getQueuedActivityLogs(),
  ]);
  for (const item of attItems) {
    if (item.lastError) {
      const clean = { ...item };
      delete clean.lastError;
      await putInStore(ATTENDANCE_STORE, clean);
    }
  }
  for (const act of actItems) {
    if (act.lastError) {
      const clean = { ...act };
      delete clean.lastError;
      await putInStore(ACTIVITY_STORE, clean);
    }
  }
}

export async function syncAuthContextToServiceWorker(context: {
  idToken: string;
  projectId: string;
  databaseId: string;
}): Promise<void> {
  if (typeof indexedDB !== 'undefined') {
    try {
      await putInStore(META_STORE, { key: 'auth_context', ...context, updatedAtMs: Date.now() });
    } catch {
      // ignore
    }
  }
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.ready;
    const target = reg.active || navigator.serviceWorker.controller;
    if (target) {
      target.postMessage({ type: 'SYNC_AUTH_CONTEXT', payload: context });
    }
  } catch {
    // ignore
  }
}
