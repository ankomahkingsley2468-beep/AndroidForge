import QRCode from 'qrcode';
import type { RosterMember } from '../types/ims';

function simpleHash(input: string): string {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < input.length; i++) {
    const ch = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36).toUpperCase();
}

export function getRotatingTimeSlot(nowMs = Date.now(), windowSeconds = 30): number {
  return Math.floor(nowMs / (windowSeconds * 1000));
}

export function buildMemberQrPayload(
  member: RosterMember,
  forceRotating?: boolean,
  nowMs = Date.now()
): { payload: string; mode: 'static_qr' | 'rotating_qr'; expiresInSeconds: number } {
  const useRotating = forceRotating ?? Boolean(member.rotatingQrEnabled);
  if (useRotating) {
    const slot = getRotatingTimeSlot(nowMs, 30);
    const sig = simpleHash(`${member.institutionId}:${member.id}:${member.qrSecret}:${slot}`);
    const elapsedInSlot = Math.floor((nowMs % 30000) / 1000);
    return {
      payload: `MERIDIAN:ROT:${member.institutionId}:${member.id}:${slot}:${sig}`,
      mode: 'rotating_qr',
      expiresInSeconds: 30 - elapsedInSlot,
    };
  }
  const sig = simpleHash(`${member.institutionId}:${member.id}:${member.qrSecret}:STATIC`);
  return {
    payload: `MERIDIAN:STC:${member.institutionId}:${member.id}:0:${sig}`,
    mode: 'static_qr',
    expiresInSeconds: 0,
  };
}

export function verifyQrPayload(
  rawPayload: string,
  institutionId: string,
  roster: RosterMember[]
): {
  valid: boolean;
  reason?: string;
  member?: RosterMember;
  mode?: 'static_qr' | 'rotating_qr';
} {
  const trimmed = rawPayload.trim();
  const parts = trimmed.split(':');
  if (parts.length !== 6 || parts[0] !== 'MERIDIAN') {
    return { valid: false, reason: 'Unrecognized QR format. Expected Meridian IMS verifiable credential.' };
  }

  const [, modeCode, qrInstId, rosterId, slotStr, sig] = parts;
  if (qrInstId !== institutionId) {
    return { valid: false, reason: 'QR credential belongs to a different institution.' };
  }

  const member = roster.find((m) => m.id === rosterId);
  if (!member) {
    return { valid: false, reason: 'Member not found in institutional roster.' };
  }

  if (member.status !== 'active') {
    return { valid: false, reason: `Member ${member.fullName} is currently inactive.` };
  }

  if (modeCode === 'ROT') {
    const currentSlot = getRotatingTimeSlot(Date.now(), 30);
    const scannedSlot = Number(slotStr);
    // Allow current slot or +/- 1 slot (30s drift grace) to prevent scan edge failure while blocking screenshot reuse
    if (Number.isNaN(scannedSlot) || Math.abs(currentSlot - scannedSlot) > 1) {
      return { valid: false, reason: 'Rotating QR token expired. Present a live credential screen.' };
    }
    const expectedSig = simpleHash(`${member.institutionId}:${member.id}:${member.qrSecret}:${scannedSlot}`);
    if (sig !== expectedSig) {
      return { valid: false, reason: 'Invalid cryptographic signature on rotating QR.' };
    }
    return { valid: true, member, mode: 'rotating_qr' };
  }

  if (modeCode === 'STC') {
    const expectedSig = simpleHash(`${member.institutionId}:${member.id}:${member.qrSecret}:STATIC`);
    if (sig !== expectedSig) {
      return { valid: false, reason: 'Invalid static QR signature.' };
    }
    return { valid: true, member, mode: 'static_qr' };
  }

  return { valid: false, reason: 'Unsupported QR verification mode.' };
}

export async function generateQrDataUrl(text: string, dark = false): Promise<string> {
  return QRCode.toDataURL(text, {
    width: 320,
    margin: 2,
    errorCorrectionLevel: 'M',
    color: {
      dark: dark ? '#f8fafc' : '#0f172a',
      light: dark ? '#0f172a' : '#ffffff',
    },
  });
}
