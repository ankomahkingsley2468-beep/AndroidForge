export type LanguageCode = 'en' | 'fr' | 'es';

export const LANGUAGE_LABELS: Record<LanguageCode, string> = {
  en: 'English',
  fr: 'Français',
  es: 'Español',
};

const DICTIONARY: Record<LanguageCode, Record<string, string>> = {
  en: {
    dashboard: 'Executive Dashboard',
    super_admin: 'Super Admin',
    attendance: 'QR Attendance',
    calls: 'Call Management',
    ai_assistant: 'AI Assistant',
    organization: 'Branches & Depts',
    staff: 'Staff & Roster',
    reports: 'Reports & Analytics',
    users_rbac: 'Users & Roles',
    backups: 'Backups & Sync',
    notifications: 'Notifications',
    audit: 'Audit Logs',
    settings: 'Settings',
    more: 'More',
    sign_out: 'Sign Out',
    offline_banner: 'Offline Mode — Attendance scans queue locally and sync automatically.',
  },
  fr: {
    dashboard: 'Tableau de bord',
    super_admin: 'Super Admin',
    attendance: 'Présence QR',
    calls: 'Gestion d’appels',
    ai_assistant: 'Assistant IA',
    organization: 'Succursales & Dépts',
    staff: 'Personnel & Registre',
    reports: 'Rapports & Analyses',
    users_rbac: 'Utilisateurs & Rôles',
    backups: 'Sauvegardes & Sync',
    notifications: 'Notifications',
    audit: 'Journal d’audit',
    settings: 'Paramètres',
    more: 'Plus',
    sign_out: 'Déconnexion',
    offline_banner: 'Mode hors ligne — Les scans QR sont mis en file et synchronisés automatiquement.',
  },
  es: {
    dashboard: 'Panel Ejecutivo',
    super_admin: 'Super Admin',
    attendance: 'Asistencia QR',
    calls: 'Gestión de Llamadas',
    ai_assistant: 'Asistente IA',
    organization: 'Sucursales y Deptos',
    staff: 'Personal y Registro',
    reports: 'Reportes y Analítica',
    users_rbac: 'Usuarios y Roles',
    backups: 'Respaldos y Sinc.',
    notifications: 'Notificaciones',
    audit: 'Registros de Auditoría',
    settings: 'Configuración',
    more: 'Más',
    sign_out: 'Cerrar sesión',
    offline_banner: 'Modo sin conexión — Los escaneos QR se guardan y sincronizan automáticamente.',
  },
};

export function t(lang: LanguageCode, key: string): string {
  return DICTIONARY[lang]?.[key] ?? DICTIONARY.en[key] ?? key;
}
