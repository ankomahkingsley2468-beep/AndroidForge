/// <reference lib="webworker" />
import { clientsClaim } from 'workbox-core';
import { cleanupOutdatedCaches, precacheAndRoute } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { CacheFirst } from 'workbox-strategies';
import { ExpirationPlugin } from 'workbox-expiration';
import { CacheableResponsePlugin } from 'workbox-cacheable-response';

declare let self: ServiceWorkerGlobalScope & {
  __WB_MANIFEST: Array<{ url: string; revision: string | null }>;
};

const DB_NAME = 'meridian-ims-offline-db';
const DB_VERSION = 2;
const ATTENDANCE_STORE = 'attendance_queue';
const ACTIVITY_STORE = 'activity_log_queue';
const META_STORE = 'sync_meta';
const SYNC_TAG = 'meridian-firebase-sync';

interface AuthContext {
  idToken: string;
  projectId: string;
  databaseId: string;
}

let cachedAuthContext: AuthContext | null = null;

self.skipWaiting();
clientsClaim();

cleanupOutdatedCaches();
precacheAndRoute(self.__WB_MANIFEST || []);

registerRoute(
  ({ url }) => url.origin === 'https://fonts.googleapis.com' || url.origin === 'https://fonts.gstatic.com',
  new CacheFirst({
    cacheName: 'meridian-fonts-cache',
    plugins: [
      new CacheableResponsePlugin({ statuses: [0, 200] }),
      new ExpirationPlugin({ maxEntries: 16, maxAgeSeconds: 60 * 60 * 24 * 365 }),
    ],
  })
);

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(ATTENDANCE_STORE)) {
        const s1 = db.createObjectStore(ATTENDANCE_STORE, { keyPath: 'localId' });
        s1.createIndex('institutionId', 'institutionId', { unique: false });
        s1.createIndex('queuedAtMs', 'queuedAtMs', { unique: false });
      }
      if (!db.objectStoreNames.contains(ACTIVITY_STORE)) {
        const s2 = db.createObjectStore(ACTIVITY_STORE, { keyPath: 'localId' });
        s2.createIndex('institutionId', 'institutionId', { unique: false });
        s2.createIndex('queuedAtMs', 'queuedAtMs', { unique: false });
      }
      if (!db.objectStoreNames.contains(META_STORE)) {
        db.createObjectStore(META_STORE, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbPut(storeName: string, item: unknown): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).put(item);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
  });
}

async function idbGet<T>(storeName: string, key: string): Promise<T | null> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => {
      db.close();
      resolve((req.result || null) as T | null);
    };
    req.onerror = () => {
      db.close();
      reject(req.error);
    };
  });
}

async function idbGetAll<T>(storeName: string): Promise<T[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => {
      db.close();
      resolve((req.result || []) as T[]);
    };
    req.onerror = () => {
      db.close();
      reject(req.error);
    };
  });
}

async function idbDelete(storeName: string, key: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(key);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
  });
}

async function broadcastToClients(msg: Record<string, unknown>) {
  const allClients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of allClients) {
    client.postMessage(msg);
  }
}

function toFirestoreFields(obj: Record<string, unknown>): Record<string, unknown> {
  const fields: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null) continue;
    if (typeof v === 'string') fields[k] = { stringValue: v };
    else if (typeof v === 'boolean') fields[k] = { booleanValue: v };
    else if (typeof v === 'number') {
      if (Number.isInteger(v)) fields[k] = { integerValue: String(v) };
      else fields[k] = { doubleValue: v };
    }
  }
  return fields;
}

async function commitDocViaRest(
  ctx: AuthContext,
  docPath: string,
  fieldsObj: Record<string, unknown>,
  serverTimeFields: string[],
  updateMaskFields?: string[]
): Promise<{ ok: boolean; error?: string }> {
  const fullName = `projects/${ctx.projectId}/databases/${ctx.databaseId}/documents/${docPath}`;
  const url = `https://firestore.googleapis.com/v1/projects/${ctx.projectId}/databases/${ctx.databaseId}/documents:commit`;

  const writeOp: Record<string, unknown> = {
    update: {
      name: fullName,
      fields: toFirestoreFields(fieldsObj),
    },
    updateTransforms: serverTimeFields.map((fieldPath) => ({
      fieldPath,
      setToServerValue: 'REQUEST_TIME',
    })),
  };

  if (updateMaskFields && updateMaskFields.length > 0) {
    writeOp.updateMask = { fieldPaths: updateMaskFields };
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${ctx.idToken}`,
    },
    body: JSON.stringify({ writes: [writeOp] }),
  });

  if (!res.ok) {
    return { ok: false, error: `HTTP ${res.status} (${res.statusText || 'Firestore REST error'})` };
  }
  return { ok: true };
}

async function getActiveAuthContext(): Promise<AuthContext | null> {
  if (cachedAuthContext) return cachedAuthContext;
  try {
    const stored = await idbGet<AuthContext & { key: string }>(META_STORE, 'auth_context');
    if (stored?.idToken && stored?.projectId && stored?.databaseId) {
      cachedAuthContext = {
        idToken: stored.idToken,
        projectId: stored.projectId,
        databaseId: stored.databaseId,
      };
      return cachedAuthContext;
    }
  } catch {
    // ignore
  }
  return null;
}

async function flushQueueInBackground(): Promise<void> {
  const attendanceItems = (await idbGetAll<Record<string, unknown>>(ATTENDANCE_STORE)).sort(
    (a, b) => Number(a.queuedAtMs || 0) - Number(b.queuedAtMs || 0)
  );
  const activityItems = (await idbGetAll<Record<string, unknown>>(ACTIVITY_STORE)).sort(
    (a, b) => Number(a.queuedAtMs || 0) - Number(b.queuedAtMs || 0)
  );

  if (attendanceItems.length === 0 && activityItems.length === 0) return;

  // Notify open window clients first so Firebase SDK can sync with fresh auth & persistent cache
  const openClients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  if (openClients.length > 0) {
    await broadcastToClients({
      type: 'SW_TRIGGER_FIREBASE_SYNC',
      attendanceCount: attendanceItems.length,
      activityCount: activityItems.length,
    });
    return;
  }

  // Headless background sync fallback when no app tabs are open
  const authCtx = await getActiveAuthContext();
  if (!authCtx) return;

  let syncedAtt = 0;
  let syncedAct = 0;
  let lastError: string | undefined;

  for (const item of attendanceItems) {
    try {
      const localId = String(item.localId || '');
      const instId = String(item.institutionId || '');
      if (!localId || !instId) continue;

      if (item.action === 'check_out' && item.existingAttendanceId) {
        const docPath = `institutions/${instId}/attendance/${String(item.existingAttendanceId)}`;
        const result = await commitDocViaRest(
          authCtx,
          docPath,
          { checkOutIso: item.checkInIso, status: 'checked_out' },
          ['updatedAt'],
          ['checkOutIso', 'status']
        );
        if (result.ok) {
          await idbDelete(ATTENDANCE_STORE, localId);
          syncedAtt++;
        } else if (result.error) {
          lastError = result.error;
          await idbPut(ATTENDANCE_STORE, { ...item, lastError: result.error });
        }
      } else {
        const docPath = `institutions/${instId}/attendance/${localId}`;
        const result = await commitDocViaRest(
          authCtx,
          docPath,
          {
            id: localId,
            institutionId: instId,
            rosterId: item.rosterId,
            memberName: item.memberName,
            memberCode: item.memberCode,
            branchId: item.branchId,
            departmentId: item.departmentId,
            dateKey: item.dateKey,
            checkInIso: item.checkInIso,
            status: item.status,
            verificationMode: item.verificationMode,
            deviceInfo: item.deviceInfo,
            recordedByUid: item.recordedByUid,
            recordedByName: item.recordedByName,
            offlineCaptured: true,
          },
          ['createdAt', 'updatedAt']
        );
        if (result.ok) {
          await idbDelete(ATTENDANCE_STORE, localId);
          syncedAtt++;
        } else if (result.error) {
          lastError = result.error;
          await idbPut(ATTENDANCE_STORE, { ...item, lastError: result.error });
        }
      }
    } catch (err) {
      lastError = err instanceof Error ? err.message : 'Headless network error';
    }
  }

  for (const act of activityItems) {
    try {
      const localId = String(act.localId || '');
      const instId = String(act.institutionId || '');
      if (!localId || !instId) continue;
      const docPath = `institutions/${instId}/auditLogs/${localId}`;
      const result = await commitDocViaRest(
        authCtx,
        docPath,
        {
          id: localId,
          institutionId: instId,
          actorUid: act.actorUid,
          actorName: act.actorName,
          actorRole: act.actorRole,
          action: act.action,
          resourceType: act.resourceType,
          resourceId: act.resourceId,
          details: act.details,
        },
        ['createdAt']
      );
      if (result.ok) {
        await idbDelete(ACTIVITY_STORE, localId);
        syncedAct++;
      } else if (result.error) {
        lastError = result.error;
        await idbPut(ACTIVITY_STORE, { ...act, lastError: result.error });
      }
    } catch (err) {
      lastError = err instanceof Error ? err.message : 'Headless network error';
    }
  }

  await idbPut(META_STORE, {
    key: 'headless_sync_status',
    lastHeadlessSyncAt: new Date().toISOString(),
    lastHeadlessSyncAttCount: syncedAtt,
    lastHeadlessSyncActCount: syncedAct,
    ...(lastError ? { lastHeadlessSyncError: lastError } : {}),
  }).catch(() => undefined);
}

self.addEventListener('message', (event) => {
  const data = event.data as { type?: string; payload?: unknown } | undefined;
  if (!data || !data.type) return;

  if (data.type === 'SYNC_AUTH_CONTEXT' && data.payload) {
    cachedAuthContext = data.payload as AuthContext;
    event.waitUntil(
      idbPut(META_STORE, { key: 'auth_context', ...cachedAuthContext, updatedAtMs: Date.now() }).catch(() => undefined)
    );
    return;
  }

  if (data.type === 'ENQUEUE_OFFLINE_ATTENDANCE' && data.payload) {
    event.waitUntil(
      idbPut(ATTENDANCE_STORE, data.payload).then(() =>
        broadcastToClients({ type: 'SW_QUEUE_UPDATED' })
      )
    );
    return;
  }

  if (data.type === 'ENQUEUE_OFFLINE_ACTIVITY' && data.payload) {
    event.waitUntil(
      idbPut(ACTIVITY_STORE, data.payload).then(() =>
        broadcastToClients({ type: 'SW_QUEUE_UPDATED' })
      )
    );
    return;
  }

  if (data.type === 'REGISTER_SYNC') {
    const reg = self.registration as ServiceWorkerRegistration & {
      sync?: { register: (tag: string) => Promise<void> };
    };
    if (reg.sync) {
      event.waitUntil(reg.sync.register(SYNC_TAG).catch(() => undefined));
    }
    return;
  }

  if (data.type === 'TRIGGER_SYNC') {
    event.waitUntil(flushQueueInBackground());
  }
});

self.addEventListener('sync', (event) => {
  const syncEvent = event as ExtendableEvent & { tag?: string };
  if (syncEvent.tag === SYNC_TAG) {
    syncEvent.waitUntil(flushQueueInBackground());
  }
});

self.addEventListener('periodicsync', (event) => {
  const syncEvent = event as ExtendableEvent & { tag?: string };
  if (syncEvent.tag === SYNC_TAG) {
    syncEvent.waitUntil(flushQueueInBackground());
  }
});
