import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, onIdTokenChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromCache,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  auth,
  db,
  ensureFirestoreOnline,
  googleProvider,
  handleFirestoreError,
  isFirestoreUnavailableError,
  OperationType,
  SUPER_ADMIN_EMAIL,
  validateFirestoreConnection,
} from '../lib/firebase';
import {
  DEFAULT_ROLE_PERMISSIONS,
  type ActiveTab,
  type AttendanceRecord,
  type AuditLog,
  type BackupRecord,
  type Branch,
  type CallCategory,
  type CallRecord,
  type Department,
  type Institution,
  type InstitutionMember,
  type InstitutionType,
  type NotificationItem,
  type OfflineActivityLogQueueItem,
  type OfflineAttendanceQueueItem,
  type RolePermissions,
  type RosterMember,
  type UserProfile,
  type UserRole,
} from '../types/ims';
import { useOnlineStatus } from '../hooks/usePWA';
import type { LanguageCode } from '../lib/i18n';
import {
  clearQueueErrors,
  enqueueActivityLogOffline,
  enqueueAttendanceOffline,
  getHeadlessSyncStatus,
  getQueuedActivityLogs,
  getQueuedAttendance,
  registerBackgroundSyncWithSW,
  removeQueuedActivityLog,
  removeQueuedAttendance,
  syncAuthContextToServiceWorker,
  triggerServiceWorkerQueueFlush,
  updateQueuedActivityError,
  updateQueuedAttendanceError,
  type HeadlessSyncStatus,
} from '../lib/offlineDb';

const THEME_STORAGE_KEY = 'meridian_theme_v1';
const LANG_STORAGE_KEY = 'meridian_lang_v1';

export function makeId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${Date.now()}_${rand}`;
}

function stripUndefined<T extends Record<string, unknown>>(obj: T): T {
  const clean: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) clean[k] = v;
  }
  return clean as T;
}

export function todayDateKey(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

interface ToastMessage {
  id: string;
  title: string;
  tone: 'success' | 'error' | 'info';
}

interface IMSContextValue {
  firebaseUser: User | null;
  authLoading: boolean;
  authError: string | null;
  userProfile: UserProfile | null;
  institutions: Institution[];
  activeInstitution: Institution | null;
  activeMember: InstitutionMember | null;
  effectiveRole: UserRole;
  effectivePermissions: RolePermissions;
  previewRole: UserRole | null;
  setPreviewRole: (role: UserRole | null) => void;
  selectedBadgeRosterId: string | null;
  setSelectedBadgeRosterId: (id: string | null) => void;
  branches: Branch[];
  departments: Department[];
  roster: RosterMember[];
  attendance: AttendanceRecord[];
  calls: CallRecord[];
  callCategories: CallCategory[];
  members: InstitutionMember[];
  notifications: NotificationItem[];
  auditLogs: AuditLog[];
  backups: BackupRecord[];
  offlineQueue: OfflineAttendanceQueueItem[];
  offlineActivityQueue: OfflineActivityLogQueueItem[];
  isOnline: boolean;
  browserOnline: boolean;
  simulatedOffline: boolean;
  setSimulatedOffline: (offline: boolean) => void;
  swStatus: 'active' | 'registering' | 'unsupported';
  swScope: string | null;
  lastSyncedAt: string | null;
  headlessSyncStatus: HeadlessSyncStatus | null;
  isSyncingOffline: boolean;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  voiceLaunchRequested: number;
  triggerVoiceAssistant: () => void;
  selectedBranchFilter: string;
  setSelectedBranchFilter: (branchId: string) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  toasts: ToastMessage[];
  pushToast: (title: string, tone?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;
  signInWithGoogle: () => Promise<void>;
  retryProfileSync: () => Promise<void>;
  logout: () => Promise<void>;
  selectInstitution: (institutionId: string) => Promise<void>;
  createInstitution: (input: {
    name: string;
    type: InstitutionType;
    code: string;
    country: string;
    timezone: string;
    workStartTime: string;
    seedSampleData?: boolean;
  }) => Promise<string>;
  updateInstitutionSettings: (patch: Partial<Institution>) => Promise<void>;
  createBranch: (input: {
    name: string;
    code: string;
    city?: string;
    country?: string;
    address?: string;
    phone?: string;
  }) => Promise<string>;
  updateBranch: (branchId: string, patch: Partial<Branch>) => Promise<void>;
  deleteBranch: (branchId: string) => Promise<void>;
  createDepartment: (input: {
    branchId: string;
    name: string;
    code: string;
    headName?: string;
  }) => Promise<string>;
  updateDepartment: (deptId: string, patch: Partial<Department>) => Promise<void>;
  deleteDepartment: (deptId: string) => Promise<void>;
  createRosterMember: (input: {
    branchId: string;
    departmentId: string;
    memberCode: string;
    fullName: string;
    email?: string;
    phone?: string;
    memberType: RosterMember['memberType'];
    jobTitle?: string;
    rotatingQrEnabled?: boolean;
  }) => Promise<string>;
  updateRosterMember: (rosterId: string, patch: Partial<RosterMember>) => Promise<void>;
  deleteRosterMember: (rosterId: string) => Promise<void>;
  recordAttendance: (input: {
    member: RosterMember;
    verificationMode: 'static_qr' | 'rotating_qr' | 'manual_officer';
  }) => Promise<{ action: 'check_in' | 'check_out' | 'duplicate'; status: string; offline: boolean }>;
  syncOfflineQueue: () => Promise<number>;
  triggerServiceWorkerSync: () => Promise<number>;
  retryFailedOfflineItems: () => Promise<number>;
  discardQueuedItem: (kind: 'attendance' | 'activity', localId: string) => Promise<void>;
  createCallRecord: (input: {
    callerName: string;
    callerNumber?: string;
    recipientName: string;
    recipientNumber?: string;
    direction: CallRecord['direction'];
    callSource: CallRecord['callSource'];
    durationSeconds: number;
    branchId?: string;
    departmentId?: string;
    assignedToRosterId?: string;
    assignedToName?: string;
    category: string;
    status: CallRecord['status'];
    consentRecorded: boolean;
    consentNotice?: string;
    recordingId?: string;
    recordingEncrypted?: boolean;
    transcript?: string;
    aiSummary?: string;
    aiSuggestedCategory?: string;
    notes?: string;
  }) => Promise<string>;
  updateCallRecord: (callId: string, patch: Partial<CallRecord>) => Promise<void>;
  deleteCallRecord: (callId: string) => Promise<void>;
  createCallCategory: (input: { name: string; description?: string; defaultDepartmentId?: string }) => Promise<void>;
  deleteCallCategory: (catId: string) => Promise<void>;
  saveMemberRbac: (input: {
    uid: string;
    email: string;
    displayName: string;
    role: UserRole;
    branchId?: string;
    departmentId?: string;
    status: 'active' | 'suspended' | 'invited';
    permissions: RolePermissions;
  }) => Promise<void>;
  createNotification: (input: {
    type: NotificationItem['type'];
    title: string;
    message: string;
    severity: NotificationItem['severity'];
  }) => Promise<void>;
  markNotificationRead: (notifId: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  recordBackup: (input: {
    destination: BackupRecord['destination'];
    recordCount: number;
    checksum: string;
    encrypted: boolean;
  }) => Promise<void>;
  logAudit: (action: string, resourceType: string, resourceId?: string, details?: string) => Promise<void>;
  seedSampleInstitutionData: (instId: string, branchId: string, deptIds: string[]) => Promise<void>;
}

const IMSContext = createContext<IMSContextValue | null>(null);

export function IMSProvider({ children }: { children: React.ReactNode }) {
  const browserOnline = useOnlineStatus();
  const [simulatedOffline, setSimulatedOffline] = useState(false);
  const isOnline = browserOnline && !simulatedOffline;

  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [institutions, setInstitutions] = useState<Institution[]>([]);
  const [activeInstitutionId, setActiveInstitutionId] = useState<string | null>(null);

  const [branches, setBranches] = useState<Branch[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [roster, setRoster] = useState<RosterMember[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [calls, setCalls] = useState<CallRecord[]>([]);
  const [callCategories, setCallCategories] = useState<CallCategory[]>([]);
  const [members, setMembers] = useState<InstitutionMember[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [backups, setBackups] = useState<BackupRecord[]>([]);

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [voiceLaunchRequested, setVoiceLaunchRequested] = useState(0);
  const triggerVoiceAssistant = useCallback(() => {
    setActiveTab('ai_assistant');
    setVoiceLaunchRequested((n) => n + 1);
  }, []);
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>('all');
  const [previewRole, setPreviewRole] = useState<UserRole | null>(null);
  const [selectedBadgeRosterId, setSelectedBadgeRosterId] = useState<string | null>(null);
  const [isSyncingOffline, setIsSyncingOffline] = useState(false);
  const syncInProgressRef = useRef(false);

  const [offlineQueue, setOfflineQueue] = useState<OfflineAttendanceQueueItem[]>([]);
  const [offlineActivityQueue, setOfflineActivityQueue] = useState<OfflineActivityLogQueueItem[]>([]);
  const [swStatus, setSwStatus] = useState<'active' | 'registering' | 'unsupported'>(() =>
    typeof navigator !== 'undefined' && 'serviceWorker' in navigator ? 'registering' : 'unsupported'
  );
  const [swScope, setSwScope] = useState<string | null>(null);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);
  const [headlessSyncStatus, setHeadlessSyncStatus] = useState<HeadlessSyncStatus | null>(null);

  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {
      // ignore
    }
    return 'light';
  });

  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem(LANG_STORAGE_KEY) as LanguageCode | null;
      if (saved && ['en', 'fr', 'es'].includes(saved)) return saved;
    } catch {
      // ignore
    }
    return 'en';
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const pushToast = useCallback((title: string, tone: 'success' | 'error' | 'info' = 'info') => {
    const id = makeId('toast');
    setToasts((prev) => [...prev.slice(-3), { id, title, tone }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // ignore
    }
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  const setLanguage = useCallback((lang: LanguageCode) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(LANG_STORAGE_KEY, lang);
    } catch {
      // ignore
    }
  }, []);

  const refreshOfflineQueues = useCallback(async () => {
    try {
      const [attItems, actItems, headless] = await Promise.all([
        getQueuedAttendance(),
        getQueuedActivityLogs(),
        getHeadlessSyncStatus(),
      ]);
      setOfflineQueue(attItems);
      setOfflineActivityQueue(actItems);
      setHeadlessSyncStatus(headless);
    } catch {
      // ignore
    }
  }, []);

  // Load IndexedDB queues & observe Service Worker readiness
  useEffect(() => {
    refreshOfflineQueues();

    if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) {
      setSwStatus('unsupported');
      return;
    }

    let mounted = true;
    navigator.serviceWorker.ready
      .then((reg) => {
        if (!mounted) return;
        setSwStatus('active');
        setSwScope(reg.scope || '/');
      })
      .catch(() => undefined);

    const onSwRegistered = (e: Event) => {
      const reg = (e as CustomEvent<ServiceWorkerRegistration>).detail;
      if (mounted && reg) {
        setSwStatus('active');
        setSwScope(reg.scope || '/');
      }
    };
    window.addEventListener('meridian-sw-registered', onSwRegistered);

    return () => {
      mounted = false;
      window.removeEventListener('meridian-sw-registered', onSwRegistered);
    };
  }, [refreshOfflineQueues]);

  // Keep Service Worker & IndexedDB auth context fresh on every ID token rotation and periodically
  useEffect(() => {
    const pushToken = async (user: User | null, forceRefresh = false) => {
      if (!user) return;
      try {
        const idToken = await user.getIdToken(forceRefresh);
        await syncAuthContextToServiceWorker({
          idToken,
          projectId: firebaseConfig.projectId,
          databaseId: firebaseConfig.firestoreDatabaseId,
        });
      } catch {
        // ignore if offline
      }
    };

    const unsubToken = onIdTokenChanged(auth, (user) => {
      pushToken(user, false);
    });

    const interval = window.setInterval(() => {
      if (auth.currentUser && browserOnline) {
        pushToken(auth.currentUser, true);
      }
    }, 45 * 60 * 1000);

    return () => {
      unsubToken();
      window.clearInterval(interval);
    };
  }, [browserOnline]);

  const syncUserProfile = useCallback(
    async (user: User) => {
      const userRef = doc(db, 'users', user.uid);
      try {
        let snap;
        try {
          snap = await getDoc(userRef);
        } catch (err) {
          if (isFirestoreUnavailableError(err)) {
            try {
              snap = await getDocFromCache(userRef);
            } catch {
              throw err;
            }
          } else {
            throw err;
          }
        }

        const isSuper = user.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();

        if (!snap.exists()) {
          const initialRole: UserRole = isSuper ? 'super_admin' : 'institution_admin';
          const newProfile: UserProfile = stripUndefined({
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || user.email?.split('@')[0] || 'Administrator',
            photoURL: user.photoURL || undefined,
            role: initialRole,
            language: 'en',
            themePreference: theme as 'light' | 'dark',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          await setDoc(userRef, newProfile);
          setUserProfile(newProfile);
          if (isSuper) {
            await setDoc(doc(db, 'superAdmins', user.uid), {
              uid: user.uid,
              email: user.email || SUPER_ADMIN_EMAIL,
              createdAt: serverTimestamp(),
            });
          }
        } else {
          const existing = snap.data() as UserProfile;
          setUserProfile(existing);
          if (existing.institutionId) {
            setActiveInstitutionId(existing.institutionId);
          }
        }
        setAuthError(null);
      } catch (err) {
        if (isFirestoreUnavailableError(err)) {
          console.warn('Profile sync waiting for Cloud Firestore connectivity.');
          setAuthError('Cloud Firestore is temporarily unreachable. Working in offline cache until reconnected.');
        } else {
          console.error('Profile sync error:', err);
          setAuthError(err instanceof Error ? err.message : 'Failed to load user profile');
        }
      } finally {
        setAuthLoading(false);
      }
    },
    [theme]
  );

  const retryProfileSync = useCallback(async () => {
    if (!firebaseUser) return;
    setAuthError(null);
    await ensureFirestoreOnline();
    await validateFirestoreConnection();
    await syncUserProfile(firebaseUser);
  }, [firebaseUser, syncUserProfile]);

  // Startup connection validation & automatic recovery when online
  useEffect(() => {
    if (!browserOnline) return;
    void ensureFirestoreOnline().then(() => validateFirestoreConnection());
    if (firebaseUser && !userProfile) {
      void syncUserProfile(firebaseUser);
    }
  }, [browserOnline, firebaseUser, userProfile, syncUserProfile]);

  // Auth listener & UserProfile bootstrap
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setAuthError(null);
      if (!user) {
        setUserProfile(null);
        setInstitutions([]);
        setActiveInstitutionId(null);
        setAuthLoading(false);
        return;
      }
      await syncUserProfile(user);
    });

    return () => unsub();
  }, [syncUserProfile]);

  // Load accessible institutions once user is authenticated
  useEffect(() => {
    if (!firebaseUser || !userProfile) return;

    const isSuper =
      userProfile.role === 'super_admin' ||
      firebaseUser.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();

    const instQuery = isSuper
      ? query(collection(db, 'institutions'))
      : query(collection(db, 'institutions'), where('ownerUid', '==', firebaseUser.uid));

    const unsub = onSnapshot(
      instQuery,
      async (snapshot) => {
        const list = snapshot.docs.map((d) => d.data() as Institution);
        // Also fetch user's bound institution if they are an invited member rather than owner
        if (userProfile.institutionId && !list.some((i) => i.id === userProfile.institutionId)) {
          try {
            const boundSnap = await getDoc(doc(db, 'institutions', userProfile.institutionId));
            if (boundSnap.exists()) {
              list.push(boundSnap.data() as Institution);
            }
          } catch {
            // ignore if no access
          }
        }
        setInstitutions(list);
        if (list.length > 0 && (!activeInstitutionId || !list.some((i) => i.id === activeInstitutionId))) {
          setActiveInstitutionId(list[0].id);
        }
      },
      (err) => {
        console.warn('Institutions listener:', err);
      }
    );

    return () => unsub();
  }, [firebaseUser, userProfile, activeInstitutionId]);

  const activeInstitution = useMemo(
    () => institutions.find((i) => i.id === activeInstitutionId) || null,
    [institutions, activeInstitutionId]
  );

  // Subscribe to all operational subcollections of activeInstitution
  useEffect(() => {
    if (!firebaseUser || !activeInstitution) {
      setBranches([]);
      setDepartments([]);
      setRoster([]);
      setAttendance([]);
      setCalls([]);
      setCallCategories([]);
      setMembers([]);
      setNotifications([]);
      setAuditLogs([]);
      setBackups([]);
      return;
    }

    const instId = activeInstitution.id;
    const unsubs: Array<() => void> = [];

    const listenSub = <T,>(
      subName: string,
      setter: React.Dispatch<React.SetStateAction<T[]>>,
      orderField?: string
    ) => {
      const colRef = collection(db, 'institutions', instId, subName);
      const q = orderField ? query(colRef, orderBy(orderField, 'desc')) : query(colRef);
      const u = onSnapshot(
        q,
        (snap) => {
          setter(snap.docs.map((d) => d.data() as T));
        },
        (err) => {
          console.warn(`Listener warning (${subName}):`, err.message);
        }
      );
      unsubs.push(u);
    };

    listenSub<Branch>('branches', setBranches);
    listenSub<Department>('departments', setDepartments);
    listenSub<RosterMember>('roster', setRoster);
    listenSub<AttendanceRecord>('attendance', setAttendance, 'checkInIso');
    listenSub<CallCategory>('callCategories', setCallCategories);
    listenSub<InstitutionMember>('members', setMembers);
    listenSub<NotificationItem>('notifications', setNotifications, 'createdAt');

    return () => {
      unsubs.forEach((u) => u());
    };
  }, [firebaseUser, activeInstitution]);

  const activeMember = useMemo(() => {
    if (!firebaseUser) return null;
    return members.find((m) => m.uid === firebaseUser.uid) || null;
  }, [members, firebaseUser]);

  // Subscribe to role-gated subcollections only when actual Firestore permissions allow
  useEffect(() => {
    if (!firebaseUser || !activeInstitution) {
      setCalls([]);
      setAuditLogs([]);
      setBackups([]);
      return;
    }

    const isSuperActual =
      firebaseUser.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase() ||
      userProfile?.role === 'super_admin';
    const isOwnerActual = activeInstitution.ownerUid === firebaseUser.uid;
    const isAdminActual =
      isSuperActual ||
      isOwnerActual ||
      (activeMember?.status === 'active' &&
        (activeMember.role === 'institution_admin' || activeMember.role === 'branch_admin'));
    const canCallsActual =
      isAdminActual ||
      (activeMember?.status === 'active' &&
        (activeMember.role === 'department_manager' || Boolean(activeMember.canAccessRecordings)));

    const instId = activeInstitution.id;
    const unsubs: Array<() => void> = [];

    if (canCallsActual) {
      const callsQ = query(collection(db, 'institutions', instId, 'calls'), orderBy('startedAtIso', 'desc'));
      unsubs.push(
        onSnapshot(
          callsQ,
          (snap) => setCalls(snap.docs.map((d) => d.data() as CallRecord)),
          (err) => console.warn('Listener warning (calls):', err.message)
        )
      );
    } else {
      setCalls([]);
    }

    if (isAdminActual) {
      const auditQ = query(collection(db, 'institutions', instId, 'auditLogs'), orderBy('createdAt', 'desc'));
      const backupsQ = query(collection(db, 'institutions', instId, 'backups'), orderBy('createdAt', 'desc'));
      unsubs.push(
        onSnapshot(
          auditQ,
          (snap) => setAuditLogs(snap.docs.map((d) => d.data() as AuditLog)),
          (err) => console.warn('Listener warning (auditLogs):', err.message)
        ),
        onSnapshot(
          backupsQ,
          (snap) => setBackups(snap.docs.map((d) => d.data() as BackupRecord)),
          (err) => console.warn('Listener warning (backups):', err.message)
        )
      );
    } else {
      setAuditLogs([]);
      setBackups([]);
    }

    return () => {
      unsubs.forEach((u) => u());
    };
  }, [firebaseUser, activeInstitution, activeMember, userProfile?.role]);

  const effectiveRole: UserRole = useMemo(() => {
    if (previewRole) return previewRole;
    if (firebaseUser?.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) return 'super_admin';
    if (activeMember?.role) return activeMember.role;
    if (activeInstitution?.ownerUid === firebaseUser?.uid) return 'institution_admin';
    return userProfile?.role || 'employee';
  }, [previewRole, firebaseUser, activeMember, activeInstitution, userProfile]);

  const effectivePermissions: RolePermissions = useMemo(() => {
    if (previewRole) return DEFAULT_ROLE_PERMISSIONS[previewRole];
    if (effectiveRole === 'super_admin' || activeInstitution?.ownerUid === firebaseUser?.uid) {
      return DEFAULT_ROLE_PERMISSIONS.super_admin;
    }
    if (activeMember) {
      return {
        canAccessRecordings: Boolean(activeMember.canAccessRecordings),
        canViewAttendance: Boolean(activeMember.canViewAttendance),
        canGenerateReports: Boolean(activeMember.canGenerateReports),
        canManageEmployees: Boolean(activeMember.canManageEmployees),
        canCreateQrCodes: Boolean(activeMember.canCreateQrCodes),
        canChangeSettings: Boolean(activeMember.canChangeSettings),
      };
    }
    return DEFAULT_ROLE_PERMISSIONS[effectiveRole];
  }, [previewRole, effectiveRole, activeInstitution, firebaseUser, activeMember]);

  const logAudit = useCallback(
    async (action: string, resourceType: string, resourceId?: string, details?: string) => {
      if (!firebaseUser || !activeInstitution) return;
      const logId = makeId('log');
      const actorName = userProfile?.displayName || firebaseUser.displayName || 'User';

      const queueOfflineLog = async () => {
        const queuedItem: OfflineActivityLogQueueItem = stripUndefined({
          localId: logId,
          institutionId: activeInstitution.id,
          actorUid: firebaseUser.uid,
          actorName,
          actorRole: effectiveRole,
          action: action.slice(0, 120),
          resourceType: resourceType.slice(0, 64),
          resourceId: resourceId?.slice(0, 128),
          details: details?.slice(0, 500),
          queuedAtMs: Date.now(),
        });
        await enqueueActivityLogOffline(queuedItem);
        await refreshOfflineQueues();
      };

      if (!isOnline) {
        await queueOfflineLog();
        return;
      }

      const path = `institutions/${activeInstitution.id}/auditLogs/${logId}`;
      try {
        await setDoc(
          doc(db, 'institutions', activeInstitution.id, 'auditLogs', logId),
          stripUndefined({
            id: logId,
            institutionId: activeInstitution.id,
            actorUid: firebaseUser.uid,
            actorName,
            actorRole: effectiveRole,
            action: action.slice(0, 120),
            resourceType: resourceType.slice(0, 64),
            resourceId: resourceId?.slice(0, 128),
            details: details?.slice(0, 500),
            createdAt: serverTimestamp(),
          })
        );
      } catch (err) {
        const msg = err instanceof Error ? err.message.toLowerCase() : '';
        if (!navigator.onLine || msg.includes('offline') || msg.includes('unavailable') || msg.includes('network')) {
          await queueOfflineLog();
        } else {
          console.warn('Audit log write skipped:', path, err);
        }
      }
    },
    [firebaseUser, activeInstitution, userProfile, effectiveRole, isOnline, refreshOfflineQueues]
  );

  const signInWithGoogle = useCallback(async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
      pushToast('Signed in successfully.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign-in failed';
      setAuthError(msg);
      pushToast(msg, 'error');
    }
  }, [pushToast]);

  const logout = useCallback(async () => {
    await signOut(auth);
    setPreviewRole(null);
    pushToast('Signed out.', 'info');
  }, [pushToast]);

  const selectInstitution = useCallback(
    async (institutionId: string) => {
      setActiveInstitutionId(institutionId);
      setSelectedBranchFilter('all');
      if (firebaseUser) {
        try {
          await updateDoc(doc(db, 'users', firebaseUser.uid), {
            institutionId,
            updatedAt: serverTimestamp(),
          });
        } catch {
          // ignore
        }
      }
    },
    [firebaseUser]
  );

  const seedSampleInstitutionData = useCallback(
    async (instId: string, mainBranchId: string, deptIds: string[]) => {
      if (!firebaseUser) return;
      const secondBranchId = makeId('br');
      await setDoc(doc(db, 'institutions', instId, 'branches', secondBranchId), {
        id: secondBranchId,
        institutionId: instId,
        name: 'North Regional Annex',
        code: 'NORTH-02',
        city: 'Manchester',
        country: 'United Kingdom',
        address: '42 Commerce Crescent',
        phone: '+44 161 555 0192',
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      const opsDeptId = deptIds[0];
      const supportDeptId = deptIds[1] || deptIds[0];

      const samplePeople: Array<{
        code: string;
        name: string;
        type: RosterMember['memberType'];
        title: string;
        branch: string;
        dept: string;
        email: string;
        phone: string;
      }> = [
        { code: 'EMP-1001', name: 'Dr. Amara Osei', type: 'employee', title: 'Director of Operations', branch: mainBranchId, dept: opsDeptId, email: 'amara.osei@institution.org', phone: '+44 20 7946 0201' },
        { code: 'EMP-1002', name: 'Marcus Vance', type: 'employee', title: 'Senior Systems Officer', branch: mainBranchId, dept: supportDeptId, email: 'm.vance@institution.org', phone: '+44 20 7946 0202' },
        { code: 'EMP-1003', name: 'Elena Rostova', type: 'faculty', title: 'Lead Coordinator', branch: secondBranchId, dept: opsDeptId, email: 'e.rostova@institution.org', phone: '+44 161 555 0141' },
        { code: 'STD-2041', name: 'Liam Patel', type: 'student', title: 'Research Fellow', branch: mainBranchId, dept: supportDeptId, email: 'liam.patel@institution.org', phone: '+44 20 7946 0244' },
        { code: 'EMP-1004', name: 'Sophia Chen', type: 'employee', title: 'Compliance Specialist', branch: secondBranchId, dept: supportDeptId, email: 's.chen@institution.org', phone: '+44 161 555 0188' },
      ];

      const today = todayDateKey();
      const rosterIds: string[] = [];

      for (let i = 0; i < samplePeople.length; i++) {
        const p = samplePeople[i];
        const rId = makeId('ros');
        rosterIds.push(rId);
        await setDoc(doc(db, 'institutions', instId, 'roster', rId), {
          id: rId,
          institutionId: instId,
          branchId: p.branch,
          departmentId: p.dept,
          memberCode: p.code,
          fullName: p.name,
          email: p.email,
          phone: p.phone,
          memberType: p.type,
          jobTitle: p.title,
          qrSecret: `SEC_${Math.random().toString(36).slice(2, 12).toUpperCase()}`,
          rotatingQrEnabled: i % 2 === 0,
          status: 'active',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        if (i < 4) {
          const attId = makeId('att');
          const status = i === 3 ? 'late' : 'present';
          const checkInHour = i === 3 ? '09:24:00' : `08:3${i}:00`;
          await setDoc(doc(db, 'institutions', instId, 'attendance', attId), {
            id: attId,
            institutionId: instId,
            rosterId: rId,
            memberName: p.name,
            memberCode: p.code,
            branchId: p.branch,
            departmentId: p.dept,
            dateKey: today,
            checkInIso: `${today}T${checkInHour}`,
            status,
            verificationMode: i % 2 === 0 ? 'rotating_qr' : 'static_qr',
            deviceInfo: 'Meridian Kiosk Terminal 01',
            recordedByUid: firebaseUser.uid,
            recordedByName: firebaseUser.displayName || 'Administrator',
            offlineCaptured: false,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      }

      const sampleCalls = [
        {
          callerName: 'Claire Thornton',
          callerNumber: '+44 20 7946 0821',
          recipientName: 'Dr. Amara Osei',
          recipientNumber: 'Ext 101',
          direction: 'inbound' as const,
          callSource: 'pbx_sip' as const,
          durationSeconds: 284,
          branchId: mainBranchId,
          departmentId: opsDeptId,
          assignedToRosterId: rosterIds[0],
          assignedToName: 'Dr. Amara Osei',
          category: 'Admissions & Intake',
          status: 'completed' as const,
          consentRecorded: true,
          consentNotice: 'Two-party consent announced via SIP IVR prompt.',
          transcript: 'Speaker 1 (Claire): Good morning, I am calling regarding the Q4 accreditation audit schedule for the North Annex.\nSpeaker 2 (Amara): Thank you Claire. We have confirmed Tuesday at 10:00 AM with all department heads.',
          aiSummary: 'Accreditation audit scheduling confirmed for Tuesday at 10:00 AM at the North Annex.',
          aiSuggestedCategory: 'Compliance & Audit',
          notes: 'Send calendar invite and branch readiness packet.',
        },
        {
          callerName: 'David Mensah',
          callerNumber: '+44 161 496 0402',
          recipientName: 'Marcus Vance',
          recipientNumber: 'Ext 204',
          direction: 'inbound' as const,
          callSource: 'app_webrtc' as const,
          durationSeconds: 162,
          branchId: mainBranchId,
          departmentId: supportDeptId,
          assignedToRosterId: rosterIds[1],
          assignedToName: 'Marcus Vance',
          category: 'IT & Infrastructure',
          status: 'follow_up' as const,
          consentRecorded: true,
          consentNotice: 'In-app WebRTC recording banner accepted by both parties.',
          transcript: 'Speaker 1 (David): The lobby QR kiosk tablet lost Wi-Fi briefly this morning, did our check-ins save?\nSpeaker 2 (Marcus): Yes, Meridian offline cache queued 14 scans and synced them automatically once Wi-Fi restored.',
          aiSummary: 'Confirmed offline QR kiosk queue synchronized 14 morning check-ins after brief Wi-Fi outage.',
          aiSuggestedCategory: 'IT & Infrastructure',
          notes: 'Verify lobby access point firmware update tonight.',
        },
      ];

      for (let i = 0; i < sampleCalls.length; i++) {
        const c = sampleCalls[i];
        const callId = makeId('call');
        await setDoc(doc(db, 'institutions', instId, 'calls', callId), {
          id: callId,
          institutionId: instId,
          ...c,
          startedAtIso: new Date(Date.now() - (i + 1) * 3600 * 1000).toISOString(),
          createdByUid: firebaseUser.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      const notifId = makeId('notif');
      await setDoc(doc(db, 'institutions', instId, 'notifications', notifId), {
        id: notifId,
        institutionId: instId,
        type: 'late_arrival',
        title: 'Late Check-In Flagged: Liam Patel',
        message: 'Checked in at 09:24 via static QR at Main Campus (threshold 09:00).',
        severity: 'warning',
        isRead: false,
        createdByUid: firebaseUser.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    },
    [firebaseUser]
  );

  const createInstitution = useCallback(
    async (input: {
      name: string;
      type: InstitutionType;
      code: string;
      country: string;
      timezone: string;
      workStartTime: string;
      seedSampleData?: boolean;
    }) => {
      if (!firebaseUser) throw new Error('Sign in required.');
      const instId = makeId('inst');
      const instPath = `institutions/${instId}`;
      try {
        await setDoc(doc(db, 'institutions', instId), {
          id: instId,
          name: input.name.trim(),
          type: input.type,
          code: input.code.trim().toUpperCase(),
          country: input.country.trim(),
          timezone: input.timezone.trim(),
          ownerUid: firebaseUser.uid,
          workStartTime: input.workStartTime || '09:00',
          recordingConsentRequired: true,
          autoRecordSupportedCalls: false,
          rotatingQrEnabled: true,
          aiProvider: 'Google Gemini',
          aiModel: 'gemini-4-hydrogen',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        const role: UserRole =
          firebaseUser.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
            ? 'super_admin'
            : 'institution_admin';

        await setDoc(doc(db, 'institutions', instId, 'members', firebaseUser.uid), {
          uid: firebaseUser.uid,
          institutionId: instId,
          email: firebaseUser.email || '',
          displayName: firebaseUser.displayName || 'Institution Owner',
          role,
          status: 'active',
          ...DEFAULT_ROLE_PERMISSIONS.institution_admin,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await updateDoc(doc(db, 'users', firebaseUser.uid), {
          institutionId: instId,
          updatedAt: serverTimestamp(),
        });

        // Create default HQ branch & departments sequentially so exists() rules pass
        const mainBranchId = makeId('br');
        await setDoc(doc(db, 'institutions', instId, 'branches', mainBranchId), {
          id: mainBranchId,
          institutionId: instId,
          name: 'Headquarters Campus',
          code: 'HQ-01',
          city: 'London',
          country: input.country.trim() || 'United Kingdom',
          address: '100 Institutional Way',
          phone: '+44 20 7946 0000',
          status: 'active',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        const deptOpsId = makeId('dept');
        await setDoc(doc(db, 'institutions', instId, 'departments', deptOpsId), {
          id: deptOpsId,
          institutionId: instId,
          branchId: mainBranchId,
          name: 'Administration & Operations',
          code: 'OPS',
          headName: firebaseUser.displayName || 'Operations Lead',
          status: 'active',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        const deptSupportId = makeId('dept');
        await setDoc(doc(db, 'institutions', instId, 'departments', deptSupportId), {
          id: deptSupportId,
          institutionId: instId,
          branchId: mainBranchId,
          name: 'Client & Student Services',
          code: 'SVC',
          headName: 'Services Desk',
          status: 'active',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        const defaultCats = ['General Inquiry', 'Admissions & Intake', 'IT & Infrastructure', 'Compliance & Audit', 'Emergency Escalation'];
        for (const catName of defaultCats) {
          const catId = makeId('cat');
          await setDoc(doc(db, 'institutions', instId, 'callCategories', catId), {
            id: catId,
            institutionId: instId,
            name: catName,
            description: `${catName} routing queue`,
            defaultDepartmentId: deptOpsId,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        if (input.seedSampleData) {
          await seedSampleInstitutionData(instId, mainBranchId, [deptOpsId, deptSupportId]);
        }

        setActiveInstitutionId(instId);
        pushToast(`Institution "${input.name}" provisioned.`, 'success');
        return instId;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, instPath);
      }
    },
    [firebaseUser, pushToast, seedSampleInstitutionData]
  );

  const updateInstitutionSettings = useCallback(
    async (patch: Partial<Institution>) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}`;
      try {
        await updateDoc(
          doc(db, 'institutions', activeInstitution.id),
          stripUndefined({
            ...patch,
            updatedAt: serverTimestamp(),
          })
        );
        await logAudit('Update Institution Settings', 'institution', activeInstitution.id, Object.keys(patch).join(', '));
        pushToast('Institution settings updated.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const createBranch = useCallback(
    async (input: { name: string; code: string; city?: string; country?: string; address?: string; phone?: string }) => {
      if (!activeInstitution) throw new Error('No active institution');
      const branchId = makeId('br');
      const path = `institutions/${activeInstitution.id}/branches/${branchId}`;
      try {
        await setDoc(
          doc(db, 'institutions', activeInstitution.id, 'branches', branchId),
          stripUndefined({
            id: branchId,
            institutionId: activeInstitution.id,
            name: input.name.trim(),
            code: input.code.trim().toUpperCase(),
            city: input.city?.trim(),
            country: input.country?.trim(),
            address: input.address?.trim(),
            phone: input.phone?.trim(),
            status: 'active',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          })
        );
        await logAudit('Create Branch', 'branch', branchId, input.name);
        pushToast(`Branch "${input.name}" created.`, 'success');
        return branchId;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const updateBranch = useCallback(
    async (branchId: string, patch: Partial<Branch>) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/branches/${branchId}`;
      try {
        await updateDoc(doc(db, 'institutions', activeInstitution.id, 'branches', branchId), stripUndefined({
          ...patch,
          updatedAt: serverTimestamp(),
        }));
        await logAudit('Update Branch', 'branch', branchId);
        pushToast('Branch updated.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const deleteBranch = useCallback(
    async (branchId: string) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/branches/${branchId}`;
      try {
        await deleteDoc(doc(db, 'institutions', activeInstitution.id, 'branches', branchId));
        await logAudit('Delete Branch', 'branch', branchId);
        pushToast('Branch removed.', 'info');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const createDepartment = useCallback(
    async (input: { branchId: string; name: string; code: string; headName?: string }) => {
      if (!activeInstitution) throw new Error('No active institution');
      const deptId = makeId('dept');
      const path = `institutions/${activeInstitution.id}/departments/${deptId}`;
      try {
        await setDoc(
          doc(db, 'institutions', activeInstitution.id, 'departments', deptId),
          stripUndefined({
            id: deptId,
            institutionId: activeInstitution.id,
            branchId: input.branchId,
            name: input.name.trim(),
            code: input.code.trim().toUpperCase(),
            headName: input.headName?.trim(),
            status: 'active',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          })
        );
        await logAudit('Create Department', 'department', deptId, input.name);
        pushToast(`Department "${input.name}" created.`, 'success');
        return deptId;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const updateDepartment = useCallback(
    async (deptId: string, patch: Partial<Department>) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/departments/${deptId}`;
      try {
        await updateDoc(doc(db, 'institutions', activeInstitution.id, 'departments', deptId), stripUndefined({
          ...patch,
          updatedAt: serverTimestamp(),
        }));
        await logAudit('Update Department', 'department', deptId);
        pushToast('Department updated.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const deleteDepartment = useCallback(
    async (deptId: string) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/departments/${deptId}`;
      try {
        await deleteDoc(doc(db, 'institutions', activeInstitution.id, 'departments', deptId));
        await logAudit('Delete Department', 'department', deptId);
        pushToast('Department removed.', 'info');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const createRosterMember = useCallback(
    async (input: {
      branchId: string;
      departmentId: string;
      memberCode: string;
      fullName: string;
      email?: string;
      phone?: string;
      memberType: RosterMember['memberType'];
      jobTitle?: string;
      rotatingQrEnabled?: boolean;
    }) => {
      if (!activeInstitution) throw new Error('No active institution');
      const rosterId = makeId('ros');
      const path = `institutions/${activeInstitution.id}/roster/${rosterId}`;
      try {
        await setDoc(
          doc(db, 'institutions', activeInstitution.id, 'roster', rosterId),
          stripUndefined({
            id: rosterId,
            institutionId: activeInstitution.id,
            branchId: input.branchId,
            departmentId: input.departmentId,
            memberCode: input.memberCode.trim().toUpperCase(),
            fullName: input.fullName.trim(),
            email: input.email?.trim(),
            phone: input.phone?.trim(),
            memberType: input.memberType,
            jobTitle: input.jobTitle?.trim(),
            qrSecret: `SEC_${Math.random().toString(36).slice(2, 12).toUpperCase()}`,
            rotatingQrEnabled: Boolean(input.rotatingQrEnabled),
            status: 'active',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          })
        );
        await logAudit('Register Member', 'roster', rosterId, `${input.fullName} (${input.memberCode})`);
        pushToast(`${input.fullName} added to roster with verifiable QR credential.`, 'success');
        return rosterId;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const updateRosterMember = useCallback(
    async (rosterId: string, patch: Partial<RosterMember>) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/roster/${rosterId}`;
      try {
        await updateDoc(doc(db, 'institutions', activeInstitution.id, 'roster', rosterId), stripUndefined({
          ...patch,
          updatedAt: serverTimestamp(),
        }));
        await logAudit('Update Roster Member', 'roster', rosterId);
        pushToast('Member record updated.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const deleteRosterMember = useCallback(
    async (rosterId: string) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/roster/${rosterId}`;
      try {
        await deleteDoc(doc(db, 'institutions', activeInstitution.id, 'roster', rosterId));
        await logAudit('Remove Roster Member', 'roster', rosterId);
        pushToast('Member removed from roster.', 'info');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const createNotification = useCallback(
    async (input: {
      type: NotificationItem['type'];
      title: string;
      message: string;
      severity: NotificationItem['severity'];
    }) => {
      if (!activeInstitution || !firebaseUser) return;
      const notifId = makeId('notif');
      try {
        await setDoc(doc(db, 'institutions', activeInstitution.id, 'notifications', notifId), {
          id: notifId,
          institutionId: activeInstitution.id,
          type: input.type,
          title: input.title.slice(0, 160),
          message: input.message.slice(0, 1000),
          severity: input.severity,
          isRead: false,
          createdByUid: firebaseUser.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Notification error:', err);
      }
    },
    [activeInstitution, firebaseUser]
  );

  const recordAttendance = useCallback(
    async (input: {
      member: RosterMember;
      verificationMode: 'static_qr' | 'rotating_qr' | 'manual_officer';
    }) => {
      if (!activeInstitution || !firebaseUser) {
        throw new Error('Authentication and institution required');
      }

      const dateKey = todayDateKey();
      const nowIso = new Date().toISOString();
      const workStart = activeInstitution.workStartTime || '09:00';
      const [startH, startM] = workStart.split(':').map(Number);
      const now = new Date();
      const isLate =
        now.getHours() > (startH || 9) ||
        (now.getHours() === (startH || 9) && now.getMinutes() > (startM || 0));
      const status: 'present' | 'late' = isLate ? 'late' : 'present';

      const existingToday = attendance.find(
        (a) => a.rosterId === input.member.id && a.dateKey === dateKey
      );
      const offlineToday = offlineQueue.filter(
        (q) => q.rosterId === input.member.id && q.dateKey === dateKey
      );
      const hasOfflineCheckOut = offlineToday.some((q) => q.action === 'check_out');
      const latestOfflineCheckIn = [...offlineToday]
        .reverse()
        .find((q) => q.action === 'check_in');

      // Duplicate check-in / check-out logic
      if ((existingToday && existingToday.checkOutIso) || hasOfflineCheckOut) {
        return { action: 'duplicate' as const, status: 'Already checked in & out today', offline: false };
      }

      // Prevent accidental double-scan within 2 minutes
      const lastCheckInIso = existingToday?.checkInIso || latestOfflineCheckIn?.checkInIso;
      if (lastCheckInIso) {
        const diffMs = Date.now() - new Date(lastCheckInIso).getTime();
        if (diffMs < 120_000) {
          return { action: 'duplicate' as const, status: 'Duplicate scan blocked (< 2 min)', offline: false };
        }
      }

      const deviceInfo =
        typeof navigator !== 'undefined'
          ? `${navigator.platform || 'Device'} · ${navigator.userAgent.includes('Android') ? 'Android' : 'Web'}`.slice(0, 150)
          : 'Web Terminal';

      const queueInIndexedDb = async () => {
        const actionType: 'check_in' | 'check_out' =
          existingToday || latestOfflineCheckIn ? 'check_out' : 'check_in';
        const queueItem: OfflineAttendanceQueueItem = stripUndefined({
          localId: makeId('offatt'),
          institutionId: activeInstitution.id,
          rosterId: input.member.id,
          memberName: input.member.fullName,
          memberCode: input.member.memberCode,
          branchId: input.member.branchId,
          departmentId: input.member.departmentId,
          dateKey,
          checkInIso: nowIso,
          status,
          verificationMode: input.verificationMode,
          deviceInfo,
          recordedByUid: firebaseUser.uid,
          recordedByName: userProfile?.displayName || firebaseUser.displayName || 'Officer',
          action: actionType,
          existingAttendanceId: existingToday?.id || latestOfflineCheckIn?.localId,
          queuedAtMs: Date.now(),
        });

        await enqueueAttendanceOffline(queueItem);
        await logAudit(
          actionType === 'check_out' ? 'Offline Attendance Check-Out' : 'Offline Attendance Check-In',
          'attendance',
          queueItem.localId,
          `${input.member.fullName} (${input.member.memberCode}) queued in IndexedDB (${status})`
        );
        await refreshOfflineQueues();
        pushToast(
          `Offline IndexedDB queued ${queueItem.action.replace('_', '-')} + activity log for ${input.member.fullName}.`,
          'info'
        );
        return {
          action: queueItem.action,
          status: `${status} (IndexedDB queued)`,
          offline: true,
        };
      };

      if (!isOnline) {
        return queueInIndexedDb();
      }

      if (existingToday) {
        const path = `institutions/${activeInstitution.id}/attendance/${existingToday.id}`;
        try {
          await updateDoc(doc(db, 'institutions', activeInstitution.id, 'attendance', existingToday.id), {
            checkOutIso: nowIso,
            status: 'checked_out',
            updatedAt: serverTimestamp(),
          });
          await logAudit('Attendance Check-Out', 'attendance', existingToday.id, `${input.member.fullName} checked out`);
          return { action: 'check_out' as const, status: 'checked_out', offline: false };
        } catch (err) {
          const msg = err instanceof Error ? err.message.toLowerCase() : '';
          if (!navigator.onLine || msg.includes('offline') || msg.includes('unavailable') || msg.includes('network')) {
            return queueInIndexedDb();
          }
          handleFirestoreError(err, OperationType.UPDATE, path);
        }
      }

      const attId = makeId('att');
      const path = `institutions/${activeInstitution.id}/attendance/${attId}`;
      try {
        await setDoc(doc(db, 'institutions', activeInstitution.id, 'attendance', attId), {
          id: attId,
          institutionId: activeInstitution.id,
          rosterId: input.member.id,
          memberName: input.member.fullName,
          memberCode: input.member.memberCode,
          branchId: input.member.branchId,
          departmentId: input.member.departmentId,
          dateKey,
          checkInIso: nowIso,
          status,
          verificationMode: input.verificationMode,
          deviceInfo,
          recordedByUid: firebaseUser.uid,
          recordedByName: userProfile?.displayName || firebaseUser.displayName || 'Officer',
          offlineCaptured: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await createNotification({
          type: isLate ? 'late_arrival' : 'attendance',
          title: isLate ? `Late Arrival: ${input.member.fullName}` : `Check-In: ${input.member.fullName}`,
          message: `${input.member.fullName} (${input.member.memberCode}) verified via ${input.verificationMode.replace('_', ' ')}.`,
          severity: isLate ? 'warning' : 'info',
        });

        await logAudit('Attendance Check-In', 'attendance', attId, `${input.member.fullName} (${status})`);
        return { action: 'check_in' as const, status, offline: false };
      } catch (err) {
        const msg = err instanceof Error ? err.message.toLowerCase() : '';
        if (!navigator.onLine || msg.includes('offline') || msg.includes('unavailable') || msg.includes('network')) {
          return queueInIndexedDb();
        }
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeInstitution, firebaseUser, attendance, offlineQueue, isOnline, userProfile, pushToast, logAudit, createNotification, refreshOfflineQueues]
  );

  const syncOfflineQueue = useCallback(async () => {
    if (!isOnline || !firebaseUser || syncInProgressRef.current) return 0;

    const [attItems, actItems] = await Promise.all([
      getQueuedAttendance(),
      getQueuedActivityLogs(),
    ]);

    if (attItems.length === 0 && actItems.length === 0) return 0;

    syncInProgressRef.current = true;
    setIsSyncingOffline(true);
    let syncedAtt = 0;
    let syncedAct = 0;

    try {
      for (const item of attItems) {
        try {
          if (item.action === 'check_out' && item.existingAttendanceId) {
            await updateDoc(doc(db, 'institutions', item.institutionId, 'attendance', item.existingAttendanceId), {
              checkOutIso: item.checkInIso,
              status: 'checked_out',
              updatedAt: serverTimestamp(),
            });
          } else {
            await setDoc(doc(db, 'institutions', item.institutionId, 'attendance', item.localId), {
              id: item.localId,
              institutionId: item.institutionId,
              rosterId: item.rosterId,
              memberName: item.memberName,
              memberCode: item.memberCode,
              branchId: item.branchId,
              departmentId: item.departmentId,
              dateKey: item.dateKey,
              checkInIso: item.checkInIso,
              status: item.status,
              verificationMode: item.verificationMode,
              deviceInfo: item.deviceInfo,
              recordedByUid: item.recordedByUid,
              recordedByName: item.recordedByName,
              offlineCaptured: true,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
          }
          await removeQueuedAttendance(item.localId);
          syncedAtt++;
        } catch (err) {
          const msg = err instanceof Error ? err.message : 'Sync failed';
          console.error('Failed to sync offline attendance item:', item.localId, err);
          await updateQueuedAttendanceError(item, msg);
        }
      }

      for (const act of actItems) {
        try {
          await setDoc(
            doc(db, 'institutions', act.institutionId, 'auditLogs', act.localId),
            stripUndefined({
              id: act.localId,
              institutionId: act.institutionId,
              actorUid: act.actorUid,
              actorName: act.actorName,
              actorRole: act.actorRole,
              action: act.action.slice(0, 120),
              resourceType: act.resourceType.slice(0, 64),
              resourceId: act.resourceId?.slice(0, 128),
              details: act.details?.slice(0, 500),
              createdAt: serverTimestamp(),
            })
          );
          await removeQueuedActivityLog(act.localId);
          syncedAct++;
        } catch (err) {
          const msg = err instanceof Error ? err.message : 'Sync failed';
          console.error('Failed to sync offline activity log:', act.localId, err);
          await updateQueuedActivityError(act, msg);
        }
      }

      await refreshOfflineQueues();
      const totalSynced = syncedAtt + syncedAct;
      if (totalSynced > 0) {
        setLastSyncedAt(new Date().toISOString());
        pushToast(
          `Synced ${syncedAtt} attendance & ${syncedAct} activity log(s) to Firebase.`,
          'success'
        );
      }
      return totalSynced;
    } finally {
      syncInProgressRef.current = false;
      setIsSyncingOffline(false);
    }
  }, [isOnline, firebaseUser, pushToast, refreshOfflineQueues]);

  const triggerServiceWorkerSync = useCallback(async () => {
    if (!isOnline) return 0;
    const dispatched = await triggerServiceWorkerQueueFlush();
    if (!dispatched) {
      return syncOfflineQueue();
    }
    return 0;
  }, [isOnline, syncOfflineQueue]);

  const retryFailedOfflineItems = useCallback(async () => {
    await clearQueueErrors();
    await refreshOfflineQueues();
    if (!isOnline) return 0;
    return syncOfflineQueue();
  }, [isOnline, refreshOfflineQueues, syncOfflineQueue]);

  const discardQueuedItem = useCallback(
    async (kind: 'attendance' | 'activity', localId: string) => {
      if (kind === 'attendance') {
        await removeQueuedAttendance(localId);
      } else {
        await removeQueuedActivityLog(localId);
      }
      await refreshOfflineQueues();
      pushToast('Queued offline item discarded.', 'info');
    },
    [refreshOfflineQueues, pushToast]
  );

  // Listen to Service Worker background sync & queue updates
  useEffect(() => {
    if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
    const onMessage = (event: MessageEvent) => {
      const data = event.data as { type?: string } | undefined;
      if (!data?.type) return;
      if (data.type === 'SW_QUEUE_UPDATED') {
        refreshOfflineQueues();
      } else if (data.type === 'SW_TRIGGER_FIREBASE_SYNC') {
        syncOfflineQueue();
      }
    };
    navigator.serviceWorker.addEventListener('message', onMessage);
    return () => navigator.serviceWorker.removeEventListener('message', onMessage);
  }, [refreshOfflineQueues, syncOfflineQueue]);

  // Automatic background sync when connectivity returns
  useEffect(() => {
    if (isOnline && firebaseUser && (offlineQueue.length > 0 || offlineActivityQueue.length > 0)) {
      registerBackgroundSyncWithSW();
      syncOfflineQueue();
    }
  }, [isOnline, firebaseUser, offlineQueue.length, offlineActivityQueue.length, syncOfflineQueue]);

  const createCallRecord = useCallback(
    async (input: {
      callerName: string;
      callerNumber?: string;
      recipientName: string;
      recipientNumber?: string;
      direction: CallRecord['direction'];
      callSource: CallRecord['callSource'];
      durationSeconds: number;
      branchId?: string;
      departmentId?: string;
      assignedToRosterId?: string;
      assignedToName?: string;
      category: string;
      status: CallRecord['status'];
      consentRecorded: boolean;
      consentNotice?: string;
      recordingId?: string;
      recordingEncrypted?: boolean;
      transcript?: string;
      aiSummary?: string;
      aiSuggestedCategory?: string;
      notes?: string;
    }) => {
      if (!activeInstitution || !firebaseUser) throw new Error('No active institution');
      const callId = makeId('call');
      const path = `institutions/${activeInstitution.id}/calls/${callId}`;
      try {
        await setDoc(
          doc(db, 'institutions', activeInstitution.id, 'calls', callId),
          stripUndefined({
            id: callId,
            institutionId: activeInstitution.id,
            callerName: input.callerName.trim(),
            callerNumber: input.callerNumber?.trim(),
            recipientName: input.recipientName.trim(),
            recipientNumber: input.recipientNumber?.trim(),
            direction: input.direction,
            callSource: input.callSource,
            startedAtIso: new Date().toISOString(),
            durationSeconds: Math.max(0, Math.round(input.durationSeconds)),
            branchId: input.branchId,
            departmentId: input.departmentId,
            assignedToRosterId: input.assignedToRosterId,
            assignedToName: input.assignedToName,
            category: input.category,
            status: input.status,
            consentRecorded: input.consentRecorded,
            consentNotice: input.consentNotice,
            recordingId: input.recordingId,
            recordingEncrypted: input.recordingEncrypted,
            transcript: input.transcript,
            aiSummary: input.aiSummary,
            aiSuggestedCategory: input.aiSuggestedCategory,
            notes: input.notes,
            createdByUid: firebaseUser.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          })
        );

        await createNotification({
          type: input.status === 'escalated' ? 'important_call' : 'assigned_call',
          title: `Call Logged: ${input.callerName} → ${input.recipientName}`,
          message: `Category: ${input.category} · Source: ${input.callSource.toUpperCase()}`,
          severity: input.status === 'escalated' ? 'urgent' : 'info',
        });

        await logAudit('Log Call Record', 'call', callId, `${input.callerName} -> ${input.recipientName}`);
        pushToast('Call record saved securely.', 'success');
        return callId;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeInstitution, firebaseUser, createNotification, logAudit, pushToast]
  );

  const updateCallRecord = useCallback(
    async (callId: string, patch: Partial<CallRecord>) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/calls/${callId}`;
      try {
        await updateDoc(
          doc(db, 'institutions', activeInstitution.id, 'calls', callId),
          stripUndefined({
            ...patch,
            updatedAt: serverTimestamp(),
          })
        );
        await logAudit('Update Call Record', 'call', callId, Object.keys(patch).join(', '));
        pushToast('Call record updated.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const deleteCallRecord = useCallback(
    async (callId: string) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/calls/${callId}`;
      try {
        await deleteDoc(doc(db, 'institutions', activeInstitution.id, 'calls', callId));
        await logAudit('Delete Call Record', 'call', callId);
        pushToast('Call record deleted.', 'info');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const createCallCategory = useCallback(
    async (input: { name: string; description?: string; defaultDepartmentId?: string }) => {
      if (!activeInstitution) return;
      const catId = makeId('cat');
      const path = `institutions/${activeInstitution.id}/callCategories/${catId}`;
      try {
        await setDoc(
          doc(db, 'institutions', activeInstitution.id, 'callCategories', catId),
          stripUndefined({
            id: catId,
            institutionId: activeInstitution.id,
            name: input.name.trim(),
            description: input.description?.trim(),
            defaultDepartmentId: input.defaultDepartmentId,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          })
        );
        pushToast(`Call category "${input.name}" added.`, 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeInstitution, pushToast]
  );

  const deleteCallCategory = useCallback(
    async (catId: string) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/callCategories/${catId}`;
      try {
        await deleteDoc(doc(db, 'institutions', activeInstitution.id, 'callCategories', catId));
        pushToast('Category deleted.', 'info');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    },
    [activeInstitution, pushToast]
  );

  const saveMemberRbac = useCallback(
    async (input: {
      uid: string;
      email: string;
      displayName: string;
      role: UserRole;
      branchId?: string;
      departmentId?: string;
      status: 'active' | 'suspended' | 'invited';
      permissions: RolePermissions;
    }) => {
      if (!activeInstitution) return;
      const path = `institutions/${activeInstitution.id}/members/${input.uid}`;
      try {
        const ref = doc(db, 'institutions', activeInstitution.id, 'members', input.uid);
        const existing = await getDoc(ref);
        if (existing.exists()) {
          await updateDoc(
            ref,
            stripUndefined({
              displayName: input.displayName.trim(),
              role: input.role,
              branchId: input.branchId,
              departmentId: input.departmentId,
              status: input.status,
              ...input.permissions,
              updatedAt: serverTimestamp(),
            })
          );
        } else {
          await setDoc(
            ref,
            stripUndefined({
              uid: input.uid.trim(),
              institutionId: activeInstitution.id,
              email: input.email.trim(),
              displayName: input.displayName.trim(),
              role: input.role,
              branchId: input.branchId,
              departmentId: input.departmentId,
              status: input.status,
              ...input.permissions,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            })
          );
        }
        await logAudit('Update User RBAC', 'member', input.uid, `${input.displayName} -> ${input.role}`);
        pushToast(`Permissions saved for ${input.displayName}.`, 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    },
    [activeInstitution, logAudit, pushToast]
  );

  const markNotificationRead = useCallback(
    async (notifId: string) => {
      if (!activeInstitution) return;
      try {
        await updateDoc(doc(db, 'institutions', activeInstitution.id, 'notifications', notifId), {
          isRead: true,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Mark read error:', err);
      }
    },
    [activeInstitution]
  );

  const markAllNotificationsRead = useCallback(async () => {
    if (!activeInstitution) return;
    const unread = notifications.filter((n) => !n.isRead);
    for (const n of unread) {
      try {
        await updateDoc(doc(db, 'institutions', activeInstitution.id, 'notifications', n.id), {
          isRead: true,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Mark all read error:', err);
      }
    }
    if (unread.length > 0) {
      pushToast(`Marked ${unread.length} notification(s) as read.`, 'success');
    }
  }, [activeInstitution, notifications, pushToast]);

  const recordBackup = useCallback(
    async (input: {
      destination: BackupRecord['destination'];
      recordCount: number;
      checksum: string;
      encrypted: boolean;
    }) => {
      if (!activeInstitution || !firebaseUser) return;
      const backupId = makeId('bak');
      const path = `institutions/${activeInstitution.id}/backups/${backupId}`;
      try {
        await setDoc(doc(db, 'institutions', activeInstitution.id, 'backups', backupId), {
          id: backupId,
          institutionId: activeInstitution.id,
          destination: input.destination,
          createdByUid: firebaseUser.uid,
          createdByName: userProfile?.displayName || firebaseUser.displayName || 'Admin',
          recordCount: input.recordCount,
          checksum: input.checksum,
          encrypted: input.encrypted,
          createdAt: serverTimestamp(),
        });
        await logAudit('Create Backup Snapshot', 'backup', backupId, `${input.destination} (${input.recordCount} records)`);
        pushToast('Institutional backup recorded.', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [activeInstitution, firebaseUser, userProfile, logAudit, pushToast]
  );

  return (
    <IMSContext.Provider
      value={{
        firebaseUser,
        authLoading,
        authError,
        userProfile,
        institutions,
        activeInstitution,
        activeMember,
        effectiveRole,
        effectivePermissions,
        previewRole,
        setPreviewRole,
        selectedBadgeRosterId,
        setSelectedBadgeRosterId,
        branches,
        departments,
        roster,
        attendance,
        calls,
        callCategories,
        members,
        notifications,
        auditLogs,
        backups,
        offlineQueue,
        offlineActivityQueue,
        isOnline,
        browserOnline,
        simulatedOffline,
        setSimulatedOffline,
        swStatus,
        swScope,
        lastSyncedAt,
        headlessSyncStatus,
        isSyncingOffline,
        activeTab,
        setActiveTab,
        voiceLaunchRequested,
        triggerVoiceAssistant,
        selectedBranchFilter,
        setSelectedBranchFilter,
        theme,
        toggleTheme,
        language,
        setLanguage,
        toasts,
        pushToast,
        dismissToast,
        signInWithGoogle,
        retryProfileSync,
        logout,
        selectInstitution,
        createInstitution,
        updateInstitutionSettings,
        createBranch,
        updateBranch,
        deleteBranch,
        createDepartment,
        updateDepartment,
        deleteDepartment,
        createRosterMember,
        updateRosterMember,
        deleteRosterMember,
        recordAttendance,
        syncOfflineQueue,
        triggerServiceWorkerSync,
        retryFailedOfflineItems,
        discardQueuedItem,
        createCallRecord,
        updateCallRecord,
        deleteCallRecord,
        createCallCategory,
        deleteCallCategory,
        saveMemberRbac,
        createNotification,
        markNotificationRead,
        markAllNotificationsRead,
        recordBackup,
        logAudit,
        seedSampleInstitutionData,
      }}
    >
      {children}
    </IMSContext.Provider>
  );
}

export function useIMS() {
  const ctx = useContext(IMSContext);
  if (!ctx) throw new Error('useIMS must be used inside IMSProvider');
  return ctx;
}
