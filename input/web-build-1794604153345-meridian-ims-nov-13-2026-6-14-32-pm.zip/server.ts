import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), '.data');
const RECORDINGS_DIR = path.join(DATA_DIR, 'recordings');
const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
const SIP_INBOX_FILE = path.join(DATA_DIR, 'sip_inbox.json');

fs.mkdirSync(RECORDINGS_DIR, { recursive: true });
fs.mkdirSync(BACKUPS_DIR, { recursive: true });

function getEncryptionKey(): Buffer {
  const secret = process.env.RECORDING_ENCRYPTION_SECRET || 'meridian-ims-institutional-vault-2026';
  return crypto.createHash('sha256').update(secret).digest();
}

function encryptBuffer(plain: Buffer): { iv: string; tag: string; ciphertext: Buffer } {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getEncryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(plain), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    iv: iv.toString('hex'),
    tag: tag.toString('hex'),
    ciphertext,
  };
}

function decryptBuffer(ciphertext: Buffer, ivHex: string, tagHex: string): Buffer {
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    getEncryptionKey(),
    Buffer.from(ivHex, 'hex')
  );
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

function getGenAIClient(): GoogleGenAI {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is not configured in server environment secrets.');
  }
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function resolveAllowedModel(requested?: string): string {
  if (requested === 'gemini-3.1-flash-lite') return 'gemini-3.1-flash-lite';
  return 'gemini-4-hydrogen';
}

async function callOpenAICompatibleGateway(params: {
  systemInstruction: string;
  userPrompt: string;
  jsonMode?: boolean;
}): Promise<{ text: string; model: string }> {
  const baseUrl = (process.env.OPENAI_COMPATIBLE_BASE_URL || '').replace(/\/+$/, '');
  const apiKey = process.env.OPENAI_COMPATIBLE_API_KEY || '';
  const model = process.env.OPENAI_COMPATIBLE_MODEL || 'gpt-4o-mini';

  if (!baseUrl || !apiKey) {
    throw new Error(
      'OpenAI-Compatible Gateway selected, but OPENAI_COMPATIBLE_BASE_URL and OPENAI_COMPATIBLE_API_KEY are not configured in server secrets.'
    );
  }

  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: params.systemInstruction },
        { role: 'user', content: params.userPrompt },
      ],
      ...(params.jsonMode ? { response_format: { type: 'json_object' } } : {}),
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    throw new Error(`External AI Gateway HTTP ${res.status}: ${errText.slice(0, 180)}`);
  }

  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  return {
    text: data.choices?.[0]?.message?.content?.trim() || '',
    model,
  };
}

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);
  app.use(express.json({ limit: '30mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'newopenlink-server',
      aiConfigured: Boolean(process.env.GEMINI_API_KEY),
      timestamp: new Date().toISOString(),
    });
  });

  // 1. Audio Recording Upload (AES-256-GCM encrypted at rest when enabled)
  app.post('/api/recordings/upload', (req, res) => {
    try {
      const { audioBase64, mimeType, encrypt = true, institutionId = 'default' } = req.body as {
        audioBase64?: string;
        mimeType?: string;
        encrypt?: boolean;
        institutionId?: string;
      };

      if (!audioBase64 || typeof audioBase64 !== 'string') {
        res.status(400).json({ error: 'Missing audioBase64 payload.' });
        return;
      }

      const cleanBase64 = audioBase64.includes(',') ? audioBase64.split(',')[1] : audioBase64;
      const rawBuffer = Buffer.from(cleanBase64, 'base64');
      if (rawBuffer.length === 0) {
        res.status(400).json({ error: 'Decoded audio buffer is empty.' });
        return;
      }

      const recordingId = `rec_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
      const safeMime = mimeType && mimeType.startsWith('audio/') ? mimeType : 'audio/webm';
      const metaPath = path.join(RECORDINGS_DIR, `${recordingId}.meta.json`);
      const binPath = path.join(RECORDINGS_DIR, `${recordingId}.bin`);

      if (encrypt) {
        const { iv, tag, ciphertext } = encryptBuffer(rawBuffer);
        fs.writeFileSync(binPath, ciphertext);
        fs.writeFileSync(
          metaPath,
          JSON.stringify({
            recordingId,
            institutionId,
            mimeType: safeMime,
            encrypted: true,
            iv,
            tag,
            sizeBytes: rawBuffer.length,
            createdAt: new Date().toISOString(),
          })
        );
      } else {
        fs.writeFileSync(binPath, rawBuffer);
        fs.writeFileSync(
          metaPath,
          JSON.stringify({
            recordingId,
            institutionId,
            mimeType: safeMime,
            encrypted: false,
            sizeBytes: rawBuffer.length,
            createdAt: new Date().toISOString(),
          })
        );
      }

      res.json({
        recordingId,
        encrypted: Boolean(encrypt),
        mimeType: safeMime,
        sizeBytes: rawBuffer.length,
      });
    } catch (err) {
      console.error('Recording upload error:', err);
      res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to store recording.' });
    }
  });

  // 1b. Verify Recording Vault Sync Status
  app.post('/api/recordings/sync-status', (req, res) => {
    try {
      const { recordingIds } = req.body as { recordingIds?: string[] };
      const ids = Array.isArray(recordingIds) ? recordingIds.slice(0, 200) : [];
      const statuses: Record<
        string,
        { synced: boolean; encrypted: boolean; sizeBytes?: number; createdAt?: string }
      > = {};

      for (const rawId of ids) {
        if (typeof rawId !== 'string') continue;
        const safeId = rawId.replace(/[^a-zA-Z0-9_-]/g, '');
        if (!safeId) continue;
        const metaPath = path.join(RECORDINGS_DIR, `${safeId}.meta.json`);
        const binPath = path.join(RECORDINGS_DIR, `${safeId}.bin`);
        if (fs.existsSync(metaPath) && fs.existsSync(binPath)) {
          try {
            const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8')) as {
              encrypted?: boolean;
              sizeBytes?: number;
              createdAt?: string;
            };
            statuses[rawId] = {
              synced: true,
              encrypted: Boolean(meta.encrypted),
              sizeBytes: meta.sizeBytes,
              createdAt: meta.createdAt,
            };
          } catch {
            statuses[rawId] = { synced: false, encrypted: false };
          }
        } else {
          statuses[rawId] = { synced: false, encrypted: false };
        }
      }

      res.json({ statuses, checkedAt: new Date().toISOString() });
    } catch (err) {
      console.error('Recording sync-status error:', err);
      res.status(500).json({ error: 'Failed to check recording sync status.' });
    }
  });

  // 2. Stream / Playback Stored Call Recording
  app.get('/api/recordings/:id', (req, res) => {
    try {
      const safeId = req.params.id.replace(/[^a-zA-Z0-9_-]/g, '');
      const metaPath = path.join(RECORDINGS_DIR, `${safeId}.meta.json`);
      const binPath = path.join(RECORDINGS_DIR, `${safeId}.bin`);

      if (!fs.existsSync(metaPath) || !fs.existsSync(binPath)) {
        res.status(404).json({ error: 'Recording not found.' });
        return;
      }

      const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
      const rawBin = fs.readFileSync(binPath);
      const audioBytes = meta.encrypted
        ? decryptBuffer(rawBin, meta.iv, meta.tag)
        : rawBin;

      res.setHeader('Content-Type', meta.mimeType || 'audio/webm');
      res.setHeader('Content-Length', audioBytes.length);
      res.setHeader('Cache-Control', 'private, no-store');
      res.send(audioBytes);
    } catch (err) {
      console.error('Recording stream error:', err);
      res.status(500).json({ error: 'Unable to stream recording.' });
    }
  });

  // 3. Gemini Audio Transcription (gemini-3.5-transcribe)
  app.post('/api/ai/transcribe', async (req, res) => {
    try {
      const { recordingId, audioBase64, mimeType } = req.body as {
        recordingId?: string;
        audioBase64?: string;
        mimeType?: string;
      };

      let resolvedBase64 = audioBase64;
      let resolvedMime = mimeType || 'audio/webm';

      if (recordingId && !resolvedBase64) {
        const safeId = recordingId.replace(/[^a-zA-Z0-9_-]/g, '');
        const metaPath = path.join(RECORDINGS_DIR, `${safeId}.meta.json`);
        const binPath = path.join(RECORDINGS_DIR, `${safeId}.bin`);
        if (!fs.existsSync(metaPath) || !fs.existsSync(binPath)) {
          res.status(404).json({ error: 'Recording file not found on server for transcription.' });
          return;
        }
        const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
        const rawBin = fs.readFileSync(binPath);
        const audioBytes = meta.encrypted ? decryptBuffer(rawBin, meta.iv, meta.tag) : rawBin;
        resolvedBase64 = audioBytes.toString('base64');
        resolvedMime = meta.mimeType || 'audio/webm';
      }

      if (!resolvedBase64) {
        res.status(400).json({ error: 'Provide either recordingId or audioBase64.' });
        return;
      }

      const cleanBase64 = resolvedBase64.includes(',') ? resolvedBase64.split(',')[1] : resolvedBase64;
      const ai = getGenAIClient();
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: resolvedMime,
                data: cleanBase64,
              },
            },
            {
              text: 'Transcribe this institutional call recording verbatim. Label distinct speakers clearly (e.g., Speaker 1, Speaker 2) and preserve important numbers, dates, and action items.',
            },
          ],
        },
      });

      res.json({
        transcript: response.text?.trim() || 'No speech detected in audio recording.',
        model: 'gemini-3.5-transcribe',
      });
    } catch (err) {
      console.error('Transcription error:', err);
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to transcribe audio.',
      });
    }
  });

  // 4. Gemini Call Summarization & Smart Categorization (or Configurable Gateway)
  app.post('/api/ai/analyze-call', async (req, res) => {
    try {
      const { transcript, notes, callerName, recipientName, availableCategories, availableDepartments, model, provider } = req.body as {
        transcript?: string;
        notes?: string;
        callerName?: string;
        recipientName?: string;
        availableCategories?: string[];
        availableDepartments?: string[];
        model?: string;
        provider?: string;
      };

      const sourceText = [
        callerName ? `Caller: ${callerName}` : '',
        recipientName ? `Recipient: ${recipientName}` : '',
        transcript ? `Transcript:\n${transcript}` : '',
        notes ? `Operator Notes:\n${notes}` : '',
      ]
        .filter(Boolean)
        .join('\n\n');

      if (!sourceText.trim()) {
        res.status(400).json({ error: 'Provide transcript or call notes to analyze.' });
        return;
      }

      const systemInstruction =
        'You are an institutional call operations analyst. Summarize calls concisely, extract key facts, assign the most accurate category from the provided list, recommend the best department, and identify follow-up actions.';
      const userPrompt = `Analyze this institutional call record and extract structured intelligence as JSON with keys: summary (string), keyPoints (string[]), suggestedCategory (string), suggestedDepartment (string), urgency ("low"|"medium"|"high"|"critical"), actionItems (string[]).\n\nAvailable Categories: ${(availableCategories || ['General Inquiry', 'Support', 'Admissions', 'Finance', 'Operations', 'Emergency']).join(', ')}\nAvailable Departments: ${(availableDepartments || []).join(', ') || 'Any'}\n\n${sourceText}`;

      if (provider === 'OpenAI-Compatible Gateway') {
        const ext = await callOpenAICompatibleGateway({
          systemInstruction,
          userPrompt,
          jsonMode: true,
        });
        const parsed = JSON.parse(ext.text || '{}');
        res.json({ ...parsed, model: ext.model, provider });
        return;
      }

      const ai = getGenAIClient();
      const selectedModel = resolveAllowedModel(model);
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: userPrompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING, description: 'Concise 2-3 sentence executive summary of the call.' },
              keyPoints: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Up to 5 important facts, dates, IDs, or commitments mentioned.',
              },
              suggestedCategory: { type: Type.STRING, description: 'Best matching category name.' },
              suggestedDepartment: { type: Type.STRING, description: 'Recommended department name.' },
              urgency: { type: Type.STRING, description: 'low, medium, high, or critical' },
              actionItems: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Concrete follow-up actions required.',
              },
            },
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim());
      res.json({ ...parsed, model: selectedModel, provider: 'Google Gemini' });
    } catch (err) {
      console.error('Analyze call error:', err);
      res.status(500).json({ error: err instanceof Error ? err.message : 'Call analysis failed.' });
    }
  });

  // 5. Gemini Institutional AI Assistant (or Configurable Gateway)
  app.post('/api/ai/assistant', async (req, res) => {
    try {
      const { prompt, context, history, model, provider } = req.body as {
        prompt?: string;
        context?: Record<string, unknown>;
        history?: Array<{ role: 'user' | 'assistant'; text: string }>;
        model?: string;
        provider?: string;
      };

      if (!prompt || !prompt.trim()) {
        res.status(400).json({ error: 'Prompt is required.' });
        return;
      }

      const conversationContext = (history || [])
        .slice(-8)
        .map((m) => `${m.role === 'user' ? 'Admin' : 'Assistant'}: ${m.text}`)
        .join('\n');

      const fullContents = [
        `Institutional Context Snapshot (JSON):\n${JSON.stringify(context || {}, null, 2)}`,
        conversationContext ? `Recent Conversation:\n${conversationContext}` : '',
        `Current Request:\n${prompt}`,
      ]
        .filter(Boolean)
        .join('\n\n');

      const systemInstruction =
        'You are the NewOpenlink Operations Assistant. Answer administrator questions strictly based on the provided institutional context snapshot (attendance logs, roster, branches, departments, call records, and notifications). Provide precise counts, identify anomalies, draft clean executive reports, and state clearly if a requested data point is not present in the context.';

      if (provider === 'OpenAI-Compatible Gateway') {
        const ext = await callOpenAICompatibleGateway({
          systemInstruction,
          userPrompt: fullContents,
        });
        res.json({
          reply: ext.text || 'No response generated.',
          model: ext.model,
          provider,
        });
        return;
      }

      const ai = getGenAIClient();
      const selectedModel = resolveAllowedModel(model);

      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: fullContents,
        config: { systemInstruction },
      });

      res.json({
        reply: response.text?.trim() || 'No response generated.',
        model: selectedModel,
        provider: 'Google Gemini',
      });
    } catch (err) {
      console.error('Assistant error:', err);
      res.status(500).json({ error: err instanceof Error ? err.message : 'Assistant request failed.' });
    }
  });

  // 6. Gemini Attendance Anomaly Analyzer (or Configurable Gateway)
  app.post('/api/ai/analyze-attendance', async (req, res) => {
    try {
      const { summaryPayload, model, provider } = req.body as {
        summaryPayload?: unknown;
        model?: string;
        provider?: string;
      };

      const userPrompt = `Analyze these institutional attendance statistics and recent records for unusual patterns, chronic lateness, branch disparities, or compliance concerns. Return JSON with headline (string), overallHealth ("nominal"|"watch"|"action_required"), anomalies (string[]), recommendations (string[]):\n${JSON.stringify(summaryPayload || {}, null, 2)}`;

      if (provider === 'OpenAI-Compatible Gateway') {
        const ext = await callOpenAICompatibleGateway({
          systemInstruction: 'You are an institutional attendance compliance analyst.',
          userPrompt,
          jsonMode: true,
        });
        const parsed = JSON.parse(ext.text || '{}');
        res.json({ ...parsed, model: ext.model, provider });
        return;
      }

      const ai = getGenAIClient();
      const selectedModel = resolveAllowedModel(model);

      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: userPrompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              headline: { type: Type.STRING },
              overallHealth: { type: Type.STRING, description: 'nominal, watch, or action_required' },
              anomalies: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              recommendations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim());
      res.json({ ...parsed, model: selectedModel, provider: 'Google Gemini' });
    } catch (err) {
      console.error('Attendance analysis error:', err);
      res.status(500).json({ error: err instanceof Error ? err.message : 'Attendance analysis failed.' });
    }
  });

  // 6b. Voice-Controlled AI Command (Gemini Audio Transcription + Hands-Free Intent & Answer)
  app.post('/api/ai/voice-command', async (req, res) => {
    try {
      const {
        audioBase64,
        mimeType,
        transcriptText,
        context,
        history,
        model,
        provider,
      } = req.body as {
        audioBase64?: string;
        mimeType?: string;
        transcriptText?: string;
        context?: Record<string, unknown>;
        history?: Array<{ role: 'user' | 'assistant'; text: string }>;
        model?: string;
        provider?: string;
      };

      const ai = getGenAIClient();
      let spokenText = (transcriptText || '').trim();

      if (audioBase64 && typeof audioBase64 === 'string') {
        const cleanBase64 = audioBase64.includes(',') ? audioBase64.split(',')[1] : audioBase64;
        if (cleanBase64.length > 0) {
          const transcribeRes = await ai.models.generateContent({
            model: 'gemini-3.5-transcribe',
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: mimeType || 'audio/webm',
                    data: cleanBase64,
                  },
                },
                {
                  text: 'Transcribe this short voice command for an institutional operations assistant cleanly and accurately. Output only the spoken command text.',
                },
              ],
            },
          });
          const transcribed = transcribeRes.text?.trim() || '';
          if (transcribed) {
            spokenText = transcribed;
          }
        }
      }

      if (!spokenText) {
        res.status(400).json({ error: 'No speech detected. Please try speaking closer to the microphone.' });
        return;
      }

      const conversationContext = (history || [])
        .slice(-6)
        .map((m) => `${m.role === 'user' ? 'Admin' : 'Assistant'}: ${m.text}`)
        .join('\n');

      const systemInstruction =
        'You are the NewOpenlink hands-free Voice Operations Assistant. Transcribed voice commands come from an administrator or officer. Answer questions strictly from the provided Institutional Context Snapshot JSON, and choose the single best action enum value if the user asked to navigate or trigger a scan. Keep spoken replies crisp, natural, and data-accurate (1-4 short sentences suitable for voice playback unless details are requested).';

      const userPrompt = `Determine the operational action and concise reply for this spoken command.\nAllowed action values:\n- "answer_only": user asked a question, summary, or status check (e.g. "Summarize today's calls", "Check attendance status")\n- "run_attendance_scan": user asked to scan or analyze attendance anomalies\n- "navigate_attendance": user asked to open QR scanner, QR badges, or attendance logs\n- "navigate_calls": user asked to open call recordings, call history, or PBX\n- "navigate_reports": user asked to open analytics or PDF/Excel reports\n- "navigate_notifications": user asked to open notifications or alerts\n- "navigate_backups": user asked to open backups or offline sync queue\n- "navigate_settings": user asked to open settings\n- "navigate_dashboard": user asked to open main dashboard\n\nReturn JSON with keys: action (string), reply (string).\n\nInstitutional Context Snapshot:\n${JSON.stringify(context || {}, null, 2)}\n\n${conversationContext ? `Recent Conversation:\n${conversationContext}\n\n` : ''}Spoken Command:\n"${spokenText}"`;

      if (provider === 'OpenAI-Compatible Gateway') {
        const ext = await callOpenAICompatibleGateway({
          systemInstruction,
          userPrompt,
          jsonMode: true,
        });
        const parsed = JSON.parse(ext.text || '{}') as { action?: string; reply?: string };
        res.json({
          transcript: spokenText,
          action: parsed.action || 'answer_only',
          reply: parsed.reply || 'Command processed.',
          model: ext.model,
          provider,
        });
        return;
      }

      const selectedModel = resolveAllowedModel(model);
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: userPrompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              action: {
                type: Type.STRING,
                description:
                  'One of: answer_only, run_attendance_scan, navigate_attendance, navigate_calls, navigate_reports, navigate_notifications, navigate_backups, navigate_settings, navigate_dashboard',
              },
              reply: {
                type: Type.STRING,
                description: 'Concise, clear voice-ready response grounded in the institutional data.',
              },
            },
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim()) as { action?: string; reply?: string };
      res.json({
        transcript: spokenText,
        action: parsed.action || 'answer_only',
        reply: parsed.reply || 'Command processed.',
        model: selectedModel,
        provider: 'Google Gemini',
      });
    } catch (err) {
      console.error('Voice command error:', err);
      res.status(500).json({ error: err instanceof Error ? err.message : 'Voice command processing failed.' });
    }
  });

  // 6c. Gemini Text-to-Speech (gemini-3.8-flash-lite-tts) for Hands-Free Readback
  app.post('/api/ai/tts', async (req, res) => {
    try {
      const { text } = req.body as { text?: string };
      const cleanText = (text || '').trim().slice(0, 1200);
      if (!cleanText) {
        res.status(400).json({ error: 'Text is required for speech synthesis.' });
        return;
      }

      const ai = getGenAIClient();
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [{ text: cleanText }],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        res.status(500).json({ error: 'No audio returned from TTS model.' });
        return;
      }
      res.json({ audioBase64: base64Audio, mimeType: 'audio/wav' });
    } catch (err) {
      console.error('TTS error:', err);
      res.status(500).json({ error: err instanceof Error ? err.message : 'TTS generation failed.' });
    }
  });

  // 7. PBX / SIP Trunk Webhook Receiver
  app.post('/api/telephony/sip-webhook', (req, res) => {
    try {
      const payload = req.body || {};
      const entry = {
        id: `sip_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
        callerName: String(payload.callerName || payload.caller_id_name || 'External Caller'),
        callerNumber: String(payload.callerNumber || payload.from || '+0000000000'),
        recipientName: String(payload.recipientName || payload.extension_name || 'Reception Desk'),
        recipientNumber: String(payload.recipientNumber || payload.to || '100'),
        direction: ['inbound', 'outbound', 'internal'].includes(payload.direction) ? payload.direction : 'inbound',
        callSource: 'pbx_sip' as const,
        durationSeconds: Math.max(0, Number(payload.durationSeconds || payload.billsec || 0)),
        pbxTrunk: String(payload.pbxTrunk || payload.trunk || 'SIP-Trunk-01'),
        recordingUrl: payload.recordingUrl ? String(payload.recordingUrl) : undefined,
        consentRecorded: Boolean(payload.consentRecorded ?? true),
        receivedAt: new Date().toISOString(),
      };

      const existing: unknown[] = fs.existsSync(SIP_INBOX_FILE)
        ? JSON.parse(fs.readFileSync(SIP_INBOX_FILE, 'utf-8'))
        : [];
      const updated = [entry, ...existing].slice(0, 50);
      fs.writeFileSync(SIP_INBOX_FILE, JSON.stringify(updated, null, 2));

      res.status(201).json({ status: 'accepted', event: entry });
    } catch (err) {
      console.error('SIP webhook error:', err);
      res.status(500).json({ error: 'Failed to process SIP webhook payload.' });
    }
  });

  app.get('/api/telephony/sip-inbox', (_req, res) => {
    try {
      const existing = fs.existsSync(SIP_INBOX_FILE)
        ? JSON.parse(fs.readFileSync(SIP_INBOX_FILE, 'utf-8'))
        : [];
      res.json({ events: existing });
    } catch {
      res.json({ events: [] });
    }
  });

  // 8. Server-side Checksummed & Encrypted Backup Snapshot
  app.post('/api/backups/create', (req, res) => {
    try {
      const { institutionId = 'default', snapshot, encrypt = true } = req.body as {
        institutionId?: string;
        snapshot?: unknown;
        encrypt?: boolean;
      };

      if (!snapshot) {
        res.status(400).json({ error: 'Missing snapshot payload.' });
        return;
      }

      const jsonText = JSON.stringify(snapshot, null, 2);
      const rawBuf = Buffer.from(jsonText, 'utf-8');
      const checksum = crypto.createHash('sha256').update(rawBuf).digest('hex').slice(0, 24);
      const backupId = `bak_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
      const filePath = path.join(BACKUPS_DIR, `${backupId}.imsvault`);

      if (encrypt) {
        const { iv, tag, ciphertext } = encryptBuffer(rawBuf);
        fs.writeFileSync(
          filePath,
          JSON.stringify({
            format: 'meridian-ims-encrypted-backup-v1',
            institutionId,
            checksum,
            iv,
            tag,
            payload: ciphertext.toString('base64'),
            createdAt: new Date().toISOString(),
          })
        );
      } else {
        fs.writeFileSync(filePath, jsonText);
      }

      res.json({
        backupId,
        checksum,
        sizeBytes: rawBuf.length,
        encrypted: Boolean(encrypt),
        createdAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error('Backup error:', err);
      res.status(500).json({ error: 'Failed to store backup archive.' });
    }
  });

  app.get('/api/backups/:id/download', (req, res) => {
    const safeId = req.params.id.replace(/[^a-zA-Z0-9_-]/g, '');
    const filePath = path.join(BACKUPS_DIR, `${safeId}.imsvault`);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Backup file not found.' });
      return;
    }
    res.download(filePath, `${safeId}.imsvault`);
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server: httpServer },
      },
      appType: 'custom',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      try {
        const url = req.originalUrl;
        const html = fs.readFileSync(path.resolve(process.cwd(), 'index.html'), 'utf-8');
        const transformed = await vite.transformIndexHtml(url, html);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(transformed);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`NewOpenlink server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
