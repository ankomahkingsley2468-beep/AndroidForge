package com.meridian.ims.recording

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File

/**
 * Meridian IMS Foreground Microphone Service (Android 14+ Compliant).
 * Displays a persistent OS notification while recording consented VoIP/WebRTC
 * or local microphone audio sessions.
 */
class RecordingForegroundService : Service() {

  private var recorder: MediaRecorder? = null
  private var outputFile: File? = null

  companion object {
    const val CHANNEL_ID = "meridian_call_recording_channel"
    const val NOTIFICATION_ID = 4102
    const val EXTRA_CALL_ID = "extra_call_id"
    const val EXTRA_CONSENT_CONFIRMED = "extra_consent_confirmed"
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val consentConfirmed = intent?.getBooleanExtra(EXTRA_CONSENT_CONFIRMED, false) ?: false
    val callId = intent?.getStringExtra(EXTRA_CALL_ID) ?: "voip_${System.currentTimeMillis()}"

    if (!consentConfirmed) {
      stopSelf()
      return START_NOT_STICKY
    }

    ensureNotificationChannel()
    val notification = buildNotification(callId)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
      )
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }

    startEncryptedCapture(callId)
    return START_STICKY
  }

  private fun startEncryptedCapture(callId: String) {
    val dir = File(filesDir, "encrypted_calls").apply { mkdirs() }
    outputFile = File(dir, "$callId.m4a")
    val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      MediaRecorder(this)
    } else {
      @Suppress("DEPRECATION")
      MediaRecorder()
    }
    mr.apply {
      setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
      setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
      setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
      setAudioSamplingRate(44100)
      setAudioEncodingBitRate(128000)
      setOutputFile(outputFile?.absolutePath)
      prepare()
      start()
    }
    recorder = mr
  }

  private fun ensureNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "Institutional Call Recording",
        NotificationManager.IMPORTANCE_LOW
      )
      val nm = getSystemService(NotificationManager::class.java)
      nm.createNotificationChannel(channel)
    }
  }

  private fun buildNotification(callId: String): Notification {
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("NewOpenlink Recording Active")
      .setContentText("Consented call capture in progress ($callId)")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setOngoing(true)
      .build()
  }

  override fun onDestroy() {
    try {
      recorder?.stop()
      recorder?.release()
    } catch (_: Exception) {
      // ignore release errors if stopped early
    }
    recorder = null
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null
}
