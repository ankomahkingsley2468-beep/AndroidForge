package com.meridian.ims.telephony

import android.net.Uri
import android.os.Build
import android.telecom.Connection
import android.telecom.ConnectionRequest
import android.telecom.ConnectionService
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager

/**
 * Meridian IMS Native Android Telecom ConnectionService.
 * Integrates institutional App-to-App VoIP and SIP calls with Android Telecom
 * for lock-screen controls, Bluetooth audio routing, and legal recording consent.
 *
 * NOTE: Android 10+ prohibits third-party apps from capturing ordinary cellular
 * SIM voice downlink/uplink audio without system-privileged permissions.
 * Cellular calls must be bridged through institutional PBX/SIP trunks or
 * verified enterprise dialer hardware.
 */
class TelecomConnectionService : ConnectionService() {

  override fun onCreateOutgoingConnection(
    connectionManagerPhoneAccount: PhoneAccountHandle?,
    request: ConnectionRequest?
  ): Connection {
    val connection = MeridianVoipConnection(request?.address)
    connection.setInitializing()
    connection.setActive()
    return connection
  }

  override fun onCreateIncomingConnection(
    connectionManagerPhoneAccount: PhoneAccountHandle?,
    request: ConnectionRequest?
  ): Connection {
    val connection = MeridianVoipConnection(request?.address)
    connection.setRinging()
    return connection
  }

  private inner class MeridianVoipConnection(
    private val remoteAddress: Uri?
  ) : Connection() {
    init {
      connectionProperties = PROPERTY_SELF_MANAGED
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        audioModeIsVoip = true
      }
      remoteAddress?.let {
        setAddress(it, TelecomManager.PRESENTATION_ALLOWED)
      }
    }

    override fun onAnswer() {
      setActive()
    }

    override fun onDisconnect() {
      setDisconnected(android.telecom.DisconnectCause(android.telecom.DisconnectCause.LOCAL))
      destroy()
    }

    override fun onAbort() {
      setDisconnected(android.telecom.DisconnectCause(android.telecom.DisconnectCause.CANCELED))
      destroy()
    }
  }
}
