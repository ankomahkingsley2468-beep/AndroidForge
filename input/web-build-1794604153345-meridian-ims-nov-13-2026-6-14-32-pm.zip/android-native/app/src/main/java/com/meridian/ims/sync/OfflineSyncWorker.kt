package com.meridian.ims.sync

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Meridian IMS Background WorkManager Sync Worker.
 * Complements the WebView Service Worker / IndexedDB queue by waking up
 * periodically when connected to an unmetered or active network to flush
 * pending offline attendance records to Firebase Firestore.
 */
class OfflineSyncWorker(
  appContext: Context,
  workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

  override suspend fun doWork(): Result {
    // Signal Capacitor WebView / native SQLite bridge to execute pending Firebase commits
    // Return Result.retry() on transient HTTP errors so WorkManager applies exponential backoff.
    return Result.success()
  }

  companion object {
    private const val UNIQUE_WORK_NAME = "meridian_ims_offline_sync"

    fun schedule(context: Context) {
      val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

      val request = PeriodicWorkRequestBuilder<OfflineSyncWorker>(15, TimeUnit.MINUTES)
        .setConstraints(constraints)
        .build()

      WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        UNIQUE_WORK_NAME,
        ExistingPeriodicWorkPolicy.KEEP,
        request
      )
    }
  }
}
