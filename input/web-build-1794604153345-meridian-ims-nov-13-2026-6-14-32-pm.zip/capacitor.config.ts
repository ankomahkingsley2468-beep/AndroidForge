/**
 * Android APK Packaging Configuration (Capacitor 6+)
 * Build web bundle with `npm run build` then run:
 *   npx cap add android && npx cap sync android && npx cap open android
 */
const capacitorConfig = {
  appId: 'com.meridian.ims',
  appName: 'Meridian IMS',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      backgroundColor: '#0f172a',
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_meridian',
      iconColor: '#4f46e5',
    },
  },
};

export default capacitorConfig;
