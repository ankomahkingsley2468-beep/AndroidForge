# Meridian IMS — Firestore Security Specification

## 1. Data Invariants
1. **Tenant Isolation**: Every institutional sub-resource (`branches`, `departments`, `roster`, `attendance`, `calls`, `callCategories`, `notifications`, `auditLogs`, `backups`, `members`) belongs to a single `institutionId` and cannot be read or written across institution boundaries.
2. **Role-Based Master Gate**: Institutional access is gated by `/institutions/{institutionId}/members/{uid}` (with `status == 'active'`) or the institution's `ownerUid`, or the verified bootstrapped Super Admin (`ankomahkingsley2468@gmail.com` with `email_verified == true`).
3. **Self-Role Escalation Prevention**: Users cannot assign themselves `super_admin` or escalate their own `role` or `permissions` in `/users/{uid}` or `/institutions/{institutionId}/members/{memberId}`.
4. **Immutable Audit Logs**: Documents in `/institutions/{institutionId}/auditLogs/{logId}` are append-only (`create` allowed for verified institutional members; `update` and `delete` strictly denied).
5. **Temporal Integrity**: `createdAt` must equal `request.time` on `create` and remain immutable on `update`. `updatedAt` must equal `request.time` on `create` and `update`.
6. **Verified Identity**: All mutations require `request.auth != null && request.auth.token.email_verified == true`.
7. **Relational Consistency**: `departments`, `roster`, and `attendance` creation verify parent `branches`, `departments`, and `roster` document existence via `exists()`, and static schema checks run prior to any DB read.
8. **Terminal State Locking**: Once an `AttendanceRecord` reaches `status == 'checked_out'` or a `CallRecord` reaches `status == 'archived'`, non-admin modifications are rejected.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Write**: Creating a branch without `request.auth`. Expected: `PERMISSION_DENIED`.
2. **Unverified Email Spoof**: Request with `email: "ankomahkingsley2468@gmail.com"` and `email_verified: false`. Expected: `PERMISSION_DENIED`.
3. **Self-Admin Escalation on User Create**: Creating `/users/{uid}` with `role: "super_admin"` by a non-super-admin user. Expected: `PERMISSION_DENIED`.
4. **Shadow Field Injection**: Creating a `RosterMember` with an unlisted ghost field `isVerifiedAdmin: true`. Expected: `PERMISSION_DENIED`.
5. **Cross-Tenant Read/Write**: Member of `inst_a` attempting to read or write `/institutions/inst_b/calls/call_1`. Expected: `PERMISSION_DENIED`.
6. **ID Poisoning**: Document path ID exceeding 128 chars or containing invalid characters (`../admin`). Expected: `PERMISSION_DENIED`.
7. **Timestamp Forgery**: Creating an `AttendanceRecord` with a backdated `createdAt` instead of `request.time`. Expected: `PERMISSION_DENIED`.
8. **Audit Log Tampering**: Updating or deleting an entry in `/institutions/{instId}/auditLogs/{logId}`. Expected: `PERMISSION_DENIED`.
9. **Role Downgrade/Privilege Escalation via Update**: An `employee` member updating their own `/members/{uid}` document to `role: "institution_admin"`. Expected: `PERMISSION_DENIED`.
10. **PII Leak via Blanket User List**: Signed-in non-admin user attempting to list `/users`. Expected: `PERMISSION_DENIED`.
11. **Oversized Payload Denial-of-Wallet**: Sending a 50KB `notes` or `fullName` string exceeding schema bounds. Expected: `PERMISSION_DENIED`.
12. **Terminal State Bypass on Backup / Attendance**: Attempting to mutate a `BackupRecord` or overwrite a `checked_out` attendance record as an officer. Expected: `PERMISSION_DENIED`.
